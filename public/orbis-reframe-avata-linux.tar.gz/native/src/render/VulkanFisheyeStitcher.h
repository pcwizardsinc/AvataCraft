#pragma once

#include <FisheyeProjection.h> // insv::StitchGpuParams
#include <SeamCut.h>           // insv::SeamCutStats
#include <SeamDepth.h>         // insv::SeamCosts
#include <SeamFlow.h>          // insv::SeamFlowStrips, insv::SeamFlowField
#include <Ycbcr.h>             // insv::YcbcrCoding

#include "ColorLut.h" // color::Grade
#include "ViewProjection.h" // view::Pose
#include "LensFrame.h"

#include <vulkan/vulkan.h>

#include <cstdint>
#include <functional>
#include <memory>
#include <string>
#include <vector>

// Vulkan compute port of insv::FisheyeStitcher::renderEquirect.
//
// Two ways to use it:
//   * init()      -- creates its own compute-only VkInstance/VkDevice; stitch()
//                    takes CPU-decoded RGB fisheye frames.
//   * initAdopt() -- adopts an existing VkDevice (FFmpeg's Vulkan video
//                    decoder); stitchVk() takes decoder-owned NV12 images and
//                    never touches host memory for the inputs (stage 2).
//
// Not thread-safe -- drive it from one thread (the NativeStitchSource decoder
// thread).

namespace render {

// Handles for one decoder-owned (FFmpeg Vulkan) fisheye frame, extracted under
// the frame lock. Mirrors insv::VulkanLensFrame (kept separate so the two libs'
// headers stay independent).
struct VulkanLensInput {
    VkImage image = VK_NULL_HANDLE;
    VkFormat format = VK_FORMAT_UNDEFINED;
    VkImageLayout layout = VK_IMAGE_LAYOUT_UNDEFINED;
    VkSemaphore semaphore = VK_NULL_HANDLE; // timeline
    uint64_t semWaitValue = 0;
    int width = 0;
    int height = 0;
    VkImageUsageFlags usage = 0; // pool image usage; fillLensFrameVk needs TRANSFER_SRC
};

// What stitchVk() left the image as -- write back into the AVVkFrame.
struct VulkanLensOutcome {
    uint64_t semSignalValue = 0;
    VkImageLayout newLayout = VK_IMAGE_LAYOUT_UNDEFINED;
};

// Where the time went in the last stitchVk() / stitchAndReframeVk() call
// (tools/playback_bench). GPU times come from timestamp queries and are < 0
// when the queue can't write timestamps.
struct StitchTiming {
    double stitchGpuMs = -1.0;  // the stitch pass
    double reframeGpuMs = -1.0; // reproject pass (stitchAndReframeVk only)
    double fenceWaitMs = 0.0;   // submit -> fence signalled (decode wait + GPU work)
    double copyMs = 0.0;        // memcpy out of the host-visible output buffer
};

class VulkanFisheyeStitcher {
public:
    VulkanFisheyeStitcher();
    ~VulkanFisheyeStitcher();

    VulkanFisheyeStitcher(const VulkanFisheyeStitcher&) = delete;
    VulkanFisheyeStitcher& operator=(const VulkanFisheyeStitcher&) = delete;

    // Own compute-only device; use with stitch(). False (err set) if no usable
    // Vulkan device is present.
    bool init(std::string& err);

    // Adopt FFmpeg's Vulkan device; builds the NV12/ycbcr pipeline; use with
    // stitchVk(). `queueFlags` is AVVulkanDeviceContext::queue_flags -- the
    // flags FFmpeg created its queues with (INTERNALLY_SYNCHRONIZED on
    // FFmpeg 9+ with drivers that offer it; those queues need
    // vkGetDeviceQueue2, vkGetDeviceQueue returns NULL for them). False (err
    // set) if the device can't do ycbcr conversion or the NV12 shader is
    // missing -- caller should fall back to init()+stitch(). `lensFormat` is
    // the decoder's picture format: NV12 (8-bit), or P010
    // (VK_FORMAT_G10X6_B10X6R10X6_2PLANE_420_UNORM_3PACK16, 10-bit, e.g. the
    // X6's I-Log); also false when the device can't sample it through a
    // ycbcr conversion with linear filtering. `ycbcr` is the stream's matrix
    // and range (insv::InsvStreamInfo), which the conversion and the
    // viewport's lens frames (fillLensFrameVk) take.
    bool initAdopt(VkInstance inst, VkPhysicalDevice phys, VkDevice dev,
                   uint32_t computeQueueFamily, VkDeviceQueueCreateFlags queueFlags,
                   std::string& err, VkFormat lensFormat, const insv::YcbcrCoding& ycbcr);

    bool ready() const { return m_ready; }

    // Whether stitchAndReframeVk() is usable (the reproject compute pipeline
    // built, reframe_reproject.comp). Independent of ready().
    bool reframeReady() const { return m_reframeReady; }

    // stage 1: reproject an RGB24 fisheye pair (params.fisheyeW x fisheyeH each)
    // into an eqW x eqH equirect (outRgba resized to eqW*eqH*4, opaque alpha).
    // With `measureSeamFlow`, the pair's seam flow is measured into the
    // window first (as measureSeamFlowVk), in the same submission, and the
    // stitch uses it (params.seamFlowGpu needn't be set).
    bool stitch(const uint8_t* rgb0, const uint8_t* rgb1, const insv::StitchGpuParams& params,
                int eqW, int eqH, std::vector<uint8_t>& outRgba, std::string& err,
                bool measureSeamFlow = false);
    // stage 1's seam flow alone: the pair's flow measured into the window,
    // no stitch (a seek's pre-roll). Blocking.
    bool measureSeamFlow(const uint8_t* rgb0, const uint8_t* rgb1,
                         const insv::StitchGpuParams& params, std::string& err);

    // stage 2: reproject a decoder-owned NV12 fisheye pair straight from VRAM.
    // Waits on each frame's timeline semaphore at semWaitValue and signals it
    // forward; *r0 / *r1 get the signalled value + left layout for the caller
    // to write back into the AVVkFrame. Blocking.
    bool stitchVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                  const insv::StitchGpuParams& params, int eqW, int eqH,
                  std::vector<uint8_t>& outRgba, VulkanLensOutcome* r0, VulkanLensOutcome* r1,
                  std::string& err);

    // stage 2 + export: stitch the NV12 fisheye pair to an eqW x eqH equirect
    // (kept GPU-resident), then reproject it to an outW x outH rectilinear
    // frame against `pose` (nullptr => the forward view), emitting tightly-packed BT.709 full-range NV12 into `outNv12`
    // (Y plane outW*outH, then interleaved UV outW*outH/2). outW must be a
    // multiple of 4 and outH a multiple of 2. No CPU reproject / swscale.
    // Requires reframeReady(). Same semaphore handshake as stitchVk().
    // `stab` (row-major 3x3, nullptr => identity) is the frame's gyro
    // de-rotation in the sphere frame, applied after `pose`. `colorGrade`
    // (nullptr => neutral) is the Colour panel grade, its LUT included, applied to the equirect sample before it's
    // reprojected.
    bool stitchAndReframeVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                            const insv::StitchGpuParams& params, int eqW, int eqH, int outW, int outH,
                            const view::Pose* pose, const float stab[9],
                            const color::Grade* colorGrade, std::vector<uint8_t>& outNv12,
                            VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);

    // A view's rectangle in a canvas of views, and its pose; its aspect is
    // the rectangle's.
    struct ViewRect {
        view::Pose pose;
        int x = 0, y = 0, w = 0, h = 0;
    };

    // stitchAndReframeVk with several views of the one equirect in one
    // canvasW x canvasH NV12 frame (the split screen's panes), filled with
    // `fillRgba` (R in the low byte) where no view goes. Each view's x and w
    // multiples of 4, y and h of 2. Same stab and grade for all.
    bool stitchAndReframeViewsVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                                 const insv::StitchGpuParams& params, int eqW, int eqH,
                                 int canvasW, int canvasH, const std::vector<ViewRect>& views,
                                 const float stab[9], const color::Grade* colorGrade,
                                 uint32_t fillRgba, std::vector<uint8_t>& outNv12,
                                 VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);

    // Depth-aware seam: measure the seam cost volume of a decoder-owned NV12
    // pair (pass 2 of the stitch shaders -- per azimuth bin and candidate
    // distance, the NCC of the two lenses) into `out`, in its own submission,
    // so the table solved from it can go into this same frame's stitch. Same
    // semaphore handshake as stitchVk(): pass r0 / r1's value and layout on as
    // the next call's semWaitValue / layout. Blocking. With `cutOut`, the
    // same submission also measures the seam cut's statistics (pass 3, with
    // params.seamQ -- the table the frame before) into it.
    bool measureSeamVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                       const insv::StitchGpuParams& params, insv::SeamCosts& out,
                       insv::SeamCutStats* cutOut, VulkanLensOutcome* r0, VulkanLensOutcome* r1,
                       std::string& err);

    // measureSeamVk's pass 3 alone: the seam cut's statistics (with
    // params.seamQ; all 0 or depth off = the template's geometry) into
    // `out`, no cost volume. The new stitcher's seam colour blend measures
    // the lenses' colour from them. Same handshake, blocking.
    bool measureSeamCutVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                          const insv::StitchGpuParams& params, insv::SeamCutStats& out,
                          VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);
    // The new stitcher's seam flow, all on the GPU: both lenses unwrapped
    // over the overlap (pass 4, on params' seam flow grid;
    // insv::MeasureSeamFlowStrips with the capture-time correction), the
    // flow between them both ways (seam_flow.comp; insv::SeamFlowEstimator's
    // DIS), added to the stitcher's window of the last
    // insv::kSeamFlowFrames frames (insv::SeamFlowWindow) and the window's
    // mean put into the flow texture -- what a frame with
    // params.seamFlowGpu stitches with. With `cutOut` the cut statistics
    // (pass 3, as measureSeamCutVk) in the same submission. Same handshake,
    // blocking.
    bool measureSeamFlowVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                           const insv::StitchGpuParams& params, insv::SeamCutStats* cutOut,
                           VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);
    // The seam flow window emptied (a seek): the next measured frame starts
    // it again. The texture keeps the last field until then.
    void resetSeamFlow();
    // Frames in the seam flow window (0 .. insv::kSeamFlowFrames).
    int seamFlowFrames() const;
    // The flow of strips measured elsewhere (`s`, on its own grid) added to
    // the window, as measureSeamFlowVk does with its own; for tests and
    // tools. Blocking.
    bool estimateSeamFlow(const insv::SeamFlowStrips& s, std::string& err);
    // The flow texture read back (the window's mean; the field the GPU
    // stitch samples, at half precision; and the fade's row as the last
    // stitch left it). For tests and tools.
    bool readSeamFlow(insv::SeamFlowField& out, std::string& err);
    // The fade's row solved from the window with `params`' seam colour
    // blend (its seamColour), as a stitch with the GPU's own field does
    // before it samples the texture; for tests and tools. Blocking.
    bool solveSeamFade(const insv::StitchGpuParams& params, std::string& err);

    // Whether renderViewVk() is usable (the fused view pipeline built -- needs
    // initAdopt(); fisheye_view_nv12.comp).
    bool viewReady() const { return m_viewReady; }

    enum class ViewFormat { Nv12, Rgba, P010 };

    // Fused render: the outW x outH rectilinear view straight from the
    // NV12 fisheye pair -- no equirect. Each output pixel's view ray (`pose`,
    // then `stab`, as stitchAndReframeVk) samples the lenses directly, so it
    // is one resample instead of two and costs output pixels, not sphere
    // pixels. `fmt` Nv12 = tightly-packed BT.709 limited NV12 (outW*outH*3/2
    // bytes); P010 = the same with 16-bit little-endian samples, the 10-bit
    // code in the high bits (outW*outH*3 bytes); Rgba = RGBA8 (outW*outH*4).
    // outW must be a multiple of 4, outH of 2. Same semaphore handshake as
    // stitchVk(). Requires viewReady().
    bool renderViewVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                      const insv::StitchGpuParams& params, int outW,
                      int outH, const view::Pose* pose, const float stab[9],
                      const color::Grade* colorGrade, ViewFormat fmt, std::vector<uint8_t>& out,
                      VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);

    // Several RGBA views of one pair in one submission, into one
    // canvasW x canvasH RGBA8 buffer (rows canvasW pixels long), cleared to
    // `clearRgba` (R in the low byte) first. Each view: its pose as above, its
    // rectangle in the canvas (x and w multiples of 4, h of 2); the aspect is
    // the rectangle's. Same stab for all, no colour grade. For the privacy
    // blur's plate scan: the detector's tiles and the quad tracker's views.
    bool renderViewsVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                       const insv::StitchGpuParams& params,
                       int canvasW, int canvasH, const std::vector<ViewRect>& views,
                       const float stab[9], uint32_t clearRgba, std::vector<uint8_t>& out,
                       VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);
    // The same in any ViewFormat with a colour grade, filled with `fillRgba`
    // where no view goes (the split screen's panes: NV12 / P010 for the
    // export, RGBA for a transition's layer). For NV12 / P010 each view's y
    // is even too.
    bool renderViewsVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                       const insv::StitchGpuParams& params,
                       int canvasW, int canvasH, const std::vector<ViewRect>& views,
                       const float stab[9], const color::Grade* colorGrade, ViewFormat fmt,
                       uint32_t fillRgba, std::vector<uint8_t>& out, VulkanLensOutcome* r0,
                       VulkanLensOutcome* r1, std::string& err);

    // Whether fillLensFrameVk() is usable -- exportable memory on this
    // device.
    bool lensExportReady() const;

    // The adopted device's lock on the compute queue this stitcher submits to
    // (insv::VulkanVideoDecoder::queueLock): the device is shared by other
    // threads' decoders. Set it right after initAdopt().
    void setQueueLock(std::function<void()> lock, std::function<void()> unlock);

    // Keeps the adopted device alive for as long as any LensFrame handed out
    // still references a ring slot (slots are freed on this device when the
    // last reference goes, which can be after this stitcher is gone). Set it
    // before the first fillLensFrameVk(): the decoder's hw device reference.
    void setDeviceKeepAlive(std::shared_ptr<void> keepAlive);

    // Hand the decoded NV12 pair to another Vulkan device. Copies both lenses'
    // Y / CbCr planes into a free slot of this stitcher's exportable ring
    // (render::LensFrame), and fills `out` with the slot and this frame's
    // packed stitch params. Blocks
    // until the GPU is done (and, if every slot is held, until one frees up --
    // the ring grows a little rather than deadlock). Same semaphore handshake
    // as stitchVk(). Requires lensExportReady() and a decoder image with
    // TRANSFER_SRC usage.
    bool fillLensFrameVk(const VulkanLensInput& f0, const VulkanLensInput& f1,
                         const insv::StitchGpuParams& params, LensFrame& out,
                         VulkanLensOutcome* r0, VulkanLensOutcome* r1, std::string& err);

    // Free the ring slots nobody holds (a source going idle).
    void trimLensRing();

    const StitchTiming& lastTiming() const;

private:
    bool bringUp(bool nv12Mode, std::string& err);
    bool buildReframePipeline(std::string& err);
    bool buildViewPipeline(std::string& err);
    // stitchAndReframeVk / stitchAndReframeViewsVk: `views` of one stitched
    // equirect into one NV12 buffer (canvas 0 x 0 = the single view); `fill`
    // fills it first.
    bool stitchAndReframeImpl(const VulkanLensInput& f0, const VulkanLensInput& f1,
                              const insv::StitchGpuParams& params, int eqW, int eqH, int canvasW,
                              int canvasH, const std::vector<ViewRect>& views, const float stab[9],
                              const color::Grade* colorGrade, const uint32_t* fill,
                              std::vector<uint8_t>& outNv12, VulkanLensOutcome* r0,
                              VulkanLensOutcome* r1, std::string& err);
    // renderViewVk / renderViewsVk: `views` into one buffer (canvas 0 x 0 =
    // the single view, NV12 or RGBA as `fmt`); `clear` fills it first.
    bool renderViewsImpl(const VulkanLensInput& f0, const VulkanLensInput& f1,
                         const insv::StitchGpuParams& params,
                         int canvasW, int canvasH, const std::vector<ViewRect>& views,
                         const float stab[9], const color::Grade* colorGrade, ViewFormat fmt,
                         const uint32_t* clear, std::vector<uint8_t>& out, VulkanLensOutcome* r0,
                         VulkanLensOutcome* r1, std::string& err);

    // measureSeamVk / measureSeamCutVk / measureSeamFlowVk: pass 2 into
    // `out`, pass 3 into `cutOut` (each: null = not run), with `flow` pass
    // 4 and the seam flow.
    bool measureSeamImpl(const VulkanLensInput& f0, const VulkanLensInput& f1,
                         const insv::StitchGpuParams& params, insv::SeamCosts* out,
                         insv::SeamCutStats* cutOut, bool flow, VulkanLensOutcome* r0,
                         VulkanLensOutcome* r1, std::string& err);
    // stitch / measureSeamFlow: the RGB pair uploaded; with `measureFlow`
    // the seam flow measured from it; with eqW > 0 stitched into outRgba.
    bool stitchRgbImpl(const uint8_t* rgb0, const uint8_t* rgb1, const insv::StitchGpuParams& params,
                       int eqW, int eqH, std::vector<uint8_t>* outRgba, bool measureFlow,
                       std::string& err);

    struct Impl;
    Impl* d = nullptr;
    bool m_ready = false;
    bool m_reframeReady = false;
    bool m_viewReady = false;
};

} // namespace render
