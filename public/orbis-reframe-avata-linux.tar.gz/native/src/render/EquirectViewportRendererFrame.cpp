// Before any Qt header (EquirectViewportRenderer.h has the reason).
#include <vulkan/vulkan.h>

#include "EquirectViewportRenderer.h"

#include "../core/Log.h"

#include <QMutexLocker>
#include <QVersionNumber>

#include <unistd.h> // dup / close: imported memory FDs

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

// One frame: the picture (an uploaded equirect or the stitcher's lens
// frames), the overlays, the Track subject box and the privacy regions,
// recorded into the frame's command buffer; and the frame stats.

namespace {

// A region outline as the view shows it: its quad's corners taken from the
// sphere frame into the view (the inverse of equirect.frag's ray: stab^T,
// then yaw, pitch and roll undone), clipped to what lies in front of the
// projection centre and projected into the output rect, px
// (view::pointToPlane: the quad's straight edges stay straight). Up to 6
// corners (4, plus one per edge the clip cuts). Fewer than 3 = nothing to
// draw.
int projectOutline(const EquirectViewportWindow::RegionOutline &o, const float stabRm[9],
                   const view::Pose &pose, const view::Lens &lens, float aspect, float rectW,
                   float rectH, float out[12])
{
    const float cy = std::cos(pose.yaw), sy = std::sin(pose.yaw);
    const float cp = std::cos(pose.pitch), sp = std::sin(pose.pitch);
    const float cr = std::cos(pose.roll), sr = std::sin(pose.roll);
    float v[4][3];
    for (int i = 0; i < 4; ++i) {
        const float *d = o.corner[i];
        // stab^T * d (stab is a rotation; rayWorld = stab * rayPosed).
        float x = stabRm[0] * d[0] + stabRm[3] * d[1] + stabRm[6] * d[2];
        float y = stabRm[1] * d[0] + stabRm[4] * d[1] + stabRm[7] * d[2];
        float z = stabRm[2] * d[0] + stabRm[5] * d[1] + stabRm[8] * d[2];
        // Undo the yaw (about Y), the pitch (about X), the roll (about Z).
        float x1 = x * cy - z * sy, z1 = x * sy + z * cy;
        float y2 = y * cp + z1 * sp, z2 = -y * sp + z1 * cp;
        v[i][0] = x1 * cr + y2 * sr;
        v[i][1] = -x1 * sr + y2 * cr;
        v[i][2] = z2;
    }
    // Keep z <= d - kNear (in front of the projection centre (0, 0, d));
    // Sutherland-Hodgman against that plane.
    constexpr float kNear = 1e-3f;
    const float zMax = lens.distortion - kNear;
    float c[6][3];
    int n = 0;
    for (int i = 0; i < 4; ++i) {
        const float *a = v[i], *b = v[(i + 1) % 4];
        const bool ina = a[2] <= zMax, inb = b[2] <= zMax;
        if (ina)
            std::copy(a, a + 3, c[n++]);
        if (ina != inb) {
            const float t = (zMax - a[2]) / (b[2] - a[2]);
            for (int k = 0; k < 3; ++k)
                c[n][k] = a[k] + t * (b[k] - a[k]);
            ++n;
        }
    }
    const float h = view::halfHeight(lens.fovY, lens.distortion);
    for (int i = 0; i < n; ++i) {
        float px = 0.0f, py = 0.0f;
        view::pointToPlane(c[i], lens.distortion, px, py);
        const float ndcX = px / (h * aspect);
        const float ndcY = -py / h;
        out[i * 2] = (ndcX + 1.0f) * 0.5f * rectW;
        out[i * 2 + 1] = (ndcY + 1.0f) * 0.5f * rectH;
    }
    return n;
}

} // namespace

EquirectViewportRenderer::LensImport *
EquirectViewportRenderer::importFor(const render::LensFrame &f, bool &lasting)
{
    lasting = false;
    const render::LensSlot &slot = *f.slot;
    auto it = m_imports.find(slot.id);
    if (it != m_imports.end())
        return &it->second;
    if (std::memcmp(slot.deviceUuid, m_deviceUuid, sizeof m_deviceUuid) != 0) {
        std::fprintf(stderr, "[viewport] lens frames come from another GPU; can't import\n");
        lasting = true;
        return nullptr;
    }

    VkDevice device = m_window->device();
    LensImport imp;
    for (int i = 0; i < render::LensSlot::kImages; ++i) {
        const bool flow = i == render::LensSlot::kFlowImage;
        const bool uv = (i & 1) != 0;
        const bool deep = slot.bitDepth > 8; // 10-bit: 16-bit planes
        const VkFormat fmt = flow ? VK_FORMAT_R16G16B16A16_SFLOAT
                             : deep ? (uv ? VK_FORMAT_R16G16_UNORM : VK_FORMAT_R16_UNORM)
                                    : (uv ? VK_FORMAT_R8G8_UNORM : VK_FORMAT_R8_UNORM);
        // Must match the exporter's image exactly (VulkanFisheyeStitcher).
        VkExternalMemoryImageCreateInfo emi{};
        emi.sType = VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_IMAGE_CREATE_INFO;
        emi.handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;
        VkImageCreateInfo ii{};
        ii.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
        ii.pNext = &emi;
        ii.imageType = VK_IMAGE_TYPE_2D;
        ii.format = fmt;
        ii.extent = flow ? VkExtent3D{static_cast<uint32_t>(slot.flowW),
                                      static_cast<uint32_t>(slot.flowH), 1}
                         : VkExtent3D{static_cast<uint32_t>(uv ? slot.lensW / 2 : slot.lensW),
                                      static_cast<uint32_t>(uv ? slot.lensH / 2 : slot.lensH), 1};
        ii.mipLevels = 1;
        ii.arrayLayers = 1;
        ii.samples = VK_SAMPLE_COUNT_1_BIT;
        ii.tiling = VK_IMAGE_TILING_OPTIMAL;
        ii.usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT;
        ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        bool ok = vkCreateImage(device, &ii, nullptr, &imp.img[i]) == VK_SUCCESS;

        VkMemoryRequirements req{};
        uint32_t type = UINT32_MAX;
        if (ok) {
            vkGetImageMemoryRequirements(device, imp.img[i], &req);
            for (uint32_t t = 0; t < m_memProps.memoryTypeCount && type == UINT32_MAX; ++t)
                if ((req.memoryTypeBits & (1u << t)) &&
                    (m_memProps.memoryTypes[t].propertyFlags & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT))
                    type = t;
            ok = type != UINT32_MAX;
        }
        if (ok) {
            const int fd = ::dup(slot.fd[i]); // the import takes ownership of this copy
            VkMemoryDedicatedAllocateInfo ded{};
            ded.sType = VK_STRUCTURE_TYPE_MEMORY_DEDICATED_ALLOCATE_INFO;
            ded.image = imp.img[i];
            VkImportMemoryFdInfoKHR imf{};
            imf.sType = VK_STRUCTURE_TYPE_IMPORT_MEMORY_FD_INFO_KHR;
            imf.pNext = &ded;
            imf.handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_OPAQUE_FD_BIT;
            imf.fd = fd;
            VkMemoryAllocateInfo ai{};
            ai.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
            ai.pNext = &imf;
            ai.allocationSize = slot.memSize[i];
            ai.memoryTypeIndex = type;
            ok = fd >= 0 &&
                 vkAllocateMemory(device, &ai, nullptr, &imp.mem[i]) == VK_SUCCESS;
            if (!ok && fd >= 0)
                ::close(fd); // not consumed on failure
        }
        if (ok)
            ok = vkBindImageMemory(device, imp.img[i], imp.mem[i], 0) == VK_SUCCESS;
        if (ok) {
            VkImageViewCreateInfo vi{};
            vi.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
            vi.image = imp.img[i];
            vi.viewType = VK_IMAGE_VIEW_TYPE_2D;
            vi.format = fmt;
            vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
            ok = vkCreateImageView(device, &vi, nullptr, &imp.view[i]) == VK_SUCCESS;
        }
        if (!ok) {
            destroyImport(imp); // lensImportFailed says so
            return nullptr;
        }
    }
    m_lensRetryWait = kLensRetryFirst; // there is room again
    return &m_imports.emplace(slot.id, imp).first->second;
}

void EquirectViewportRenderer::lensImportFailed()
{
    // Most often the graphics memory is short for a moment (another clip
    // opening, an export starting). The lens path itself is fine, so it is
    // tried again: playback sends equirects meanwhile, and the paused frame
    // on screen is read again as one (lensFramesLost).
    // Lens frames sent before the controller heard of it fail the same way:
    // one failure per try, not per frame.
    if (m_lensOff)
        return;
    const auto wait = m_lensRetryWait;
    m_lensRetryWait = std::min<std::chrono::seconds>(2 * wait, kLensRetryMax);
    m_lensRetryAt = std::chrono::steady_clock::now() + wait;
    m_lensOff = true;
    m_window->setLensFramesSupported(false);
    QMetaObject::invokeMethod(m_window, &EquirectViewportWindow::lensFramesLost,
                              Qt::QueuedConnection);
    std::fprintf(stderr,
                 "[viewport] importing a lens frame failed (is the graphics memory full?); the "
                 "equirect preview, the lenses tried again in %lld s\n",
                 static_cast<long long>(wait.count()));
}

void EquirectViewportRenderer::tryLensFramesAgain()
{
    if (!m_lensOff || !m_lensCapable || std::chrono::steady_clock::now() < m_lensRetryAt)
        return;
    m_lensOff = false;
    m_window->setLensFramesSupported(true);
    core::log::Info("[viewport] trying the lens frames again\n");
}

void EquirectViewportRenderer::retireLens(std::shared_ptr<const render::LensFrame> f)
{
    if (!f)
        return;
    // A frame recorded now finishes before the one concurrentFrameCount()
    // frames later starts (Qt waits on that frame slot's fence).
    const uint64_t frames = static_cast<uint64_t>(std::max(1, m_window->concurrentFrameCount()));
    m_retired.push_back({std::move(f), m_frameCounter + frames});
}

void EquirectViewportRenderer::recordTextureCopy(VkCommandBuffer cmd, uint32_t stagingSlot)
{
    VkImageMemoryBarrier toTransferDst{};
    toTransferDst.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    toTransferDst.oldLayout = m_textureUndefined ? VK_IMAGE_LAYOUT_UNDEFINED
                                                 : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    toTransferDst.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    toTransferDst.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toTransferDst.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toTransferDst.image = m_textureImage;
    toTransferDst.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    toTransferDst.srcAccessMask = m_textureUndefined ? 0 : VK_ACCESS_SHADER_READ_BIT;
    toTransferDst.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    const VkPipelineStageFlags srcStage = m_textureUndefined
        ? VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT
        : VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT;
    vkCmdPipelineBarrier(cmd, srcStage, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr,
                                     0, nullptr, 1, &toTransferDst);

    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {m_texWidth, m_texHeight, 1};
    vkCmdCopyBufferToImage(cmd, m_stagingBuffers[stagingSlot], m_textureImage,
                                       VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);

    VkImageMemoryBarrier toShaderRead{};
    toShaderRead.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    toShaderRead.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    toShaderRead.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    toShaderRead.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toShaderRead.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toShaderRead.image = m_textureImage;
    toShaderRead.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    toShaderRead.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    toShaderRead.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT,
                                     VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0,
                                     nullptr, 1, &toShaderRead);

    m_textureUndefined = false;
}

void EquirectViewportRenderer::recordInsetUpload(VkCommandBuffer cmd, InsetSlot &slot,
                                                 const std::vector<uint8_t> &rgba)
{
    const uint32_t frame = static_cast<uint32_t>(m_window->currentFrame());
    std::memcpy(slot.stagingMap[frame], rgba.data(), std::min<size_t>(rgba.size(), size_t(slot.w) * slot.h * 4));

    VkImageMemoryBarrier toDst{};
    toDst.sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
    toDst.oldLayout = slot.undefined ? VK_IMAGE_LAYOUT_UNDEFINED : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    toDst.newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    toDst.srcQueueFamilyIndex = toDst.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
    toDst.image = slot.img;
    toDst.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    toDst.srcAccessMask = slot.undefined ? 0 : VK_ACCESS_SHADER_READ_BIT;
    toDst.dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    vkCmdPipelineBarrier(cmd,
                                     slot.undefined ? VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT
                                                    : VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT,
                                     VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, nullptr, 0, nullptr, 1,
                                     &toDst);
    VkBufferImageCopy region{};
    region.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1};
    region.imageExtent = {slot.w, slot.h, 1};
    vkCmdCopyBufferToImage(cmd, slot.staging[frame], slot.img,
                                       VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &region);
    VkImageMemoryBarrier toRead = toDst;
    toRead.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
    toRead.newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    toRead.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    toRead.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT,
                                     VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0,
                                     nullptr, 1, &toRead);
    slot.undefined = false;
}

void EquirectViewportRenderer::statsFrameStart(bool newPicture)
{
    Stats &s = m_stats;
    const auto now = render::framestats::Clock::now();
    if (s.lastRender != render::framestats::Clock::time_point{})
        s.interval.add(render::framestats::MsBetween(s.lastRender, now));
    else
        s.windowStart = now;
    s.lastRender = now;
    if (newPicture) {
        if (s.rendersOfCurrent > 0)
            ++s.shownFor[std::min(s.rendersOfCurrent, 5) - 1];
        s.rendersOfCurrent = 0;
        ++s.newFrames;
    }
    ++s.rendersOfCurrent;
    const view::Pose pose = m_window->Pose();
    if (pose != s.lastPose) {
        ++s.poseChanges;
        s.lastPose = pose;
    }
}

void EquirectViewportRenderer::statsFrameEnd(render::framestats::Clock::time_point start)
{
    Stats &s = m_stats;
    const auto now = render::framestats::Clock::now();
    s.cpu.add(render::framestats::MsBetween(start, now));
    if (render::framestats::MsBetween(s.windowStart, now) < 1000.0)
        return;
    std::fprintf(stderr,
                 "[stats] viewport: renders %zu | interval mean %.2f p99 %.2f max %.2f ms | "
                 "cpu mean %.2f max %.2f ms | new frames %d, shown for 1/2/3/4/5+ renders: "
                 "%d/%d/%d/%d/%d | pose changes %d\n",
                 s.cpu.count(), s.interval.mean(), s.interval.pct(0.99), s.interval.max(),
                 s.cpu.mean(), s.cpu.max(), s.newFrames, s.shownFor[0], s.shownFor[1],
                 s.shownFor[2], s.shownFor[3], s.shownFor[4], s.poseChanges);
    s.interval.clear();
    s.cpu.clear();
    s.newFrames = s.poseChanges = 0;
    std::fill(std::begin(s.shownFor), std::end(s.shownFor), 0);
    s.windowStart = now;
}

void EquirectViewportRenderer::startNextFrame()
{
    // A swapchain rebuild (a resize) that ran out of memory half-way leaves
    // QVulkanWindow not ready, yet it still starts the frame -- with no
    // framebuffer, semaphores or fence. Drawing would use the null
    // framebuffer, and frameReady() would submit and present with the null
    // semaphores; both crash. So neither: the frame stays pending, Qt starts
    // no other, and the window is taken down (vulkanFailed), which releases
    // the swapchain.
    if (!m_window->isValid()) {
        m_window->ReportVulkanFailure("couldn't rebuild the swapchain");
        return;
    }
    const auto statsStart = render::framestats::Clock::now();
    VkCommandBuffer commandBuffer = m_window->currentCommandBuffer();
    ++m_frameCounter;
    // QVulkanWindow's default render pass has no external subpass dependency,
    // so its layout transitions at vkCmdBeginRenderPass aren't ordered after
    // (a) the swapchain acquire -- waited on at COLOR_ATTACHMENT_OUTPUT -- or
    // (b) the previous frame's store to the one depth-stencil image all
    // frames share (sync validation: WRITE_AFTER_READ vs
    // vkAcquireNextImageKHR, WRITE_AFTER_WRITE vs the last storeOp). One
    // barrier from those stages / writes to everything after covers both.
    VkMemoryBarrier attachments{};
    attachments.sType = VK_STRUCTURE_TYPE_MEMORY_BARRIER;
    attachments.srcAccessMask =
        VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    attachments.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_READ_BIT |
                                VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT |
                                VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT |
                                VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    vkCmdPipelineBarrier(
        commandBuffer,
        VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT |
            VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT,
        VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, 0, 1, &attachments, 0, nullptr, 0, nullptr);
    // Lens frames no frame in flight can still be reading go back to their ring.
    while (!m_retired.empty() && m_retired.front().releaseAt <= m_frameCounter)
        m_retired.pop_front();

    int width = 0, height = 0;
    std::vector<uint8_t> rgba;
    std::shared_ptr<const render::LensFrame> lens;
    const bool newPicture = m_window->TakePendingFrame(width, height, rgba, lens);
    if (render::framestats::Enabled())
        statsFrameStart(newPicture);
    // The lens frame shown until now: handed back once the new one imports,
    // else shown on instead of it (the equirect preview may hold an old
    // picture, or none).
    std::shared_ptr<const render::LensFrame> shownLens;
    if (newPicture) {
        if (lens) {
            if (m_lensMode)
                shownLens = std::move(m_currentLens);
            else
                retireLens(std::move(m_currentLens));
            m_currentLens = std::move(lens);
            m_lensMode = true;
        } else {
            // Upload recorded into this frame's own command buffer, before the
            // render pass begins -- no separate submit, no wait-idle.
            if (ensureTextureResources(static_cast<uint32_t>(width), static_cast<uint32_t>(height))) {
                const uint32_t slot = static_cast<uint32_t>(m_window->currentFrame());
                std::memcpy(m_stagingMapped[slot], rgba.data(), rgba.size());
                recordTextureCopy(commandBuffer, slot);
            }
            m_lastWidth = width;
            m_lastHeight = height;
            m_lastRgba = std::move(rgba);
            retireLens(std::move(m_currentLens));
            m_currentLens.reset();
            m_lensMode = false;
        }
    }

    // Lens mode: this frame's descriptor set -> the current pair's (imported)
    // images and its stitch params.
    const uint32_t frameSlot = static_cast<uint32_t>(m_window->currentFrame());
    LensImport *imp = nullptr;
    tryLensFramesAgain();
    if (m_lensMode && m_currentLens && m_lensCapable) {
        bool lasting = false;
        imp = importFor(*m_currentLens, lasting);
        if (!imp && lasting) {
            m_lensCapable = false;
            m_window->setLensFramesSupported(false); // the controller falls back
        } else if (!imp) {
            lensImportFailed();
            // The frame shown until now stays (its slot is imported); with
            // none, the failed one is let go, not tried again every render.
            bool unused = false;
            retireLens(std::move(m_currentLens));
            if (shownLens && (imp = importFor(*shownLens, unused)))
                m_currentLens = std::move(shownLens);
            else
                m_lensMode = false;
        }
    }
    retireLens(std::move(shownLens));
    if (imp) {
        static bool announced = false;
        if (!announced) {
            announced = true;
            core::log::Info("[viewport] drawing the view straight from the fisheyes (%dx%d "
                            "lenses)\n",
                            m_currentLens->slot->lensW, m_currentLens->slot->lensH);
        }
        if (imp->acquiredFill != m_currentLens->fill) {
            // Take the freshly written images over from the exporting device.
            VkImageMemoryBarrier acq[render::LensSlot::kImages]{};
            for (int i = 0; i < render::LensSlot::kImages; ++i) {
                acq[i].sType = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER;
                acq[i].oldLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
                acq[i].newLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
                acq[i].srcAccessMask = 0;
                acq[i].dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
                acq[i].srcQueueFamilyIndex = VK_QUEUE_FAMILY_EXTERNAL;
                acq[i].dstQueueFamilyIndex = m_window->graphicsQueueFamilyIndex();
                acq[i].image = imp->img[i];
                acq[i].subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
            }
            vkCmdPipelineBarrier(commandBuffer, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
                                             VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr,
                                             0, nullptr, render::LensSlot::kImages, acq);
            imp->acquiredFill = m_currentLens->fill;
        }
        imp->lastUsed = m_frameCounter;
        std::memcpy(m_lensUboMap[frameSlot], m_currentLens->params.data(),
                    render::LensFrame::kParamsBytes);
        VkDescriptorBufferInfo uboInfo{m_lensUbo[frameSlot], 0, render::LensFrame::kParamsBytes};
        VkDescriptorImageInfo imgInfo[render::LensSlot::kImages];
        VkWriteDescriptorSet w[1 + render::LensSlot::kImages]{};
        w[0].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET;
        w[0].dstSet = m_lensSets[frameSlot];
        w[0].dstBinding = 0;
        w[0].descriptorCount = 1;
        w[0].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
        w[0].pBufferInfo = &uboInfo;
        for (int i = 0; i < render::LensSlot::kImages; ++i) {
            imgInfo[i] = {i == render::LensSlot::kFlowImage ? m_flowSampler : m_lensSampler,
                          imp->view[i], VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
            w[1 + i] = w[0];
            w[1 + i].dstBinding = static_cast<uint32_t>(1 + i);
            w[1 + i].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
            w[1 + i].pBufferInfo = nullptr;
            w[1 + i].pImageInfo = &imgInfo[i];
        }
        vkUpdateDescriptorSets(m_window->device(), 1 + render::LensSlot::kImages, w, 0, nullptr);
    }

    // Drop imports of slots not drawn for a while (a trimmed ring, a closed
    // clip). None of them is in flight any more.
    for (auto it = m_imports.begin(); it != m_imports.end();) {
        const bool current = m_currentLens && it->first == m_currentLens->slot->id;
        if (!current && it->second.lastUsed + 120 < m_frameCounter) {
            destroyImport(it->second);
            it = m_imports.erase(it);
        } else {
            ++it;
        }
    }

    // Insets: upload any new pictures (outside the render pass). Each has
    // its clip's slot; one not drawn for a while is freed (nothing in
    // flight uses it any more).
    std::vector<EquirectViewportWindow::InsetDraw> insets;
    if (m_insetPipeline != VK_NULL_HANDLE)
        insets = m_window->RenderInsets();
    std::vector<InsetSlot *> insetSlots(insets.size(), nullptr);
    {
        std::map<int, int> seen; // clip id -> its insets so far this frame
        for (size_t i = 0; i < insets.size(); ++i) {
            const auto &d = insets[i];
            InsetSlot *slot = insetSlot({d.clipId, seen[d.clipId]++});
            if (!slot)
                continue;
            slot->lastUsed = m_frameCounter;
            if (!d.rgba || d.width <= 0 || d.height <= 0 ||
                d.rgba->size() < size_t(d.width) * d.height * 4)
                continue;
            if (slot->key == d.frameKey && slot->w == uint32_t(d.width) &&
                slot->h == uint32_t(d.height)) {
                insetSlots[i] = slot;
                continue;
            }
            if (!ensureInsetSlot(*slot, uint32_t(d.width), uint32_t(d.height)))
                continue;
            recordInsetUpload(commandBuffer, *slot, *d.rgba);
            slot->key = d.frameKey;
            insetSlots[i] = slot;
        }
    }
    for (auto it = m_insetSlots.begin(); it != m_insetSlots.end();) {
        InsetSlot &slot = it->second;
        if (slot.lastUsed + 120 < m_frameCounter) {
            destroyInsetSlot(slot);
            vkFreeDescriptorSets(m_window->device(), slot.pool, 1, &slot.set);
            it = m_insetSlots.erase(it);
        } else {
            ++it;
        }
    }

    // The grades' LUTs: uploaded on first use (their own submissions), so
    // before the render pass is recorded. Every set picked here stays valid
    // for this command buffer, however many grades it binds.
    m_luts.beginFrame();
    const color::Grade grade = m_window->CurrentColorGrade();
    const VkDescriptorSet lutSet = m_luts.setFor(grade.hasLut() ? grade.lut : nullptr);
    std::vector<VkDescriptorSet> insetLutSets(insets.size(), VK_NULL_HANDLE);
    for (size_t i = 0; i < insets.size(); ++i)
        if (insetSlots[i])
            insetLutSets[i] =
                m_luts.setFor(insets[i].colorGrade.hasLut() ? insets[i].colorGrade.lut : nullptr);

    const QSize size = m_window->swapChainImageSize();

    // One clear value per attachment the default render pass clears: colour,
    // depth-stencil, and the multisample colour when MSAA is on
    // (VUID-VkRenderPassBeginInfo-clearValueCount-00902).
    VkClearValue clearValues[3]{};
    const float *surround = m_window->SurroundColor();
    clearValues[0].color = {{surround[0], surround[1], surround[2], 1.0f}};
    clearValues[1].depthStencil = {1.0f, 0};
    clearValues[2].color = clearValues[0].color;

    VkRenderPassBeginInfo beginInfo{};
    beginInfo.sType = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO;
    beginInfo.renderPass = m_window->defaultRenderPass();
    beginInfo.framebuffer = m_window->currentFramebuffer();
    beginInfo.renderArea.extent.width = static_cast<uint32_t>(size.width());
    beginInfo.renderArea.extent.height = static_cast<uint32_t>(size.height());
    beginInfo.clearValueCount = m_window->sampleCountFlagBits() > VK_SAMPLE_COUNT_1_BIT ? 3 : 2;
    beginInfo.pClearValues = clearValues;

    vkCmdBeginRenderPass(commandBuffer, &beginInfo, VK_SUBPASS_CONTENTS_INLINE);
    // Without the equirect texture's set (its creation failed, logged in
    // initResources) or the texture (no room for it, ensureTextureResources)
    // the equirect preview isn't drawn, only the surround; the view straight
    // from the fisheyes still is.
    const bool drawPicture = imp || (m_pipeline != VK_NULL_HANDLE &&
                                     m_descriptorSet != VK_NULL_HANDLE &&
                                     m_textureView != VK_NULL_HANDLE);
    if (imp) {
        vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, m_lensPipeline);
        const VkDescriptorSet sets[2] = {m_lensSets[frameSlot], lutSet};
        vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                            m_lensPipelineLayout, 0, 2, sets, 0, nullptr);
    } else if (drawPicture) {
        vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, m_pipeline);
        const VkDescriptorSet sets[2] = {m_descriptorSet, lutSet};
        vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                            m_pipelineLayout, 0, 2, sets, 0, nullptr);
    }

    // Letterbox / pillarbox the picture to the project's output aspect: the
    // render pass clears the whole window to black, the draw covers only the
    // centred output-shaped rect.
    const float winAspect =
        size.height() > 0 ? static_cast<float>(size.width()) / size.height() : 1.0f;
    const float outAspect = m_window->OutputAspect() > 0.0f ? m_window->OutputAspect() : winAspect;
    int rectW = size.width();
    int rectH = size.height();
    if (outAspect > winAspect)
        rectH = std::max(1, static_cast<int>(std::lround(size.width() / outAspect)));
    else
        rectW = std::max(1, static_cast<int>(std::lround(size.height() * outAspect)));
    const int rectX = (size.width() - rectW) / 2;
    const int rectY = (size.height() - rectH) / 2;

    VkViewport viewport{};
    viewport.x = static_cast<float>(rectX);
    viewport.y = static_cast<float>(rectY);
    viewport.width = static_cast<float>(rectW);
    viewport.height = static_cast<float>(rectH);
    viewport.minDepth = 0.0f;
    viewport.maxDepth = 1.0f;
    vkCmdSetViewport(commandBuffer, 0, 1, &viewport);

    VkRect2D scissor{};
    scissor.offset.x = rectX;
    scissor.offset.y = rectY;
    scissor.extent.width = static_cast<uint32_t>(rectW);
    scissor.extent.height = static_cast<uint32_t>(rectH);
    vkCmdSetScissor(commandBuffer, 0, 1, &scissor);

    // Split screen: each pane its part of the output rect (as the export
    // places them, pane::rects at the output size) and its own view; the
    // gap between them cleared to its colour first. One pane = the rect.
    struct PaneDraw {
        float x, y, w, h; // framebuffer px
        float aspect;     // at the output size
        view::Pose pose;
        view::Lens lens; // the pose at that aspect
    };
    std::vector<PaneDraw> panes;
    const pane::Split split = m_window->Split();
    const int activePane = m_window->EffectiveActivePane();
    {
        view::Pose poses[pane::kMaxPanes];
        m_window->PanePoses(poses);
        int outW = 0, outH = 0;
        m_window->OutputSize(outW, outH);
        const std::vector<pane::Rect> rects =
            split.isSplit() ? pane::rects(split, outW, outH) : std::vector<pane::Rect>{};
        for (size_t i = 0; i < rects.size(); ++i) {
            const pane::Rect &r = rects[i];
            PaneDraw d{rectX + float(r.x) / outW * rectW, rectY + float(r.y) / outH * rectH,
                       float(r.w) / outW * rectW, float(r.h) / outH * rectH,
                       float(r.aspect()), poses[i], view::lens(poses[i], r.aspect())};
            panes.push_back(d);
        }
        if (panes.empty()) {
            // The window's own: one picture.
            // The export's aspect, to the bit, when the output size is known.
            const double aspect = m_window->OutputAspect() > 0.0f && outW > 0 && outH > 0
                                      ? double(outW) / double(outH)
                                      : double(outAspect);
            panes.push_back({float(rectX), float(rectY), float(rectW), float(rectH), outAspect,
                             poses[0], view::lens(poses[0], aspect)});
        }
    }
    // A pane's integer rect, clipped to the output rect.
    const auto paneScissor = [&](const PaneDraw &d) {
        const int x0 = std::max(rectX, int(std::lround(d.x)));
        const int y0 = std::max(rectY, int(std::lround(d.y)));
        const int x1 = std::min(rectX + rectW, int(std::lround(d.x + d.w)));
        const int y1 = std::min(rectY + rectH, int(std::lround(d.y + d.h)));
        VkRect2D r{};
        r.offset = {x0, y0};
        r.extent = {uint32_t(std::max(0, x1 - x0)), uint32_t(std::max(0, y1 - y0))};
        return r;
    };
    if (panes.size() > 1 && drawPicture) {
        VkClearAttachment gap{};
        gap.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        gap.colorAttachment = 0;
        gap.clearValue.color = {{((split.gapRgb >> 16) & 0xff) / 255.0f,
                                 ((split.gapRgb >> 8) & 0xff) / 255.0f,
                                 (split.gapRgb & 0xff) / 255.0f, 1.0f}};
        VkClearRect cr{};
        cr.rect = scissor;
        cr.layerCount = 1;
        vkCmdClearAttachments(commandBuffer, 1, &gap, 1, &cr);
    }

    PushConstants pc{};
    pc.yaw = panes[0].pose.yaw;
    pc.pitch = panes[0].pose.pitch;
    pc.roll = panes[0].pose.roll;
    pc.fovY = panes[0].lens.fovY;
    pc.aspect = outAspect;
    pc.distortion = panes[0].lens.distortion;
    // Stabilization matrix, row-major in the window -> col-major (3 padded
    // vec3 columns) for std140.
    float stabRm[9];
    m_window->StabRowMajor(stabRm);
    for (int col = 0; col < 3; ++col) {
        pc.stab[col * 4 + 0] = stabRm[0 * 3 + col];
        pc.stab[col * 4 + 1] = stabRm[1 * 3 + col];
        pc.stab[col * 4 + 2] = stabRm[2 * 3 + col];
        pc.stab[col * 4 + 3] = 0.0f;
    }
    std::copy(grade.adjust.begin(), grade.adjust.end(), pc.colorGrade);
    render::VulkanLutStore::pushValues(grade.hasLut() ? grade.lut.get() : nullptr, grade.lutMix,
                                       pc.colorLut);
    for (const PaneDraw &d : panes) {
        if (!drawPicture)
            break;
        if (panes.size() > 1) {
            const VkViewport pv{d.x, d.y, d.w, d.h, 0.0f, 1.0f};
            vkCmdSetViewport(commandBuffer, 0, 1, &pv);
            const VkRect2D ps = paneScissor(d);
            if (ps.extent.width == 0 || ps.extent.height == 0)
                continue;
            vkCmdSetScissor(commandBuffer, 0, 1, &ps);
            pc.yaw = d.pose.yaw;
            pc.pitch = d.pose.pitch;
            pc.roll = d.pose.roll;
            pc.fovY = d.lens.fovY;
            pc.aspect = d.aspect;
            pc.distortion = d.lens.distortion;
        }
        vkCmdPushConstants(commandBuffer, imp ? m_lensPipelineLayout : m_pipelineLayout,
                           VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(PushConstants), &pc);
        vkCmdDraw(commandBuffer, 3, 1, 0, 0);
    }
    if (panes.size() > 1) { // back to the whole output rect for what's drawn over
        vkCmdSetViewport(commandBuffer, 0, 1, &viewport);
        vkCmdSetScissor(commandBuffer, 0, 1, &scissor);
    }

    // The privacy-blur region outlines, on the picture (under the insets):
    // each scissored to its own bounds, so a pass costs only its pixels.
    const auto &outlines = m_window->Outlines();
    if (m_regionPipeline && !outlines.empty()) {
        vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                      m_regionPipeline);
        const float border = 2.0f * float(m_window->devicePixelRatio());
        // Every outline in every pane, through its view, in its own rect.
        for (size_t k = 0; k < panes.size() * outlines.size(); ++k) {
            const PaneDraw &d = panes[k / outlines.size()];
            const auto &o = outlines[k % outlines.size()];
            RegionPushConstants rpc{};
            const int n = projectOutline(o, stabRm, d.pose, d.lens, d.aspect, d.w, d.h, rpc.pts);
            if (n < 3)
                continue;
            for (int i = 0; i < n; ++i) { // pane px -> output rect px
                rpc.pts[i * 2] += d.x - float(rectX);
                rpc.pts[i * 2 + 1] += d.y - float(rectY);
            }
            float lo[2] = {rpc.pts[0], rpc.pts[1]}, hi[2] = {lo[0], lo[1]};
            for (int i = 1; i < n; ++i)
                for (int k = 0; k < 2; ++k) {
                    lo[k] = std::min(lo[k], rpc.pts[i * 2 + k]);
                    hi[k] = std::max(hi[k], rpc.pts[i * 2 + k]);
                }
            const float pad = border + 1.0f;
            const VkRect2D ps = paneScissor(d);
            const int x0 = std::max(ps.offset.x - rectX, int(std::floor(lo[0] - pad)));
            const int y0 = std::max(ps.offset.y - rectY, int(std::floor(lo[1] - pad)));
            const int x1 = std::min(ps.offset.x - rectX + int(ps.extent.width),
                                    int(std::ceil(std::min(hi[0] + pad, 1e6f))));
            const int y1 = std::min(ps.offset.y - rectY + int(ps.extent.height),
                                    int(std::ceil(std::min(hi[1] + pad, 1e6f))));
            if (x1 <= x0 || y1 <= y0)
                continue;
            VkRect2D rs{};
            rs.offset.x = rectX + x0;
            rs.offset.y = rectY + y0;
            rs.extent.width = static_cast<uint32_t>(x1 - x0);
            rs.extent.height = static_cast<uint32_t>(y1 - y0);
            vkCmdSetScissor(commandBuffer, 0, 1, &rs);
            rpc.origin[0] = float(rectX);
            rpc.origin[1] = float(rectY);
            rpc.border = border;
            rpc.count = float(n);
            std::copy(o.rgb, o.rgb + 3, rpc.color);
            rpc.color[3] = 1.0f;
            vkCmdPushConstants(commandBuffer, m_regionPipelineLayout,
                                           VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(rpc), &rpc);
            vkCmdDraw(commandBuffer, 3, 1, 0, 0);
        }
        vkCmdSetScissor(commandBuffer, 0, 1, &scissor);
    }

    // The insets over the view, bottom-most first, placed in the output rect
    // exactly as the export places them (inset::place).
    bool insetBound = false;
    for (size_t i = 0; i < insets.size(); ++i) {
        const auto &d = insets[i];
        if (!insetSlots[i])
            continue; // no picture yet, or no memory for it
        const InsetSlot &slot = *insetSlots[i];
        const inset::Rect r = inset::place(d.look, d.frame, d.aspect, rectW, rectH);
        if (r.empty() || d.look.opacity <= 0.0f)
            continue;
        if (!insetBound) {
            vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                          m_insetPipeline);
            insetBound = true;
        }
        const VkDescriptorSet sets[2] = {slot.set, insetLutSets[i]};
        vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                            m_insetPipelineLayout, 0, 2, sets, 0, nullptr);
        InsetPushConstants ipc{};
        ipc.rect[0] = float(r.x);
        ipc.rect[1] = float(r.y);
        ipc.rect[2] = float(r.w);
        ipc.rect[3] = float(r.h);
        ipc.origin[0] = float(rectX);
        ipc.origin[1] = float(rectY);
        ipc.radius = float(r.radius);
        ipc.border = float(r.border);
        ipc.borderColor[0] = ((d.frame.borderRgb >> 16) & 0xff) / 255.0f;
        ipc.borderColor[1] = ((d.frame.borderRgb >> 8) & 0xff) / 255.0f;
        ipc.borderColor[2] = (d.frame.borderRgb & 0xff) / 255.0f;
        ipc.borderColor[3] = d.look.opacity;
        std::copy(d.colorGrade.adjust.begin(), d.colorGrade.adjust.end(), ipc.grade);
        render::VulkanLutStore::pushValues(d.colorGrade.hasLut() ? d.colorGrade.lut.get() : nullptr,
                                           d.colorGrade.lutMix, ipc.lut);
        vkCmdPushConstants(commandBuffer, m_insetPipelineLayout,
                                       VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(ipc), &ipc);
        vkCmdDraw(commandBuffer, 3, 1, 0, 0);
    }

    // The active pane of a split picture, outlined in the selection
    // colour (the viewport's alone: the export has no outline).
    const PaneDraw &active = panes[std::min(size_t(activePane), panes.size() - 1)];
    if (m_markerPipeline && panes.size() > 1) {
        vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, m_markerPipeline);
        MarkerPushConstants mpc{};
        mpc.rect[0] = active.x - float(rectX);
        mpc.rect[1] = active.y - float(rectY);
        mpc.rect[2] = active.w;
        mpc.rect[3] = active.h;
        mpc.origin[0] = float(rectX);
        mpc.origin[1] = float(rectY);
        mpc.border = 2.0f * float(m_window->devicePixelRatio());
        const float *col = m_window->MarkerColor(EquirectViewportWindow::MarkerStyle::Select);
        std::copy(col, col + 3, mpc.color);
        mpc.color[3] = 0.9f;
        vkCmdPushConstants(commandBuffer, m_markerPipelineLayout, VK_SHADER_STAGE_FRAGMENT_BIT, 0,
                           sizeof(mpc), &mpc);
        vkCmdDraw(commandBuffer, 3, 1, 0, 0);
    }

    // The Track subject box, over everything: fractions of the active pane.
    float marker[4];
    EquirectViewportWindow::MarkerStyle markerStyle{};
    if (m_markerPipeline && m_window->Marker(marker, &markerStyle)) {
        vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS,
                                      m_markerPipeline);
        MarkerPushConstants mpc{};
        mpc.rect[0] = active.x - float(rectX) + marker[0] * active.w;
        mpc.rect[1] = active.y - float(rectY) + marker[1] * active.h;
        mpc.rect[2] = marker[2] * active.w;
        mpc.rect[3] = marker[3] * active.h;
        mpc.origin[0] = float(rectX);
        mpc.origin[1] = float(rectY);
        mpc.border = 2.0f * float(m_window->devicePixelRatio());
        // The theme's colours while drawing, tracking, lost.
        const float *col = m_window->MarkerColor(markerStyle);
        mpc.fill = markerStyle == EquirectViewportWindow::MarkerStyle::Select ? 0.12f : 0.0f;
        mpc.color[0] = col[0];
        mpc.color[1] = col[1];
        mpc.color[2] = col[2];
        mpc.color[3] = 1.0f;
        vkCmdPushConstants(commandBuffer, m_markerPipelineLayout,
                                       VK_SHADER_STAGE_FRAGMENT_BIT, 0, sizeof(mpc), &mpc);
        vkCmdDraw(commandBuffer, 3, 1, 0, 0);
    }

    vkCmdEndRenderPass(commandBuffer);

    if (render::framestats::Enabled())
        statsFrameEnd(statsStart);
    m_window->frameReady();
    m_window->requestUpdate();
}
