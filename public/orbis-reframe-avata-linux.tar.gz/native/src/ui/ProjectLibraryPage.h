#pragma once

#include <QListWidget>
#include <QWidget>

#include <functional>

class QAction;
class QLabel;
class QPushButton;
class QStackedWidget;
class ProjectLibrary;
struct ProjectSummary;

// The cards of the project library, painted in the theme's colours.
class ProjectCardList : public QListWidget {
    Q_OBJECT

public:
    explicit ProjectCardList(QWidget *parent = nullptr);

    // Card and thumbnail size, in device-independent pixels.
    static QSize cardSize();
    static QSize thumbnailSize();
};

// The start screen: every project in the library as a card (thumbnail, name,
// when it was last opened, clip count and length, missing media), with New
// project, Open other, and per project Open / Rename / Duplicate / Show in
// file manager / Remove from list. Shown when no project is open. Reading the projects and their
// thumbnails happens on worker threads; `loaded` fires when the last arrives.
class ProjectLibraryPage : public QWidget {
    Q_OBJECT

public:
    // `library` is the app's list (owned by the caller), read on refresh().
    explicit ProjectLibraryPage(ProjectLibrary *library, QWidget *parent = nullptr);
    ~ProjectLibraryPage() override;

    // What draws a card's picture when the project starts with a flat video
    // (an .insv's comes from its trailer): a frame of `path` at `size`. Set
    // before refresh(); called on worker threads. Unset = no picture.
    using FlatThumbnailFn = std::function<QImage(const QString &path, const QSize &size)>;
    void setFlatThumbnail(FlatThumbnailFn fn) { m_flatThumbnail = std::move(fn); }

    // Re-read the library and every project in it.
    void refresh();

    // The project file of the selected card, empty if none.
    QString selectedPath() const;
    // Select the card of project file `path`, if there is one.
    void selectPath(const QString &path);

    // Asks for a project name (Rename, Duplicate): (title, current text) ->
    // the name, empty if cancelled. A dialog unless a test sets another.
    using NamePrompt = std::function<QString(const QString &title, const QString &text)>;
    void setNamePrompt(NamePrompt prompt) { m_namePrompt = std::move(prompt); }

    // Item data roles of a card.
    enum Role {
        PathRole = Qt::UserRole + 1,
        SummaryReadRole,  // bool: the summary below has arrived
        DetailsRole,      // QString: "3 clips · 4:12"
        WhenRole,         // QString: "Opened today 14:32"
        ProblemRole,      // QString: missing media / file / unreadable, empty if fine
        ThumbnailRole,    // QImage
    };

signals:
    void openRequested(const QString &path);
    void newProjectRequested();
    void openOtherRequested();
    // The projects folder changed (Change… on the page).
    void projectsFolderChanged();
    void loaded();

private:
    FlatThumbnailFn m_flatThumbnail;
    void applySummary(int generation, const ProjectSummary &summary, const QImage &thumbnail);
    void removeSelected();
    void renameSelected();
    void duplicateSelected();
    QString askName(const QString &title, const QString &text);
    void showSelectedInFileManager();
    void chooseProjectsFolder();
    void updateActions();

    ProjectLibrary *m_library;
    ProjectCardList *m_list = nullptr;
    QStackedWidget *m_body = nullptr;
    QLabel *m_folderLabel = nullptr;
    QAction *m_openAction = nullptr;
    QAction *m_showAction = nullptr;
    QAction *m_renameAction = nullptr;
    QAction *m_duplicateAction = nullptr;
    QAction *m_removeAction = nullptr;
    NamePrompt m_namePrompt;
    int m_generation = 0; // results from an older refresh() are dropped
    int m_pending = 0;
};
