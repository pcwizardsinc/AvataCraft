#include "MainWindow.h"
#include "Theme.h"

#include "AboutDialog.h"
#include "ProjectLibraryPage.h"
#include "SystemCheck.h"

#include "../core/Log.h"

#include <QAbstractSpinBox>
#include <QPlainTextEdit>
#include <QAction>
#include <QActionGroup>
#include <QApplication>
#include <QCloseEvent>
#include <QDir>
#include <QDialog>
#include <QDesktopServices>
#include <QFile>
#include <QLocale>
#include <QFileDialog>
#include <QFileInfo>
#include <QHBoxLayout>
#include <QKeyEvent>
#include <QKeySequence>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QPlatformSurfaceEvent>
#include <QSet>
#include <QSettings>
#include <QSplitter>
#include <QShortcut>
#include <QTimer>
#include <QStackedWidget>
#include <QThread>
#include <QVBoxLayout>
#include <QWidget>
#include <QWindow>

#include <algorithm>
#include <cmath>

#include <IStitchSource.h> // stitch::PreviewStitchConfig

#include "AudioPlayer.h"
#ifdef ORBIS_REFRAME_HAVE_TRACKING
#include "SubjectTrackController.h"
#endif
#ifdef ORBIS_REFRAME_HAVE_PLATE_SCAN
#include "PlateJobController.h" // ~MainWindow deletes m_plateJobs
#endif
#include "ClipMeasurements.h"
#include "ExportRunner.h"
#include "RenderJobs.h"
#include "MediaImporter.h"
#include "MediaPoolPanel.h"
#include "TitlePresets.h"
#include "TitlesPanel.h"
#include "TransitionsPanel.h"
#include "PlaybackController.h"
#include "ProjectFiles.h"
#include "ProjectSettingsDialog.h"
#include "SettingsPanel.h"
#include "SettingsSidebar.h"
#include "TabSidebar.h"
#include "TimelineWidget.h"
#include "TrackFiles.h"
#include "ThumbnailCache.h"
#include "../core/Autosave.h"
#include "WaveformCache.h"
#include "ClipFactsCache.h"
#include "TelemetryCache.h"
#include "PlayerBar.h"
#include "EditToolbar.h"
#include "UserManual.h"
#include "panels/AudioPanel.h"
#include "panels/ColourPanel.h"
#include "panels/MediaInfoPanel.h"
#include "panels/OverlayPanel.h"
#include "panels/GaugePanel.h"
#include "panels/AnimationPanel.h"
#include "panels/TitleLookPanel.h"
#include "panels/TitleTextPanel.h"
#include "panels/PrivacyPanel.h"
#include "panels/ReframePanel.h"
#include "panels/SplitScreenPanel.h"
#include "panels/StabilizationPanel.h"
#include "panels/StitchingPanel.h"
#include "../core/ClipItem.h"
#include "../core/MediaPool.h"
#include "../core/Project.h"
#include "../core/ProjectLibrary.h"
#include "../core/Timeline.h"
#include "../core/Version.h"
#include "../render/EquirectViewportWindow.h"

MainWindow::MainWindow(QVulkanInstance *vulkanInstance, ClipBackend clipBackend, QWidget *parent)
    : QMainWindow(parent), m_clipBackend(std::move(clipBackend))
{
    setWindowTitle(QStringLiteral("orbis-reframe"));

    QWidget *viewportContainer = createViewport(vulkanInstance);
    qApp->installEventFilter(this); // see eventFilter(): release text fields

    m_timelineWidget = new TimelineWidget(this);
    m_waveforms = new WaveformCache(this); // the timeline's waveforms (scanned in the background)
    m_clipFacts = new ClipFactsCache(m_clipBackend.probe, this);
    m_telemetry = new TelemetryCache({}, this);
    m_editToolbar = new EditToolbar(this);
    m_playerBar = new PlayerBar(this);

    setupModel();
    setupSourcesSidebar();
    setupLayout(viewportContainer);
    setupPages();
    setupPlayback();
    connectStitchAndStabilization();
    connectTimeline();
    connectOverlaysAndAudio();
    connectEdits();
    connectReframe();
    connectColour();
    connectMeasurements();
    connectPrivacy();
    connectTransitions();
    setupMenus();
    setupViewMenu();
    setupKeyboardShortcuts();
    connectController();
    connectPlayerBar();
    setupMediaCheck();
    connectFullScreen();

    m_playbackThread->start();
    setEditorActive(false); // the library is shown until a project opens
}

QWidget *MainWindow::createViewport(QVulkanInstance *vulkanInstance)
{
    m_viewport = new EquirectViewportWindow;
    m_viewport->setVulkanInstance(vulkanInstance);
    // Import decoded lens frames from the decoder's Vulkan device
    // (enabled only if supported; the viewport checks before using it).
    m_viewport->setDeviceExtensions({QByteArrayLiteral("VK_KHR_external_memory_fd")});
    // Once Vulkan is up: say if this GPU can't decode video or export.
    // Only the first time -- vulkanReady() repeats after a device loss.
    connect(m_viewport, &EquirectViewportWindow::vulkanReady, this,
            [this] { syscheck::warnAtStartup(this, m_viewport); }, Qt::SingleShotConnection);
    // The shaders write display-ready (gamma-encoded) colour, so the swapchain
    // must not encode it again: an *_SRGB format -- the first one a headless
    // Sway offers -- lifted every dark tone.
    m_viewport->setPreferredColorFormats({VK_FORMAT_B8G8R8A8_UNORM, VK_FORMAT_R8G8B8A8_UNORM});
    const auto viewportColors = [this] {
        const theme::Colors &tc = theme::colors();
        m_viewport->SetSurroundColor(tc.surround);
        m_viewport->SetMarkerColors(tc.accent, tc.success, tc.error);
    };
    viewportColors();
    connect(theme::notifier(), &theme::Notifier::changed, this, viewportColors);

    // Without Vulkan (tests) the viewport isn't shown -- it would only warn
    // that it can't start -- and a blank widget holds its place.
    QWidget *viewportContainer = nullptr;
    if (vulkanInstance) {
        // A viewport that can't start Vulkan stays grey for good (Qt doesn't
        // try again), so its place says why instead. Hiding the window also
        // releases what Vulkan it has.
        auto *stack = new QStackedWidget(this);
        QWidget *container = QWidget::createWindowContainer(m_viewport, stack);
        container->setFocusPolicy(Qt::StrongFocus);
        stack->addWidget(container);
        auto *failed = new QLabel(
            tr("The viewport can't show the picture: the graphics card's memory is probably "
               "full.\n\n"
               "Save the project, close other programs that use the graphics card (another "
               "orbis-reframe, games, a web browser) and start orbis-reframe again."),
            stack);
        failed->setWordWrap(true);
        failed->setAlignment(Qt::AlignCenter);
        failed->setContentsMargins(32, 32, 32, 32);
        stack->addWidget(failed);
        connect(m_viewport, &EquirectViewportWindow::vulkanFailed, stack,
                [stack, failed] { stack->setCurrentWidget(failed); });
        viewportContainer = stack;
    } else {
        m_unshownViewport.reset(m_viewport);
        viewportContainer = new QWidget(this);
        viewportContainer->setFocusPolicy(Qt::StrongFocus);
    }
    viewportContainer->setObjectName(QStringLiteral("viewport"));
    viewportContainer->setMinimumSize(320, 160);
    return viewportContainer;
}

void MainWindow::setupModel()
{
    // The edit model, owned by the GUI thread: a Project holding a Timeline.
    // The whole timeline is handed to PlaybackController as a segment list
    // (pushTimelineToController); it plays across the clips in timeline time.
    m_project = new Project(this);
    m_timeline = m_project->timeline();
    m_autosave = new Autosave(m_project, Autosave::kDefaultIntervalMs, this);
    m_measurements = new ClipMeasurements(m_project, m_clipBackend.measure, this);
    m_exports = new ExportRunner(this);
    connect(m_exports, &ExportRunner::busyChanged, this, [this] {
        updateExportEnabled();
        updateScreenshotEnabled();
    });
    connect(m_exports, &ExportRunner::stillFinished, this,
            [this](const QString &path, const QString &error) {
                if (error.isEmpty()) {
                    m_editToolbar->showNotice(tr("Saved %1").arg(QDir::toNativeSeparators(path)));
                } else {
                    m_editToolbar->showNotice(QString());
                    QMessageBox::warning(this, tr("Screenshot failed"), error);
                }
            });
    connect(m_measurements, &ClipMeasurements::statusChanged, this, [this] {
        updateSyncStatus();
        updateSeamStatus();
    });
    // More of a source's seam analysed: the frame on screen, if it is that
    // source's, is stitched again with it (playing, the next frames are).
    connect(m_measurements, &ClipMeasurements::seamAnalysed, this, [this](const QString &path) {
        const ClipItem *cur = m_timeline->clipById(m_clipId);
        if (!m_playing && cur && cur->sourcePath == path)
            QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                                      Q_ARG(qint64, m_lastTimelineMs));
    });
    // An older project's clips have their sound put on the stream tracks.
    m_project->setAudioStreamCounter([this](const QString &path) { return audioStreamCount(path); });
    connect(m_project, &Project::modifiedChanged, this, [this](bool) { updateWindowTitle(); });
    connect(m_project, &Project::filePathChanged, this, [this](const QString &) {
        updateWindowTitle();
        updateCacheDirs(m_project->filePath());
    });
    updateWindowTitle();
}

void MainWindow::setupSourcesSidebar()
{
    // The left sidebar (sources), beside the viewport: the Media tab.
    m_sourcesSidebar = new TabSidebar(TabSidebar::Side::Left, QStringLiteral("sourcesSidebar"), this);
    // Resizable (file names can be long); the width is remembered per user.
    const int sourcesWidth = std::max(280, fontMetrics().height() * 17);
    m_sourcesSidebar->setPageWidthRange(200, sourcesWidth, 900);
    m_sourcesSidebar->setPageWidth(
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .value(QStringLiteral("sidebars/sourcesWidth"), sourcesWidth)
            .toInt());
    connect(m_sourcesSidebar, &TabSidebar::pageWidthChanged, this, [](int width) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("sidebars/sourcesWidth"), width);
    });
    m_mediaPanel = new MediaPoolPanel(m_project->mediaPool());
    m_thumbnailCache = std::make_shared<ThumbnailCache>();
    m_mediaPanel->setThumbnailProvider(
        [cache = m_thumbnailCache](const MediaItem &item, const QSize &size) {
            return cache->get(item, size, &mediaThumbnail);
        });
    m_mediaPanel->setModeProvider(&mediaMode);
    m_sourcesSidebar->addTab(m_mediaPanel, QStringLiteral("film"), tr("Media"));
    m_titlesPanel = new TitlesPanel;
    m_sourcesSidebar->addTab(m_titlesPanel, QStringLiteral("shapes"), tr("Overlays"));
    connect(m_titlesPanel, &TitlesPanel::addTitleRequested, this,
            [this](const QString &presetId) { addTitle(0, m_lastTimelineMs, presetId); });
    m_transitionsPanel = new TransitionsPanel;
    m_sourcesSidebar->addTab(m_transitionsPanel, QStringLiteral("blend"), tr("Transitions"));
    m_sourcesSidebar->setToggleKeys(
        QKeySequence(Qt::CTRL | Qt::Key_B).toString(QKeySequence::NativeText));
    m_sourcesSidebar->setOpen(
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .value(QStringLiteral("sidebars/sourcesOpen"), true)
            .toBool());
    connect(m_sourcesSidebar, &TabSidebar::openChanged, this, [](bool open) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("sidebars/sourcesOpen"), open);
    });
    m_mediaImport = new MediaImporter(m_project, m_mediaPanel, m_sourcesSidebar,
                                      m_clipBackend.probe, this);
    connect(m_mediaPanel, &MediaPoolPanel::importFilesRequested, m_mediaImport,
            &MediaImporter::importFiles);
    connect(m_mediaPanel, &MediaPoolPanel::importFolderRequested, m_mediaImport,
            &MediaImporter::importFolder);
    connect(m_mediaPanel, &MediaPoolPanel::filesDropped, m_mediaImport, &MediaImporter::import);
    connect(m_mediaPanel, &MediaPoolPanel::addToTimelineRequested, this,
            &MainWindow::addMediaToTimeline);
    connect(m_mediaPanel, &MediaPoolPanel::previewRequested, this, &MainWindow::previewMedia);
    // The file previewed gone from the pool, or missing: the timeline again.
    const auto previewGone = [this] {
        const MediaItem *m = previewing() ? m_project->mediaPool()->item(m_sourcePath) : nullptr;
        if (previewing() && (!m || m->missing))
            leaveSource();
    };
    connect(m_project->mediaPool(), &MediaPool::changed, this, previewGone);
    connect(m_project->mediaPool(), &MediaPool::missingChanged, this, previewGone);
    connect(m_mediaPanel, &MediaPoolPanel::locateRequested, this, &MainWindow::locateMedia);
}

void MainWindow::setupLayout(QWidget *viewportContainer)
{
    // Top: the sources sidebar, the viewport over its player bar, and the
    // settings sidebar (below). Bottom, across the full width: the timeline
    // under its edit toolbar.
    auto *viewColumn = new QVBoxLayout;
    viewColumn->setContentsMargins(0, 0, 0, 0);
    viewColumn->setSpacing(0);
    viewColumn->addWidget(viewportContainer, 1);
    viewColumn->addWidget(m_playerBar, 0);
    auto *top = new QHBoxLayout;
    top->setContentsMargins(0, 0, 0, 0);
    top->setSpacing(0);
    top->addWidget(m_sourcesSidebar, 0);
    top->addLayout(viewColumn, 1);
    m_timelinePane = new QWidget(this);
    m_timelinePane->setObjectName(QStringLiteral("timelinePane"));
    auto *timelineLayout = new QVBoxLayout(m_timelinePane);
    timelineLayout->setContentsMargins(0, 0, 0, 0);
    timelineLayout->setSpacing(0);
    timelineLayout->addWidget(m_editToolbar, 0);
    timelineLayout->addWidget(m_timelineWidget, 1);

    // Right: the settings sidebar. Each section is wired to Project /
    // PlaybackController / the clip under the playhead below.
    m_sidebar = new SettingsSidebar(this);
    m_stitchingPanel = m_sidebar->stitching();
    m_reframePanel = m_sidebar->reframe();
    m_reframePanel->setNoClip();
    m_splitScreenPanel = m_sidebar->splitScreen();
    m_splitScreenPanel->setNoClip();
    m_stabilizationPanel = m_sidebar->stabilization();
    m_stabilizationPanel->setNoClip(); // nothing open yet
    m_stitchingPanel->setNoClip();
    m_audioPanel = m_sidebar->audio();
    m_audioPanel->setNoClip();
    m_colourPanel = m_sidebar->colour();
    m_colourPanel->setNoClip();
    m_privacyPanel = m_sidebar->privacy();         // starts in its no-clip state
    m_overlayPanel = m_sidebar->overlay();         // starts with no overlay clip
    m_overlayAnimationPanel = m_sidebar->overlayAnimation();
    m_titleTextPanel = m_sidebar->titleText();     // ... and no title
    m_titleLookPanel = m_sidebar->titleLook();
    m_titleAnimationPanel = m_sidebar->titleAnimation();
    m_titlePlacementPanel = m_sidebar->titlePlacement();
    m_transitionPanel = m_sidebar->transition();   // ... and no transition
    m_mediaInfoPanel = m_sidebar->mediaInfo();     // starts in its no-clip state
    // Open / closed, its width, its tab and which sections are open are
    // remembered per user, like the left sidebar's.
    {
        QSettings settings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"));
        m_sidebar->setPageWidth(
            settings.value(QStringLiteral("sidebars/settingsWidth"), m_sidebar->pageWidth())
                .toInt());
        m_sidebar->setOpen(settings.value(QStringLiteral("sidebars/settingsOpen"), true).toBool());
        m_sidebar->setCurrentIndex(settings.value(QStringLiteral("sidebars/settingsTab"), 0).toInt());
        for (SettingsPanel *section : m_sidebar->sections()) {
            const QString key = QStringLiteral("sidebars/sections/") + section->objectName();
            section->setExpanded(settings.value(key, section->isExpanded()).toBool());
            connect(section, &SettingsPanel::expandedToggled, this, [key](bool expanded) {
                QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
                    .setValue(key, expanded);
            });
        }
    }
    m_sidebar->setToggleKeys(
        QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_B).toString(QKeySequence::NativeText));
    connect(m_sidebar, &TabSidebar::pageWidthChanged, this, [](int width) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("sidebars/settingsWidth"), width);
    });
    connect(m_sidebar, &TabSidebar::openChanged, this, [](bool open) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("sidebars/settingsOpen"), open);
    });
    connect(m_sidebar, &TabSidebar::currentChanged, this, [](int index) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("sidebars/settingsTab"), index);
    });

    top->addWidget(m_sidebar, 0);
    auto *topPane = new QWidget(this);
    topPane->setObjectName(QStringLiteral("viewerPane"));
    topPane->setLayout(top);

    // The split between them is dragged by the user and remembered per user;
    // the first time, the timeline gets the height its tracks want.
    m_editorPage = new QSplitter(Qt::Vertical, this);
    m_editorPage->setObjectName(QStringLiteral("editorSplitter"));
    m_editorPage->setChildrenCollapsible(false);
    m_editorPage->addWidget(topPane);
    m_editorPage->addWidget(m_timelinePane);
    m_editorPage->setStretchFactor(0, 1);
    m_editorPage->setStretchFactor(1, 0);
    {
        const QByteArray state =
            QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
                .value(QStringLiteral("layout/editorSplitter"))
                .toByteArray();
        m_timelineHeightSet = !state.isEmpty() && m_editorPage->restoreState(state);
        if (!m_timelineHeightSet)
            m_editorPage->setSizes({1000, m_timelinePane->sizeHint().height()});
    }
    connect(m_editorPage, &QSplitter::splitterMoved, this, [this] {
        m_timelineHeightSet = true;
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("layout/editorSplitter"), m_editorPage->saveState());
    });
}

void MainWindow::setupPages()
{
    // The start screen (no project open) and the editor share the window.
    m_library = std::make_unique<ProjectLibrary>();
    m_files = std::make_unique<ProjectFiles>(m_project, m_library.get(), m_autosave, this);
    m_trackFiles = std::make_unique<TrackFiles>(
        m_project, [this](int clipId) { addOverlayAudio(clipId); }, this);
    m_libraryPage = new ProjectLibraryPage(m_library.get(), this);
    m_libraryPage->setFlatThumbnail([](const QString &path, const QSize &size) {
        return mediaThumbnail({path, MediaItem::Kind::Video}, size);
    });
    connect(m_libraryPage, &ProjectLibraryPage::openRequested, this, &MainWindow::openProject);
    connect(m_libraryPage, &ProjectLibraryPage::newProjectRequested, this, &MainWindow::newProject);
    connect(m_libraryPage, &ProjectLibraryPage::openOtherRequested, this,
            &MainWindow::openProjectFile);
    m_pages = new QStackedWidget(this);
    m_pages->addWidget(m_libraryPage);
    m_pages->addWidget(m_editorPage);
    m_pages->setCurrentWidget(m_libraryPage); // until a project opens (main.cpp)
    setCentralWidget(m_pages);
}

void MainWindow::makeGpuRoomForJob()
{
    QMetaObject::invokeMethod(m_controller, &PlaybackController::makeGpuRoom, true);
    m_measurements->yieldGpu();
}

void MainWindow::setupPlayback()
{
    // The controller runs on its own thread: opening a clip and its first
    // stitch block, which must not stall the GUI. No parent
    // -- ownership is handed to the thread via the finished/deleteLater wiring
    // below.
    m_controller = new PlaybackController;
    m_controller->setViewport(m_viewport);
    m_controller->setSourceFactory(m_clipBackend.makeSource);
    m_controller->setStabilizationProvider(m_stabilizers.provider());
    m_controller->setViewProvider(m_frameViews.provider());
    // The copy of every clip's reframe path and grade that presented frames
    // take their view from: refreshed with any change to them or the clips.
    const auto views = [this] { m_frameViews.update(*m_timeline); };
    connect(m_timeline, &Timeline::clipReframeChanged, this, views);
    connect(m_timeline, &Timeline::clipColorChanged, this, views);
    connect(m_timeline, &Timeline::clipInserted, this, views);
    connect(m_timeline, &Timeline::clipRemoved, this, views);
    connect(m_timeline, &Timeline::clipsReordered, this, views);
    views();
    m_playbackThread = new QThread(this);
    m_controller->moveToThread(m_playbackThread);
    connect(m_playbackThread, &QThread::finished, m_controller, &QObject::deleteLater);
    // A lens frame the viewport had no room to import: the paused frame read
    // again (queued onto the controller's thread).
    connect(m_viewport, &EquirectViewportWindow::lensFramesLost, m_controller,
            &PlaybackController::viewportLostLensFrames);

    // Audio: a slave of m_controller's clock, entirely on the GUI thread --
    // see AudioPlayer's own comment for why. A normal child, unlike
    // m_controller.
    m_audioPlayer = new AudioPlayer(this);
}

void MainWindow::connectTimeline()
{
    // View -> controller. These connections cross the thread boundary, so Qt
    // queues them onto the worker's event loop automatically.
    connect(m_playerBar, &PlayerBar::playPauseClicked,
            m_controller, &PlaybackController::togglePlay);

    // Timeline widget -> controller / model. It works entirely in timeline
    // time.
    const auto seekTo = [this](qint64 timelineMs) {
        QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                                  Q_ARG(qint64, timelineMs));
    };
    const auto scrubTo = [this](qint64 timelineMs) {
        QMetaObject::invokeMethod(m_controller, "scrub", Qt::QueuedConnection,
                                  Q_ARG(qint64, timelineMs));
    };
    // A click on the timeline shows it again, if a Media tab file was.
    connect(m_timelineWidget, &TimelineWidget::seekRequested, this, [this, seekTo](qint64 ms) {
        leaveSource();
        seekTo(ms);
    });
    connect(m_timelineWidget, &TimelineWidget::scrubRequested, this, [this, scrubTo](qint64 ms) {
        leaveSource();
        scrubTo(ms);
    });
    // The player bar's progress strip scrubs like the ruler -- in the file
    // previewed while there is one.
    connect(m_playerBar, &PlayerBar::seekRequested, this, [this, seekTo](qint64 ms) {
        if (previewing())
            QMetaObject::invokeMethod(m_controller, "seekSource", Qt::QueuedConnection,
                                      Q_ARG(qint64, ms));
        else
            seekTo(ms);
    });
    connect(m_playerBar, &PlayerBar::scrubRequested, this, [this, scrubTo](qint64 ms) {
        if (previewing())
            QMetaObject::invokeMethod(m_controller, "scrubSource", Qt::QueuedConnection,
                                      Q_ARG(qint64, ms));
        else
            scrubTo(ms);
    });
    connect(m_playerBar, &PlayerBar::backToTimelineClicked, this, &MainWindow::leaveSource);
    connect(m_timelineWidget, &TimelineWidget::clipTrimInRequested, m_timeline,
            &Timeline::setClipTrimIn);
    connect(m_timelineWidget, &TimelineWidget::clipTrimOutRequested, m_timeline,
            &Timeline::setClipTrimOut);
    connect(m_timelineWidget, &TimelineWidget::clipMoved, m_timeline, &Timeline::moveClip);
    connect(m_timelineWidget, &TimelineWidget::clipRemoveRequested, m_timeline,
            &Timeline::removeClip);
    connect(m_timelineWidget, &TimelineWidget::clipSplitRequested, this,
            [this](int id, qint64 atSourceMs) { m_timeline->splitClip(id, atSourceMs); });
    connect(m_timelineWidget, &TimelineWidget::clipDuplicateRequested, this, [this](int id) {
        if (const int copy = m_timeline->duplicateClip(id))
            selectVideoClip(copy);
    });
    connect(m_timelineWidget, &TimelineWidget::clipSpeedRequested, m_timeline,
            &Timeline::setClipSpeed);
    // Highlight marks from a dot's menu and the clip menu.
    connect(m_timelineWidget, &TimelineWidget::markDeleteRequested, m_timeline,
            &Timeline::removeClipMark);
    connect(m_timelineWidget, &TimelineWidget::markHideRequested, this,
            [this](int id, qint64 ms) { m_timeline->setClipMarkHidden(id, ms, true); });
    connect(m_timelineWidget, &TimelineWidget::hiddenMarksShowRequested, m_timeline,
            &Timeline::showClipHiddenMarks);
    connect(m_timeline, &Timeline::clipMarksChanged, this, &MainWindow::refreshTimelineWidget);

    // Extra tracks. The widget edits them through Timeline; any change
    // comes back as tracksChanged, which redraws and re-feeds the mixer.
    connect(m_timelineWidget, &TimelineWidget::trackClipSelected, this,
            &MainWindow::selectTrackClip);
    // Clicking a video clip selects it for the panels and the trim buttons,
    // without moving the playhead; 0 = back to following the playhead.
    connect(m_timelineWidget, &TimelineWidget::clipSelected, this, &MainWindow::selectVideoClip);
    // Clicking a clip, or any edit, shows the timeline again if a Media tab
    // file was shown: what's done is to the timeline.
    connect(m_timelineWidget, &TimelineWidget::clipSelected, this, &MainWindow::leaveSource);
    connect(m_timelineWidget, &TimelineWidget::trackClipSelected, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipInserted, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipRemoved, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipsReordered, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipTrimChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipReframeChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipMarksChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipFitChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipColorChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipStabilizationChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipPrivacyChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipSpeedChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipStitchChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::tracksChanged, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::transitionsChanged, this, &MainWindow::leaveSource);
    connect(m_project, &Project::projectReset, this, &MainWindow::leaveSource);
    connect(m_timeline, &Timeline::clipRemoved, this, [this](int id) {
        if (id == m_selectedClipId)
            selectVideoClip(0);
    });
    connect(m_timelineWidget, &TimelineWidget::trackClipMoved, m_timeline,
            &Timeline::moveTrackClip);
    connect(m_timelineWidget, &TimelineWidget::trackClipTrimInRequested, m_timeline,
            &Timeline::setTrackClipTrimIn);
    connect(m_timelineWidget, &TimelineWidget::trackClipTrimOutRequested, m_timeline,
            &Timeline::setTrackClipTrimOut);
    connect(m_timelineWidget, &TimelineWidget::trackClipRemoveRequested, m_timeline,
            &Timeline::removeTrackClip);
    connect(m_timelineWidget, &TimelineWidget::audioClipLinkRequested, this,
            [this](int id, bool link) {
                const TrackClip *a = m_timeline->trackClipById(id);
                if (a)
                    m_timeline->linkAudioClip(id, link ? m_timeline->linkTargetFor(*a) : 0);
            });
    connect(m_timelineWidget, &TimelineWidget::trackClipSplitRequested, this,
            [this](int id, qint64 atMs) {
                if (const int right = m_timeline->splitTrackClip(id, atMs))
                    selectTrackClip(right);
            });
    connect(m_timelineWidget, &TimelineWidget::trackMuteToggled, this, [this](int id, bool muted) {
        if (const Track *t = m_timeline->trackById(id))
            m_timeline->setTrackAudio(id, t->gainDb, muted);
    });
    connect(m_timelineWidget, &TimelineWidget::trackRemoveRequested, m_timeline,
            &Timeline::removeTrack);
    connect(m_timelineWidget, &TimelineWidget::trackRenameRequested, m_timeline,
            &Timeline::setTrackName);
    connect(m_timelineWidget, &TimelineWidget::trackMoved, m_timeline, &Timeline::moveTrack);
    // Folded sound tracks are a view setting, not part of the project (no
    // undo, no unsaved change): the main track's are remembered per user,
    // an overlay track's for this session.
    m_timelineWidget->setSoundCollapsed(
        0, QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
               .value(QStringLiteral("timeline/videoSoundFolded"), false)
               .toBool());
    connect(m_timelineWidget, &TimelineWidget::soundCollapsedToggled, this,
            [this](int videoTrackId, bool collapsed) {
                if (videoTrackId == 0)
                    QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
                        .setValue(QStringLiteral("timeline/videoSoundFolded"), collapsed);
                fitTimelineHeight();
            });
    connect(m_timelineWidget, &TimelineWidget::addClipRequested, this,
            &MainWindow::addClipToTimeline);
    connect(m_timelineWidget, &TimelineWidget::clipFilesDropped, this,
            &MainWindow::addClipFiles);
    connect(m_timelineWidget, &TimelineWidget::addAudioTrackRequested, this,
            [this] { m_timeline->addTrack(Track::Kind::Audio); });
    connect(m_timelineWidget, &TimelineWidget::addAudioFileRequested, this,
            [this](int trackId, qint64 atMs) { selectAdded(m_trackFiles->pickAudio(trackId, atMs)); });
    connect(m_timelineWidget, &TimelineWidget::audioFilesDropped, this,
            [this](const QStringList &paths, int trackId, qint64 atMs) {
                selectAdded(m_trackFiles->addAudio(paths, trackId, atMs));
            });
    // Overlay (video) tracks.
    connect(m_timelineWidget, &TimelineWidget::addVideoTrackRequested, this,
            [this] { m_timeline->addTrack(Track::Kind::Video); });
    connect(m_timelineWidget, &TimelineWidget::addVideoFileRequested, this,
            [this](int trackId, qint64 atMs) { selectAdded(m_trackFiles->pickVideo(trackId, atMs)); });
    connect(m_timelineWidget, &TimelineWidget::videoFilesDropped, this,
            [this](const QStringList &paths, int trackId, qint64 atMs) {
                selectAdded(m_trackFiles->addVideo(paths, trackId, atMs));
            });
    connect(m_timelineWidget, &TimelineWidget::titleDropped, this, &MainWindow::addTitle);
}

void MainWindow::connectOverlaysAndAudio()
{
    // Picking an inset in the view selects its clip; dragging it moves it.
    // (Not a Media tab file's picture: it isn't the timeline's.)
    connect(m_viewport, &EquirectViewportWindow::insetPressed, this, [this](int clipId) {
        if (!previewing())
            selectTrackClip(clipId);
    });
    connect(m_viewport, &EquirectViewportWindow::insetMoved, this,
            [this](int clipId, float cx, float cy) {
                const TrackClip *c = previewing() ? nullptr : m_timeline->trackClipById(clipId);
                if (!c)
                    return;
                const qint64 src = c->sourceAtLocalMs(
                    std::clamp<qint64>(m_lastTimelineMs - c->startMs, 0, c->timelineDurationMs()));
                inset::Look l = c->lookAt(src);
                l.centerX = cx;
                l.centerY = cy;
                applyInsetLook(clipId, l);
            });
    // Picture in picture tab (overlay videos) and the Overlay tab's Position and timing
    // (titles) -> the selected overlay clip. Each only ever shows its kind.
    for (OverlayPanel *panel : {m_overlayPanel, m_titlePlacementPanel}) {
        connect(panel, &OverlayPanel::lookEdited, this, [this](const inset::Look &l) {
            if (const TrackClip *c = selectedOverlayClip())
                applyInsetLook(c->id, l);
        });
        connect(panel, &OverlayPanel::frameEdited, this, [this](const inset::Frame &f) {
            if (const TrackClip *c = selectedOverlayClip())
                m_timeline->setTrackClipInset(c->id, c->look, f);
        });
        connect(panel, &OverlayPanel::timingEdited, this,
                [this](qint64 fadeInMs, qint64 fadeOutMs, qint64 startMs, qint64 spanMs) {
                    int trackId = 0;
                    const TrackClip *c = selectedOverlayClip(&trackId);
                    if (!c)
                        return;
                    const int id = c->id;
                    // The length first: the fades are clamped to it.
                    if (spanMs != c->timelineDurationMs())
                        m_timeline->setTrackClipTrimOut(id, c->trimInMs + std::llround(spanMs * c->speed));
                    m_timeline->setTrackClipFades(id, fadeInMs, fadeOutMs);
                    m_timeline->moveTrackClip(id, trackId, startMs);
                });
        connect(panel, &OverlayPanel::bringForwardRequested, this,
                [this] { moveSelectedOverlayLayer(-1); });
        connect(panel, &OverlayPanel::sendBackwardRequested, this,
                [this] { moveSelectedOverlayLayer(1); });
        connect(panel, &OverlayPanel::addKeyRequested, this,
                &MainWindow::setOverlayKeyAtPlayhead);
        connect(panel, &OverlayPanel::removeKeyRequested, this,
                &MainWindow::deleteOverlayKeyAtPlayhead);
        connect(panel, &OverlayPanel::clearKeysRequested, this,
                &MainWindow::clearOverlayKeys);
        connect(panel, &OverlayPanel::easeEdited, this, [this](keytrack::Ease e) {
            if (const TrackClip *c = selectedOverlayClip())
                m_timeline->setTrackClipInsetEase(
                    c->id, c->sourceAtLocalMs(m_lastTimelineMs - c->startMs), e);
        });
    }
    // Overlay tab's Text and Look -> the selected title. A new alignment pins
    // another point of the text: the title moves so its text stays put.
    const auto titleEdited = [this](const title::Style &t) {
        const TrackClip *c = selectedOverlayClip();
        if (!c || !c->isTitle())
            return;
        const OutputSettings &out = m_project->output();
        // Measured with the fields as they show at the playhead.
        const title::Clock clock = title::hasFields(c->title->text) || title::hasFields(t.text)
                                       ? renderjobs::titleClock(*m_timeline, fieldSources())
                                       : title::Clock();
        m_timeline->setTrackClipTitle(
            c->id, t,
            renderjobs::titleAnchorShift(*c->title, t, out.width, out.height,
                                         clock.at(m_lastTimelineMs),
                                         clock.gpsAt(m_lastTimelineMs),
                                         clock.motionAt(m_lastTimelineMs)));
    };
    connect(m_titleTextPanel, &TitleTextPanel::titleEdited, this, titleEdited);
    connect(m_titleLookPanel, &TitleLookPanel::titleEdited, this, titleEdited);
    // Either tab's Animation -> the selected overlay of its kind.
    for (AnimationPanel *panel : {m_overlayAnimationPanel, m_titleAnimationPanel}) {
        const bool drawn = panel == m_titleAnimationPanel;
        connect(panel, &AnimationPanel::motionEdited, this,
                [this, drawn](const inset::Motion &m) {
                    const TrackClip *c = selectedOverlayClip();
                    if (c && c->isDrawn() == drawn)
                        m_timeline->setTrackClipMotion(c->id, m);
                });
    }
    connect(m_sidebar->gauge(), &GaugePanel::gaugeEdited, this, [this](const gauge::Style &g) {
        const TrackClip *c = selectedOverlayClip();
        if (c && c->isGauge())
            m_timeline->setTrackClipGauge(c->id, g);
    });
    // Waveforms arrive from background scans: redraw.
    connect(m_waveforms, &WaveformCache::ready, this, &MainWindow::refreshTimelineWidget);
    // A file's guard profiles and marks read in the background: the panel
    // may show it, the timeline its marks.
    connect(m_clipFacts, &ClipFactsCache::ready, this, [this](const QString &path) {
        const ClipItem *c = m_timeline->clipById(editClipId());
        if (c && c->sourcePath == path)
            syncStitchingPanel();
        if (!m_clipFacts->highlights(path).isEmpty())
            refreshTimelineWidget();
    });
    // A file's GPS and motion read in the background: the overlays reading
    // them, and the selected one's note on where there's none.
    connect(m_telemetry, &TelemetryCache::ready, this, [this](const QString &path) {
        bool used = false;
        for (int i = 0; i < m_timeline->count() && !used; ++i)
            used = m_timeline->clipAt(i).sourcePath == path;
        if (!used)
            return;
        pushInsetsToController();
        refreshOverlayPanel();
    });
    connect(m_timelineWidget, &TimelineWidget::overlayAudioRequested, this,
            &MainWindow::putOverlayAudioOnTrack);
    connect(m_timeline, &Timeline::tracksChanged, this, &MainWindow::onTracksChanged);
    // Audio panel -> the audio clip a section shows, and its track.
    connect(m_audioPanel, &AudioPanel::audioClipEdited, this,
            [this](int id, double gainDb, bool muted, qint64 fadeInMs, qint64 fadeOutMs,
                   qint64 startMs) {
                int trackId = 0;
                if (!m_timeline->trackClipById(id, &trackId))
                    return;
                m_timeline->setAudioClipLevel(id, gainDb, muted);
                m_timeline->setTrackClipFades(id, fadeInMs, fadeOutMs);
                m_timeline->moveTrackClip(id, trackId, startMs);
            });
    connect(m_audioPanel, &AudioPanel::trackLevelEdited, m_timeline, &Timeline::setTrackAudio);
    connect(m_audioPanel, &AudioPanel::noiseEdited, m_timeline, &Timeline::setAudioClipNoise);
    connect(m_project, &Project::projectReset, this, [this] {
        selectTrackClip(-1);
        m_selectedClipId = 0; // ids don't survive a load / undo
    });
}

void MainWindow::connectEdits()
{
    // Trim from the transport buttons / [ ] shortcuts acts on the clip under
    // the playhead, at m_lastPositionMs (that clip's *source* time -- the
    // transport bar only knows timeline time). Timeline owns the clamp /
    // min-gap validation.
    connect(m_editToolbar, &EditToolbar::splitRequested, this, [this] { splitAtPlayhead(); });
    connect(m_editToolbar, &EditToolbar::trimInRequested, this,
            [this] { trimAtPlayhead(true); });
    connect(m_editToolbar, &EditToolbar::trimOutRequested, this,
            [this] { trimAtPlayhead(false); });
    connect(m_editToolbar, &EditToolbar::trimCleared, this,
            [this] { clearTrim(); });

    // Any structural or trim change to the timeline -> rebuild the controller's
    // segments and repaint the widget, then keep the playhead on the same
    // source frame it was showing: its timeline position moves when its
    // own trim-in shifts, or when an earlier clip's length changes.
    connect(m_timeline, &Timeline::clipTrimChanged, this, [this](int, qint64, qint64) {
        remapPlayheadAfterEdit();
    });
    connect(m_timeline, &Timeline::clipInserted, this, [this](int) { remapPlayheadAfterEdit(); });
    connect(m_timeline, &Timeline::clipRemoved, this, [this](int) { remapPlayheadAfterEdit(); });
    connect(m_timeline, &Timeline::clipsReordered, this, [this] { remapPlayheadAfterEdit(); });
    connect(m_timeline, &Timeline::clipSpeedChanged, this,
            [this](int, double) { remapPlayheadAfterEdit(); });
    connect(m_timeline, &Timeline::clipFitChanged, this, [this](int id, ClipItem::Fit fit) {
        pushInsetsToController();
        if (id == editClipId())
            m_reframePanel->setClip(true, fit == ClipItem::Fit::Fill);
    });
}

void MainWindow::connectReframe()
{
    // Reframe authoring. The viewport is a dumb pose display + input device; this
    // window is the only thing that knows both the playhead and the Timeline.
    //  * arm toggle gates whether a look gesture writes a keyframe;
    //  * a finished drag / a zoom notch (lookCommitted) writes one at the
    //    playhead when armed;
    //  * during a drag we stop pushing the sampled pose so the path doesn't
    //    fight the user's hand.
    connect(m_editToolbar, &EditToolbar::reframeArmedChanged, this,
            [this](bool armed) { m_reframeArmed = armed; });
    connect(m_viewport, &EquirectViewportWindow::draggingChanged, this,
            [this](bool active) {
                m_viewportDragging = active;
                m_frameViews.setDragging(active);
            });
    connect(m_viewport, &EquirectViewportWindow::lookCommitted, this, [this] {
        if (previewing()) // only looking around in a Media tab file
            return;
        if (m_reframeArmed && m_clipId)
            m_timeline->upsertClipReframeKey(
                m_clipId, m_lastPositionMs, m_viewport->Pose(), playingPane());
        syncReframePanel(); // the drag / zoom moved the pose
    });
    // Split screen: a click on another pane steers it from now on.
    connect(m_viewport, &EquirectViewportWindow::activePaneChanged, this,
            &MainWindow::setActivePane);
    connect(m_reframePanel, &ReframePanel::activePaneEdited, this, &MainWindow::setActivePane);
    connect(m_splitScreenPanel, &SplitScreenPanel::splitEdited, this,
            [this](const pane::Split &split) {
                const ClipItem *c = m_timeline->clipById(editClipId());
                if (!c || c->flat)
                    return;
                // Panes a layout brings in without a camera of their own yet look
                // the way Fill panes points them, from pane 1's view at the playhead.
                std::vector<Timeline::PanePose> keys;
                const qint64 at = c->id == m_clipId ? m_lastPositionMs : c->trimInMs;
                view::Pose poses[pane::kMaxPanes];
                m_viewport->PanePoses(poses);
                const ReframePose base =
                    c->id == m_clipId ? poses[0] : c->reframe.sample(at);
                for (const Timeline::PanePose &k : fillPoses(split, base))
                    if (c->paneTrack(k.first).isEmpty())
                        keys.push_back(k);
                m_timeline->setClipSplit(c->id, split, at, &keys);
            });
    connect(m_splitScreenPanel, &SplitScreenPanel::fillPanesRequested, this,
            &MainWindow::fillPanes);

    // Reframe panel: a numeric edit sets the live viewport pose and, when
    // authoring is armed, keyframes it at the playhead -- same as a drag.
    connect(m_reframePanel, &ReframePanel::fitEdited, this, [this](bool fill) {
        m_timeline->setClipFit(editClipId(), fill ? ClipItem::Fit::Fill : ClipItem::Fit::Bars);
    });
    connect(m_reframePanel, &ReframePanel::poseEdited, this, [this](const ReframePose &p) {
        m_viewport->SetPose(p);
        if (m_reframeArmed && m_clipId)
            m_timeline->upsertClipReframeKey(m_clipId, m_lastPositionMs, p, playingPane());
    });
    // Easing needs no arming: it changes keys already there, not the path's
    // points.
    connect(m_reframePanel, &ReframePanel::easeEdited, this, [this](keytrack::Ease e) {
        if (m_clipId)
            m_timeline->setClipReframeEase(m_clipId, m_lastPositionMs, e, playingPane());
    });
    // Track subject: the panel arms a box select in the viewport; a drawn box
    // starts tracking from the playhead.
    m_reframePanel->setTrackUnavailable(syscheck::trackUnavailableReason());
#ifdef ORBIS_REFRAME_HAVE_TRACKING
    connect(m_reframePanel, &ReframePanel::trackSubjectToggled, this,
            &MainWindow::setTrackSelecting);
    m_tracker = new SubjectTrackController(m_viewport, m_reframePanel->trackStopButton(), this);
    connect(m_reframePanel, &ReframePanel::trackStopRequested, m_tracker,
            &SubjectTrackController::stop);
    connect(m_tracker, &SubjectTrackController::progress, this, [this](qint64 ms, qint64 lostFor) {
        const SubjectTrackController::Run &run = m_tracker->run();
        const int idx = m_timeline->indexOfId(run.clipId);
        if (idx >= 0)
            showPlayhead(
                m_timeline->clipToTimeline(idx, m_timeline->clipAt(idx).localAtSourceMs(ms)));
        const QString t = QString::number((ms - run.req.fromMs) / 1000.0, 'f', 1);
        m_reframePanel->setTrackStatus(
            lostFor < 0 ? tr("%1 s tracked. Following the subject.").arg(t)
                        : tr("%1 s. Lost the subject %2 s ago; stopping keeps the path up to "
                             "where it was last seen.")
                              .arg(t)
                              .arg(lostFor / 1000.0, 0, 'f', 1));
    });
    connect(m_tracker, &SubjectTrackController::finished, this, &MainWindow::finishSubjectTracking);
#endif
    // The viewport's box select serves Track subject and "Blur a plate…".
    connect(m_viewport, &EquirectViewportWindow::boxSelected, this, [this](const QRectF &box) {
        if (m_plateSelecting)
            startPlateFollow(box);
        else
            startSubjectTracking(box);
    });
    connect(m_viewport, &EquirectViewportWindow::boxSelectCanceled, this, [this] {
        if (m_plateSelecting)
            setPlateSelecting(false);
        else
            setTrackSelecting(false);
    });
    connect(m_editToolbar, &EditToolbar::zoomOutRequested, m_timelineWidget,
            &TimelineWidget::zoomOut);
    connect(m_editToolbar, &EditToolbar::zoomToFitRequested, m_timelineWidget,
            &TimelineWidget::zoomToFit);
    connect(m_editToolbar, &EditToolbar::zoomInRequested, m_timelineWidget,
            &TimelineWidget::zoomIn);
    connect(m_editToolbar, &EditToolbar::deleteKeyRequested, this, [this] {
        if (m_clipId)
            m_timeline->removeClipReframeKeyNear(m_clipId, m_lastPositionMs, playingPane());
    });
    connect(m_editToolbar, &EditToolbar::clearReframeRequested, this, [this] {
        if (m_clipId)
            m_timeline->clearClipReframe(m_clipId, playingPane());
    });
    connect(m_timeline, &Timeline::clipReframeChanged, this, [this](int id) {
        refreshTimelineWidget(); // re-draw the keyframe diamonds
        if (id == m_clipId) {
            if (!m_viewportDragging)
                applySampledPose(m_lastPositionMs); // reflect an edit/delete at once
            syncReframePanel();
        }
        if (id == editClipId())
            if (const ClipItem *c = m_timeline->clipById(id)) {
                m_reframePanel->setPaneLayout(c->split.layout);
                m_splitScreenPanel->setSplit(c->split);
            }
    });
}

void MainWindow::setupMenus()
{
    QMenu *fileMenu = menuBar()->addMenu(tr("&File"));
    QAction *newProjectAction =
        fileMenu->addAction(tr("&New project…"), this, &MainWindow::newProject);
    newProjectAction->setObjectName(QStringLiteral("newProjectAction"));
    newProjectAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_N));
    newProjectAction->setIcon(theme::icon(QStringLiteral("file-plus-2")));
    QAction *openProjectAction =
        fileMenu->addAction(tr("&Open project…"), this, &MainWindow::openProjectFile);
    openProjectAction->setObjectName(QStringLiteral("openProjectAction"));
    openProjectAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_O));
    openProjectAction->setIcon(theme::icon(QStringLiteral("folder-open")));
    QAction *libraryAction =
        fileMenu->addAction(tr("Project &library…"), this, &MainWindow::closeToLibrary);
    libraryAction->setObjectName(QStringLiteral("projectLibraryAction"));
    libraryAction->setIcon(theme::icon(QStringLiteral("layers")));
    fileMenu->addSeparator();
    QAction *saveProjectAction =
        fileMenu->addAction(tr("&Save project"), this, [this] { m_files->save(); });
    saveProjectAction->setObjectName(QStringLiteral("saveProjectAction"));
    saveProjectAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_S));
    saveProjectAction->setIcon(theme::icon(QStringLiteral("save")));
    QAction *saveProjectAsAction =
        fileMenu->addAction(tr("Save project &as…"), this, [this] { m_files->saveAs(m_clipPath); });
    saveProjectAsAction->setObjectName(QStringLiteral("saveProjectAsAction"));
    saveProjectAsAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_S));
    // Their own enabled state (a clip open, undo history) is already off
    // while no project is open; these would act on the hidden editor.
    m_editorActions = {libraryAction, saveProjectAction, saveProjectAsAction};
    fileMenu->addSeparator();
    QAction *projectSettingsAction = fileMenu->addAction(tr("Project se&ttings…"), this,
                                                         &MainWindow::editProjectSettings);
    projectSettingsAction->setObjectName(QStringLiteral("projectSettingsAction"));
    projectSettingsAction->setIcon(theme::icon(QStringLiteral("clapperboard")));
    m_editorActions += projectSettingsAction;
    fileMenu->addSeparator();

    // File -> Export flat video… (disabled until a clip is open).
    m_exportAction = fileMenu->addAction(tr("&Export flat video…"), this,
                                        &MainWindow::exportFlatVideo);
    m_exportAction->setObjectName(QStringLiteral("exportAction"));
    m_exportAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_E));
    m_exportAction->setIcon(theme::icon(QStringLiteral("upload")));
    m_exportAction->setEnabled(false);

    // Save screenshot: the player bar's button and Ctrl+Shift+P, in no menu
    // -- a window-level action (listed under Playback in the shortcut help).
    m_screenshotAction = new QAction(tr("Save &screenshot"), this);
    m_screenshotAction->setObjectName(QStringLiteral("screenshotAction"));
    m_screenshotAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_P));
    m_screenshotAction->setShortcutContext(Qt::ApplicationShortcut);
    m_screenshotAction->setEnabled(false);
    connect(m_screenshotAction, &QAction::triggered, this, &MainWindow::takeScreenshot);
    addAction(m_screenshotAction);
    connect(m_playerBar, &PlayerBar::screenshotRequested, this, &MainWindow::takeScreenshot);

    fileMenu->addSeparator();
    // close() runs closeEvent() -> m_files->confirmDiscard(), so an unsaved
    // project still prompts before the app exits.
    QAction *quitAction = fileMenu->addAction(tr("&Quit"), this, &QWidget::close);
    quitAction->setObjectName(QStringLiteral("quitAction"));
    quitAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_Q));
    quitAction->setMenuRole(QAction::QuitRole);

    // Edit -> Undo/Redo. Project::undo()/redo() operate on whole-project
    // snapshots coalesced by a settle timer (see Project.cpp) -- there's no
    // per-action label, so these are just "Undo"/"Redo".
    QMenu *editMenu = menuBar()->addMenu(tr("&Edit"));
    m_undoAction = editMenu->addAction(tr("&Undo"), this, &MainWindow::undo);
    m_undoAction->setObjectName(QStringLiteral("undoAction"));
    m_undoAction->setShortcut(QKeySequence::Undo);
    m_undoAction->setEnabled(m_project->canUndo());
    m_redoAction = editMenu->addAction(tr("&Redo"), this, &MainWindow::redo);
    m_redoAction->setObjectName(QStringLiteral("redoAction"));
    m_redoAction->setShortcut(QKeySequence::Redo);
    m_redoAction->setEnabled(m_project->canRedo());
    connect(m_project, &Project::canUndoChanged, m_undoAction, &QAction::setEnabled);
    connect(m_project, &Project::canRedoChanged, m_redoAction, &QAction::setEnabled);
    // Highlight marks at the playhead, on the clip under it. Application-wide
    // like the editor's other single keys (the viewport is its own window).
    editMenu->addSeparator();
    m_addMarkAction = editMenu->addAction(tr("Add &mark"), this, &MainWindow::addMarkAtPlayhead);
    m_addMarkAction->setObjectName(QStringLiteral("addMarkAction"));
    m_addMarkAction->setShortcut(QKeySequence(Qt::Key_M));
    m_addMarkAction->setShortcutContext(Qt::ApplicationShortcut);
    m_deleteMarkAction =
        editMenu->addAction(tr("&Delete mark"), this, &MainWindow::deleteMarkAtPlayhead);
    m_deleteMarkAction->setObjectName(QStringLiteral("deleteMarkAction"));
    m_deleteMarkAction->setShortcut(QKeySequence(Qt::SHIFT | Qt::Key_M));
    m_deleteMarkAction->setShortcutContext(Qt::ApplicationShortcut);
    m_editorActions += {m_addMarkAction, m_deleteMarkAction};

    // Media: into the project's media (the Media tab), or straight onto the
    // timeline.
    QMenu *mediaMenu = menuBar()->addMenu(tr("&Media"));
    QAction *importFilesAction =
        mediaMenu->addAction(tr("&Import files…"), m_mediaImport, &MediaImporter::importFiles);
    importFilesAction->setObjectName(QStringLiteral("importFilesAction"));
    importFilesAction->setShortcut(QKeySequence(Qt::CTRL | Qt::Key_I));
    importFilesAction->setIcon(theme::icon(QStringLiteral("file-plus-2")));
    QAction *importFolderAction =
        mediaMenu->addAction(tr("Import &folder…"), m_mediaImport, &MediaImporter::importFolder);
    importFolderAction->setObjectName(QStringLiteral("importFolderAction"));
    importFolderAction->setIcon(theme::icon(QStringLiteral("folder-plus")));
    mediaMenu->addSeparator();
    QAction *addClipAction =
        mediaMenu->addAction(tr("&Add clip to timeline…"), this, [this] { addClipToTimeline(); });
    addClipAction->setObjectName(QStringLiteral("addClipAction"));
    addClipAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_A));
    QAction *addAudioAction = mediaMenu->addAction(
        tr("Add a&udio file…"), this, [this] { selectAdded(m_trackFiles->pickAudio(0, m_lastTimelineMs)); });
    addAudioAction->setObjectName(QStringLiteral("addAudioAction"));
    addAudioAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_M));
    QAction *addVideoAction = mediaMenu->addAction(
        tr("Add &picture in picture…"), this, [this] { selectAdded(m_trackFiles->pickVideo(0, m_lastTimelineMs)); });
    addVideoAction->setObjectName(QStringLiteral("addVideoAction"));
    addVideoAction->setShortcut(QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_V));
    addVideoAction->setIcon(theme::icon(QStringLiteral("picture-in-picture-2")));
    mediaMenu->addSeparator();
    QAction *addAudioTrackAction = mediaMenu->addAction(
        tr("Add audio &track"), this, [this] { m_timeline->addTrack(Track::Kind::Audio); });
    addAudioTrackAction->setObjectName(QStringLiteral("addAudioTrackAction"));
    QAction *addOverlayTrackAction = mediaMenu->addAction(
        tr("Add &overlay track"), this, [this] { m_timeline->addTrack(Track::Kind::Video); });
    addOverlayTrackAction->setObjectName(QStringLiteral("addOverlayTrackAction"));
    m_editorActions += {importFilesAction, importFolderAction, addClipAction, addAudioAction,
                        addVideoAction, addAudioTrackAction, addOverlayTrackAction};
    // About the camera, not a project: there in the project library too.
    mediaMenu->addSeparator();
    QAction *calibrateAction = mediaMenu->addAction(tr("&Calibrate camera lenses…"), this,
                                                    &MainWindow::openLensCalibration);
    calibrateAction->setObjectName(QStringLiteral("calibrateLensesAction"));
#ifndef ORBIS_REFRAME_HAVE_LENS_CALIBRATION
    calibrateAction->setEnabled(false);
#endif
}

void MainWindow::connectController()
{
    // Controller -> view.
    connect(m_controller, &PlaybackController::durationChanged, m_playerBar,
            &PlayerBar::setDuration);
    connect(m_controller, &PlaybackController::openFailed, this,
            [this](const QString &path, int clipId, const QString &error) {
                // Named by its clip as well as its file: two clips cut from
                // one recording share the file name.
                QString what = QFileInfo(path).fileName();
                if (const int i = m_timeline->indexOfId(clipId); i >= 0)
                    what = tr("%1 (clip %2)").arg(what).arg(i + 1);
                // A file that's gone is the missing-media marks' to report
                // (found here too if it went since the last check): a line,
                // not a dialog on top of the missing-media warning.
                // For a take, any of its files (a ONE X2 clip's lens-1 file).
                const MediaItem *item = m_project->mediaPool()->item(path);
                const QString gone = item ? media::firstMissingFile(*item)
                                          : QFileInfo::exists(path) ? QString() : path;
                if (!gone.isEmpty()) {
                    recheckMissingMedia();
                    m_editToolbar->showNotice(
                        gone == path ? tr("Can't play %1: the file is missing").arg(what)
                                     : tr("Can't play %1: %2 is missing")
                                           .arg(what, QFileInfo(gone).fileName()));
                    return;
                }
                // The decoder's own words are for a bug report, not the
                // first thing the user reads.
                QMessageBox box(QMessageBox::Warning, tr("Playback error"),
                                tr("Can't play %1: the file can't be read.").arg(what),
                                QMessageBox::Ok, this);
                box.setDetailedText(error);
                box.exec();
            });
    // A clip that plays on the CPU because the GPU part didn't start: said
    // once per file, or a stutter looks like a bug. Short, to fit the
    // toolbar; what to do is in the manual, the details in the log.
    connect(m_controller, &PlaybackController::gpuFallback, this,
            [this](const QString &path, int clipId, bool decode, bool stitch,
                   const QString &codec) {
                if (m_gpuFallbackNoticed.contains(path))
                    return;
                m_gpuFallbackNoticed.insert(path);
                const int i = m_timeline->indexOfId(clipId);
                const QString what =
                    i >= 0 ? tr("Clip %1").arg(i + 1) : QFileInfo(path).fileName();
                m_editToolbar->showNotice(syscheck::gpuFallbackNotice(what, decode, stitch, codec));
            });
    // The audio follows the seeks the controller has applied, not the
    // requests: the controller runs on its own thread, and ticks it queued
    // before taking a seek still carry the old position -- had the audio
    // seeked at the request, the next of those would read as a jump back.
    connect(m_controller, &PlaybackController::seeked, m_audioPlayer, &AudioPlayer::seek);
    connect(m_controller, &PlaybackController::sourceShownChanged, this,
            [this](bool shown) { m_positionsAreSource = shown; });
    connect(m_controller, &PlaybackController::positionChanged, this,
            [this](qint64 timelineMs, qint64 atNs) {
                if (m_positionsAreSource) { // a Media tab file's (showSource)
                    m_sourcePositionMs = timelineMs;
                    m_playerBar->setPosition(timelineMs);
                    m_audioPlayer->notePlaybackPosition(timelineMs, atNs);
                    return;
                }
                m_lastTimelineMs = timelineMs;
                showPlayhead(timelineMs);
                m_audioPlayer->notePlaybackPosition(timelineMs, atNs);
                bindActiveClipAt(timelineMs);
                if (selectedOverlayClip())
                    refreshOverlayPanel(); // keyed values / key buttons follow the playhead
            });
    connect(m_controller, &PlaybackController::playingChanged,
            m_playerBar, &PlayerBar::setPlaying);
    connect(m_controller, &PlaybackController::scrubbingChanged, m_measurements,
            &ClipMeasurements::setScrubbing);
    connect(m_measurements, &ClipMeasurements::gpuRoomWanted, m_controller,
            [this] { m_controller->makeGpuRoom(false); });
    connect(m_controller, &PlaybackController::playingChanged, this, [this](bool playing) {
        m_playing = playing;
        if (previewing())
            m_mediaPanel->setPreview(m_sourcePath, playing);
        m_measurements->setPlaying(playing);
        if (playing)
            return;
        if (m_measuredWhilePlaying) { // results held back while playing
            m_measuredWhilePlaying = false;
            pushSeamCorrection();
            ensureStabilizers();
            applyStabilization(m_lastPositionMs);
            updateSyncStatus();
            QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                                      Q_ARG(qint64, m_lastTimelineMs)); // re-stitch
        }
    });
    connect(m_timeline, &Timeline::clipInserted, m_measurements, &ClipMeasurements::schedule);
    // A trim moves the stretch of the source whose seam is analysed.
    connect(m_timeline, &Timeline::clipTrimChanged, m_measurements, &ClipMeasurements::schedule);
    connect(m_controller, &PlaybackController::bufferingChanged,
            m_playerBar, &PlayerBar::setBuffering);
    // Every play/pause entry point (transport button, Space, export pausing
    // playback, reaching end-of-timeline) funnels through this one signal.
    // Off 1x the preview is silent (the player bar's speed).
    connect(m_controller, &PlaybackController::playingChanged, this, [this](bool playing) {
        if (playing && m_previewRate == 1.0)
            m_audioPlayer->play();
        else
            m_audioPlayer->pause();
        // Said once, where the user is looking when they expect sound; the
        // reason is in the log and Help > About.
        if (playing && !m_audioPlayer->hasOutput() && !m_noSoundNoticeShown) {
            m_noSoundNoticeShown = true;
            m_editToolbar->showNotice(tr("No sound output found — playing without sound"));
        }
    });
    // Hold the audio exactly while the video clock is frozen (a seek / stall)
    // so the two resume in step. Not bufferingChanged: that also fires
    // on ticks that merely find the queue empty while the clock runs on, and
    // holding the audio then chopped it for a second after every seek.
    connect(m_controller, &PlaybackController::clockHeldChanged, m_audioPlayer,
            &AudioPlayer::setHold);
}

void MainWindow::connectPlayerBar()
{
    // The player bar's speed and volume.
    connect(m_playerBar, &PlayerBar::speedChanged, this, [this](double speed) {
        m_previewRate = speed;
        QMetaObject::invokeMethod(m_controller, [ctrl = m_controller, speed] { ctrl->setRate(speed); });
        if (m_playing) {
            if (speed == 1.0) {
                m_audioPlayer->seek(m_lastTimelineMs);
                m_audioPlayer->play();
            } else {
                m_audioPlayer->pause();
            }
        }
    });
    {
        QSettings settings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"));
        m_playerBar->setVolume(settings.value(QStringLiteral("player/volume"), 100).toInt());
        m_playerBar->setMuted(settings.value(QStringLiteral("player/muted"), false).toBool());
    }
    applyPreviewVolume();
    connect(m_playerBar, &PlayerBar::volumeChanged, this, [this](int percent) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("player/volume"), percent);
        applyPreviewVolume();
    });
    connect(m_playerBar, &PlayerBar::mutedChanged, this, [this](bool muted) {
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("player/muted"), muted);
        applyPreviewVolume();
    });
}

void MainWindow::setupMediaCheck()
{
    // Files going missing or coming back while the app runs: looked for every
    // 2 s while it's in front, and at once when it comes back to the front.
    m_mediaCheck = new QTimer(this);
    m_mediaCheck->setInterval(2000);
    connect(m_mediaCheck, &QTimer::timeout, this, &MainWindow::recheckMissingMedia);
    connect(qApp, &QGuiApplication::applicationStateChanged, this,
            [this](Qt::ApplicationState state) {
                if (state == Qt::ApplicationActive) {
                    recheckMissingMedia();
                    m_mediaCheck->start();
                } else {
                    m_mediaCheck->stop();
                }
            });
    if (QGuiApplication::applicationState() == Qt::ApplicationActive)
        m_mediaCheck->start();
}

void MainWindow::connectFullScreen()
{
    // Full screen (the player bar's button, a double-click on the picture):
    // the player bar hides while the mouse rests.
    m_playerBarHide = new QTimer(this);
    m_playerBarHide->setSingleShot(true);
    m_playerBarHide->setInterval(2500);
    connect(m_playerBarHide, &QTimer::timeout, this, [this] {
        // Not while the mouse is on it (or a time is being typed).
        if (!m_fullScreen)
            return;
        if (m_playerBar->underMouse() || m_playerBar->isAncestorOf(QApplication::focusWidget()))
            m_playerBarHide->start();
        else
            m_playerBar->setVisible(false);
    });
    connect(m_playerBar, &PlayerBar::fullScreenClicked, this,
            [this] { setFullScreenView(!m_fullScreen); });
    connect(m_viewport, &EquirectViewportWindow::doubleClicked, this,
            [this] { setFullScreenView(!m_fullScreen); });
    connect(m_project, &Project::outputChanged, this, [this] { updatePlayerBar(); });
}

MainWindow::~MainWindow()
{
    delete m_measurements; // waits for a running one
    m_measurements = nullptr;
    delete m_exports; // waits for a screenshot being saved
    m_exports = nullptr;
    // Background jobs that stitch and draw into the viewport: stopped and
    // waited for while the viewport is still there.
#ifdef ORBIS_REFRAME_HAVE_PLATE_SCAN
    delete m_plateJobs;
    m_plateJobs = nullptr;
#endif
#ifdef ORBIS_REFRAME_HAVE_TRACKING
    delete m_tracker;
    m_tracker = nullptr;
#endif
    m_playbackThread->quit();
    m_playbackThread->wait();
    m_unshownViewport.reset(); // its users are gone
}

namespace {

// A widget that takes typed text, so it swallows the editor's single-key
// shortcuts while focused. Spin boxes report themselves as the focus widget,
// not their inner QLineEdit.
bool isTextEntry(const QWidget *w)
{
    return qobject_cast<const QAbstractSpinBox *>(w) || qobject_cast<const QLineEdit *>(w) ||
           qobject_cast<const QPlainTextEdit *>(w); // a title's text
}

// A title as the timeline and the Overlay tab name it: its first line.
QString titleLabel(const title::Style &t)
{
    const QString first = t.text.trimmed().section(QLatin1Char('\n'), 0, 0).trimmed();
    return first.isEmpty() ? MainWindow::tr("(empty title)") : first;
}

// A gauge as they name it: what it shows, and how.
QString gaugeLabel(const gauge::Style &g)
{
    switch (g.kind) {
    case gauge::Kind::Tape: return MainWindow::tr("Heading tape");
    case gauge::Kind::Lean: return MainWindow::tr("Lean dial");
    case gauge::Kind::GForce: return MainWindow::tr("G circle");
    case gauge::Kind::Route: return MainWindow::tr("Route");
    case gauge::Kind::Dial:
    case gauge::Kind::Bar: break;
    }
    const bool speed = g.reads == gauge::Reads::Speed;
    return g.kind == gauge::Kind::Dial
               ? (speed ? MainWindow::tr("Speed dial") : MainWindow::tr("Altitude dial"))
               : (speed ? MainWindow::tr("Speed bar") : MainWindow::tr("Altitude bar"));
}

// An overlay clip's name on the timeline and in the panels.
QString overlayLabel(const TrackClip &c)
{
    return c.isTitle()   ? titleLabel(*c.title)
           : c.isGauge() ? gaugeLabel(*c.gauge)
                         : QFileInfo(c.sourcePath).fileName();
}

} // namespace

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (m_fullScreen && event->type() == QEvent::MouseMove)
        showPlayerBarForAWhile();

    // Only the editor's own fields: a dialog's keep Enter (its default
    // button) and their focus.
    QWidget *fw = QApplication::focusWidget();
    if (!isTextEntry(fw) || fw->window() != this)
        return QMainWindow::eventFilter(watched, event);

    switch (event->type()) {
    case QEvent::MouseButtonPress: {
        // Presses also arrive at the top-level QWindow before its widgets --
        // ignore those; the only bare QWindow that matters is the viewport.
        bool outside = false;
        if (watched == m_viewport) {
            outside = true;
        } else if (auto *w = qobject_cast<QWidget *>(watched)) {
            // Clicking the field itself (text, arrows) keeps it; clicking
            // another text field moves focus there on its own.
            bool inEntry = false;
            for (QWidget *p = w; p && !inEntry; p = p->parentWidget())
                inEntry = p == fw || isTextEntry(p);
            outside = !inEntry;
        }
        if (outside)
            fw->clearFocus();
        break;
    }
    case QEvent::ShortcutOverride:
        // A field keeps its own editing keys -- arrows, Home / End, Delete,
        // Backspace, Escape -- over the editor's unmodified shortcuts (a
        // spin box doesn't claim Up / Down itself). Ctrl / Alt ones still
        // reach the shortcuts.
        if (watched == fw) {
            const auto *ke = static_cast<QKeyEvent *>(event);
            if (!(ke->modifiers() & (Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier))) {
                event->accept();
                return true;
            }
        }
        break;
    case QEvent::KeyPress:
        // A field that handles Enter / Escape itself (the timeline's rename box).
        if (watched == fw && !fw->property("ownsReturnEscape").toBool()) {
            const int key = static_cast<QKeyEvent *>(event)->key();
            if (key == Qt::Key_Return || key == Qt::Key_Enter || key == Qt::Key_Escape) {
                fw->clearFocus();
                return true;
            }
        }
        break;
    default:
        break;
    }
    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (m_files->confirmDiscard()) {
        // Let the viewport release its swapchain while it's still shown.
        // Closing destroys the window, which hides it first and only then
        // tells QVulkanWindow (SurfaceAboutToBeDestroyed); with Qt 6.8 on
        // Wayland (Debian 13) the NVIDIA driver crashes destroying a swapchain
        // whose window is already hidden. Releasing twice is harmless.
        QPlatformSurfaceEvent aboutToGo(QPlatformSurfaceEvent::SurfaceAboutToBeDestroyed);
        QCoreApplication::sendEvent(m_viewport, &aboutToGo);
        event->accept();
    } else
        event->ignore();
}

void MainWindow::applySampledPose(qint64 sourceMs, bool clipChanged)
{
    const ClipItem *c = m_timeline->clipById(m_clipId);
    if (!c)
        return;
    // Every pane's view as it exports, the split first: the active pane is
    // the window's own pose, set after it.
    view::Pose poses[pane::kMaxPanes];
    for (int i = 0; i < c->paneCount(); ++i) {
        const ReframeTrack &t = c->paneTrack(i);
        poses[i] = t.isEmpty() ? ReframePose{} : t.sample(sourceMs);
    }
    m_viewport->SetPanes(c->flat ? pane::Split{} : c->split, poses);
    if (m_viewportDragging)
        return;
    const ReframeTrack &active = c->paneTrack(paneOf(*c));
    if (!active.isEmpty())
        m_viewport->SetPose(active.sample(sourceMs));
    else if (clipChanged)
        m_viewport->SetPose(ReframePose{});
    // else free look
}

int MainWindow::paneOf(const ClipItem &c) const
{
    const int pane = m_viewport->ActivePane();
    return pane < c.paneCount() ? pane : 0;
}

int MainWindow::playingPane() const
{
    const ClipItem *c = m_timeline->clipById(m_clipId);
    return c ? paneOf(*c) : 0;
}

void MainWindow::setActivePane(int pane)
{
    m_viewport->SetActivePane(pane); // a click there has done it already
    m_frameViews.setActivePane(m_viewport->ActivePane());
    m_reframePanel->setActivePane(m_viewport->ActivePane());
    refreshTimelineWidget(); // that pane's keyframe diamonds
    if (!m_playing)
        applySampledPose(m_lastPositionMs);
    syncReframePanel();
}

std::vector<Timeline::PanePose> MainWindow::fillPoses(const pane::Split &split,
                                                      const ReframePose &base) const
{
    int outW = 0, outH = 0;
    m_viewport->OutputSize(outW, outH);
    const std::vector<pane::Rect> rects = pane::rects(split, outW, outH);
    std::vector<Timeline::PanePose> keys;
    for (int i = 1; i < split.count() && i < static_cast<int>(rects.size()); ++i) {
        ReframePose p = base;
        p.yaw = base.yaw + pane::fillYawOffset(split.layout, i);
        // 90 degrees across (rectilinear), within what the view allows.
        p.fov = std::clamp(pane::fovFor(std::numbers::pi / 2.0, rects[size_t(i)].aspect()),
                           view::kMinFov, view::maxFov(p));
        keys.push_back({i, p});
    }
    return keys;
}

void MainWindow::fillPanes()
{
    const ClipItem *c = m_timeline->clipById(m_clipId);
    if (!c || c->flat || !c->split.isSplit())
        return;
    view::Pose poses[pane::kMaxPanes];
    m_viewport->PanePoses(poses);
    const ReframePose base = poses[0];
    std::vector<Timeline::PanePose> keys = fillPoses(c->split, base);
    keys.insert(keys.begin(), {0, base}); // pane 1 keeps its view, keyed too
    m_timeline->setClipSplit(c->id, c->split, m_lastPositionMs, &keys);
}

void MainWindow::syncReframePanel()
{
    m_reframePanel->setPose(m_viewport->Pose());
    const ClipItem *c = m_timeline->clipById(m_clipId);
    const ReframeTrack *t = c ? &c->paneTrack(paneOf(*c)) : nullptr;
    const int seg =
        t ? keytrack::segmentAt(t->keys(), m_lastPositionMs, ClipItem::kReframeDeleteSnapMs) : -1;
    m_reframePanel->setEase(seg >= 0, seg >= 0 ? t->keys()[seg].ease : keytrack::Ease::Linear);
}

void MainWindow::bindActiveClipAt(qint64 timelineMs)
{
    const Timeline::Point pt = m_timeline->timelineToClip(timelineMs);
    if (pt.clipIndex < 0) {
        m_clipId = 0;
        m_lastPositionMs = 0;
        return;
    }
    const ClipItem &c = m_timeline->clipAt(pt.clipIndex);
    const bool clipChanged = c.id != m_clipId;
    m_clipId = c.id;
    if (clipChanged) {
        pushSeamCorrection();
        m_measurements->setPriorityPath(c.sourcePath); // its seam analysed first
        updateSeamStatus();
    }
    m_timelineWidget->setActiveClip(editClipId());
    m_lastPositionMs = c.sourceAtLocalMs(pt.clipLocalMs); // this clip's source time
    // The stab matrix itself rides with each presented frame (the playback
    // controller's stabilization provider) -- setting it here from the clock
    // position would put it up to a frame out of step with the picture.
    if (clipChanged) {
        ensureStabilizers();
        updateSyncStatus();
    }
    // While playing, each presented frame brings its own view and grade
    // (FrameViewCache): set from the clock here, they would change a frame
    // apart from the picture at a cut.
    if (!m_viewportDragging && !m_playing)
        applySampledPose(m_lastPositionMs, clipChanged);
    if (!m_viewportDragging)
        syncReframePanel();
    if (clipChanged) {
        if (!m_playing)
            applyColorGrade(c.color); // the viewport shows this clip
        if (!selectedVideoClip()) // the panels follow the playhead unless a clip is selected
            refreshClipPanels();
    }
}

const ClipItem *MainWindow::selectedVideoClip() const
{
    return m_selectedClipId > 0 ? m_timeline->clipById(m_selectedClipId) : nullptr;
}

int MainWindow::editClipId() const
{
    if (const ClipItem *c = selectedVideoClip())
        return c->id;
    return m_clipId;
}

void MainWindow::selectVideoClip(int clipId)
{
    if (clipId > 0 && !m_timeline->clipById(clipId))
        clipId = 0;
    m_selectedClipId = clipId;
    if (clipId > 0 && m_selectedTrackClipId > 0)
        selectTrackClip(-1); // one selection at a time
    if (clipId > 0 && m_selectedTransition)
        selectTransition(0);
    refreshClipPanels();
}

void MainWindow::refreshClipPanels()
{
    m_timelineWidget->setActiveClip(editClipId());
    const ClipItem *c = m_timeline->clipById(editClipId());
    if (!c) {
        m_privacyPanel->setNotApplicable(QString());
        m_privacyPanel->setNoClip();
        m_stabilizationPanel->setNotApplicable(QString());
        m_stabilizationPanel->setNoClip();
        syncStitchingPanel();
        m_reframePanel->setNoClip();
        m_splitScreenPanel->setNotApplicable(QString());
        m_splitScreenPanel->setNoClip();
        refreshAudioPanel();
        return;
    }
    syncMediaInfoPanel(*c);
    syncColourPanel(c->color);
    m_reframePanel->setClip(c->flat, c->fit == ClipItem::Fit::Fill);
    m_reframePanel->setPaneLayout(c->split.layout);
    m_splitScreenPanel->setNotApplicable(c->flat ? tr("A flat video isn't split into panes.")
                                                 : QString());
    m_splitScreenPanel->setSplit(c->split);
    m_reframePanel->setActivePane(paneOf(*c));
    syncStabilizationPanel();
    syncStitchingPanel();
    syncPrivacyPanel();
    refreshAudioPanel(); // the selected audio clip, if any, else this clip
    const ClipItem *playing = m_timeline->clipById(m_clipId);
    const bool keyed = playing && !playing->paneTrack(paneOf(*playing)).isEmpty();
    m_editToolbar->setHasReframeKeys(keyed);
    m_reframePanel->setClipUnkeyed(playing && !keyed);
}

TimelineWidget::Peaks MainWindow::waveformFor(const QString &path, int stream)
{
    const WaveformCache::Peaks p = m_waveforms->peaks(path, stream);
    return p ? TimelineWidget::Peaks(p, &p->peaks) : nullptr; // shares ownership with p
}

int MainWindow::audioStreamCount(const QString &path)
{
    auto it = m_audioTrackCounts.constFind(path);
    if (it == m_audioTrackCounts.constEnd())
        it = m_audioTrackCounts.insert(
            path, m_clipBackend.audioStreamCount(path.toStdString()));
    return *it;
}

void MainWindow::refreshTrackRows()
{
    QVector<TimelineWidget::TrackView> tracks;
    const auto moveTargets = [this](const Track &from, int clipId) {
        QVector<int> ids;
        for (int k = 0; k < m_timeline->trackCount(); ++k)
            if (const int id = m_timeline->trackAt(k).id;
                id != from.id && m_timeline->canHoldClip(id, clipId))
                ids.push_back(id);
        return ids;
    };
    for (int i = 0; i < m_timeline->trackCount(); ++i) {
        const Track &t = m_timeline->trackAt(i);
        TimelineWidget::TrackView v;
        v.id = t.id;
        v.name = t.name;
        v.muted = t.muted;
        v.video = t.kind == Track::Kind::Video;
        v.group = t.group() == Track::Group::Main    ? TimelineWidget::TrackView::Group::Main
                  : t.group() == Track::Group::Audio ? TimelineWidget::TrackView::Group::Audio
                                                     : TimelineWidget::TrackView::Group::Overlay;
        v.overlayAudio = t.role == Track::Role::OverlayAudio;
        for (const TrackClip &c : t.clips) {
            TimelineWidget::TrackClipView a;
            a.id = c.id;
            a.label = overlayLabel(c);
            if (v.video) { // an overlay: no audio to draw, nothing to link
                a.startMs = c.startMs;
                a.trimInMs = c.trimInMs;
                a.trimOutMs = c.trimOutMs;
                a.sourceDurationMs = c.sourceDurationMs;
                a.speed = c.speed;
                a.fadeInMs = c.fadeInMs;
                a.fadeOutMs = c.fadeOutMs;
                a.missing = c.mediaMissing;
                for (const InsetKey &k : c.insetKeys.keys())
                    a.keySourceMs.push_back(k.timeMs);
                a.hasSound =
                    !c.isDrawn() && !c.mediaMissing && audioStreamCount(c.sourcePath) > 0;
                a.moveTargets = moveTargets(t, c.id);
                v.clips.push_back(a);
                continue;
            }
            a.startMs = c.startMs;
            a.trimInMs = c.trimInMs;
            a.trimOutMs = c.trimOutMs;
            a.sourceDurationMs = c.sourceDurationMs;
            a.speed = c.speed;
            a.fadeInMs = c.fadeInMs;
            a.fadeOutMs = c.fadeOutMs;
            a.muted = c.muted;
            a.missing = c.mediaMissing;
            a.linked = c.linkedClipId != 0;
            if (!c.mediaMissing)
                a.peaks = waveformFor(c.sourcePath, c.stream);
            a.gain = std::pow(10.0, c.gainDb / 20.0);
            a.linkable = !a.linked && m_timeline->linkTargetFor(c) != 0;
            a.moveTargets = moveTargets(t, c.id);
            v.clips.push_back(a);
        }
        tracks.push_back(std::move(v));
    }
    m_timelineWidget->setTracks(tracks);
    m_timelineWidget->setSelectedTrackClip(m_selectedTrackClipId);
    fitTimelineHeight();
}

void MainWindow::fitTimelineHeight()
{
    // Until the user drags the split, the timeline is as tall as its tracks
    // need, but never more than 40 % of the editor; once dragged, their
    // height stays and extra tracks scroll.
    if (m_timelineHeightSet)
        return;
    const int total = m_editorPage->height();
    if (total <= 0)
        return;
    const int want = std::max(m_timelinePane->minimumSizeHint().height(),
                              std::min(m_timelinePane->sizeHint().height(), total * 2 / 5));
    m_editorPage->setSizes({total - want - m_editorPage->handleWidth(), want});
}

void MainWindow::selectTrackClip(int clipId)
{
    if (clipId > 0 && !m_timeline->trackClipById(clipId))
        clipId = -1;
    const bool changed = clipId != m_selectedTrackClipId;
    m_selectedTrackClipId = clipId;
    m_timelineWidget->setSelectedTrackClip(clipId);
    // Between the Picture in picture and Overlay tabs, the one for what's selected.
    if (const TrackClip *tc = changed && clipId > 0 ? m_timeline->trackClipById(clipId) : nullptr) {
        const int tab = m_sidebar->currentIndex();
        if (tc->isDrawn() && tab == SettingsSidebar::OverlayTab)
            m_sidebar->setCurrentIndex(SettingsSidebar::TitleTab);
        else if (!tc->isDrawn() && tab == SettingsSidebar::TitleTab && selectedOverlayClip())
            m_sidebar->setCurrentIndex(SettingsSidebar::OverlayTab);
    }
    if (clipId > 0 && m_selectedTransition)
        selectTransition(0); // one selection at a time
    if (clipId > 0 && m_selectedClipId > 0) {
        m_selectedClipId = 0;
        refreshClipPanels();
    } else if (changed) {
        refreshAudioPanel();
    }
    refreshOverlayPanel();
}

QList<int> MainWindow::audioPanelClipIds(QString *scope) const
{
    // Every audio clip linked to `clipId`, in track order: a video clip's
    // camera mic and external mic, an overlay's sound.
    const auto linkedTo = [this](int clipId) {
        QList<int> ids;
        for (int i = 0; i < m_timeline->trackCount(); ++i)
            for (const TrackClip &a : m_timeline->trackAt(i).clips)
                if (a.linkedClipId == clipId)
                    ids.append(a.id);
        return ids;
    };
    int trackId = 0;
    if (m_selectedTrackClipId > 0 && m_timeline->trackClipById(m_selectedTrackClipId, &trackId)) {
        if (m_timeline->trackById(trackId)->kind == Track::Kind::Video) {
            if (scope)
                *scope = tr("Selected PiP clip");
            return linkedTo(m_selectedTrackClipId);
        }
        if (scope)
            *scope = tr("Selected audio clip");
        return {m_selectedTrackClipId};
    }
    // Else the video clip selected or under the playhead.
    const int clipId = editClipId();
    if (!clipId)
        return {};
    if (scope)
        *scope = tr("This clip");
    return linkedTo(clipId);
}

void MainWindow::refreshAudioPanel()
{
    QString scope;
    QList<AudioClipState> states;
    for (int id : audioPanelClipIds(&scope)) {
        int trackId = 0;
        const TrackClip *a = m_timeline->trackClipById(id, &trackId);
        const Track *t = a ? m_timeline->trackById(trackId) : nullptr;
        if (!t)
            continue;
        AudioClipState st;
        st.clipId = id;
        st.trackId = trackId;
        st.kind = t->role == Track::Role::CameraMic     ? QStringLiteral("cameraMic")
                  : t->role == Track::Role::ExternalMic ? QStringLiteral("externalMic")
                                                        : QStringLiteral("clip");
        st.label = QFileInfo(a->sourcePath).fileName();
        st.gainDb = a->gainDb;
        st.muted = a->muted;
        st.fadeInMs = a->fadeInMs;
        st.fadeOutMs = a->fadeOutMs;
        st.spanMs = a->timelineDurationMs();
        st.startMs = a->startMs;
        st.linked = a->linkedClipId != 0;
        st.trackName = t->name;
        st.trackGainDb = t->gainDb;
        st.trackMuted = t->muted;
        st.noise = a->noise;
        states.append(st);
    }
    m_audioPanel->setClips(states, scope);
}

void MainWindow::onTracksChanged()
{
    if (m_selectedTrackClipId > 0 && !m_timeline->trackClipById(m_selectedTrackClipId))
        m_selectedTrackClipId = -1;
    refreshTrackRows();
    refreshAudioPanel();
    refreshOverlayPanel();
    pushInsetsToController();
    m_audioPlayer->setMix(renderjobs::mixClips(*m_timeline));
}

void MainWindow::selectAdded(std::optional<int> lastClipId)
{
    if (lastClipId)
        selectTrackClip(*lastClipId);
}

void MainWindow::addTitle(int trackId, qint64 atMs, const QString &presetId)
{
    if (m_timeline->count() == 0)
        return; // the main track sets the length
    const titlepresets::GaugePreset *gaugePreset = titlepresets::findGauge(presetId);
    const titlepresets::Preset *preset = gaugePreset ? nullptr : titlepresets::find(presetId);
    if (!preset && !gaugePreset) {
        qWarning("[titles] no title preset \"%s\"; adding the plain one", qPrintable(presetId));
        preset = &titlepresets::all().front();
    }
    atMs = std::clamp<qint64>(atMs, 0, m_timeline->totalDurationMs());
    // The track given if it has room there, else the first that has, else a
    // new one.
    const qint64 endMs = atMs + title::kDefaultSpanMs;
    const int given = m_timeline->freeTrackFor(atMs, endMs, true, [trackId](const Track &t) {
        return t.id == trackId;
    });
    trackId = given ? given
                    : m_timeline->freeTrackFor(atMs, endMs, true, [](const Track &) { return true; });
    if (!trackId)
        trackId = m_timeline->addTrack(Track::Kind::Video);
    const int id =
        gaugePreset
            ? m_timeline->addGaugeClip(trackId, atMs, titlepresets::gaugeStyleFor(*gaugePreset),
                                       title::kDefaultSpanMs, gaugePreset->look)
            : m_timeline->addTitleClip(trackId, atMs, titlepresets::styleFor(*preset),
                                       title::kDefaultSpanMs, preset->look, preset->motion);
    if (!id)
        return;
    selectTrackClip(id);
    m_sidebar->setCurrentIndex(SettingsSidebar::TitleTab);
    m_sidebar->setOpen(true);
}

void MainWindow::pushInsetsToController()
{
    const OutputSettings &out = m_project->output();
    m_controller->setInsets(renderjobs::insetFeed(*m_timeline, out.width, out.height, m_privacy,
                                                  fieldSources(),
                                                  m_controller->layerLender())); // thread-safe
}

renderjobs::FieldSources MainWindow::fieldSources(bool wait)
{
    renderjobs::FieldSources out;
    const bool clock = renderjobs::anyTitleClock(*m_timeline);
    const bool gps = renderjobs::anyTitleTelemetry(*m_timeline);
    if (!clock && !gps)
        return out;
    for (int i = 0; i < m_timeline->count(); ++i) {
        const ClipItem &c = m_timeline->clipAt(i);
        if (c.mediaMissing)
            continue;
        if (clock && !out.recorded.contains(c.sourcePath)) {
            auto it = m_recordedTimes.constFind(c.sourcePath);
            if (it == m_recordedTimes.constEnd()) {
                const camera::MediaInfo *info = mediaInfoFor(c.sourcePath);
                it = m_recordedTimes.insert(c.sourcePath,
                                            info ? recordedTime(*info) : QDateTime());
            }
            out.recorded.insert(c.sourcePath, *it);
        }
        if (gps && !c.flat && !out.gps.contains(c.sourcePath)) {
            const TelemetryCache::Readings r = wait ? m_telemetry->await(c.sourcePath)
                                                    : m_telemetry->readings(c.sourcePath);
            out.gps.insert(c.sourcePath, r.gps);
            out.motion.insert(c.sourcePath, r.motion);
        }
    }
    return out;
}

QString MainWindow::titleClockNote(const TrackClip &c)
{
    if (!c.isDrawn())
        return {};
    const bool gaugeMotion = c.isGauge() && gauge::readsMotion(c.gauge->kind);
    const bool clock = c.isTitle() && title::hasClockFields(c.title->text);
    const bool gps = c.isGauge() ? !gaugeMotion : title::hasGpsFields(c.title->text);
    const bool motion = c.isGauge() ? gaugeMotion : title::hasMotionFields(c.title->text);
    const bool gForce = c.isGauge() ? c.gauge->kind == gauge::Kind::GForce
                                    : title::hasGForceField(c.title->text);
    if (!clock && !gps && !motion)
        return {};
    const renderjobs::FieldSources sources = fieldSources();
    const title::Clock readings = renderjobs::titleClock(*m_timeline, sources);
    QStringList unknown, noGps, partGps, noMotion, noG, noTravel;
    const qint64 endMs = c.startMs + c.timelineDurationMs();
    for (int i = 0; i < m_timeline->count(); ++i) {
        const qint64 from = m_timeline->clipToTimeline(i, 0);
        const qint64 to = from + m_timeline->clipAt(i).timelineDurationMs();
        // Under the title, or the last clip if the title runs past the end.
        const bool last = i == m_timeline->count() - 1 && c.startMs >= to;
        if (!(from < endMs && to > c.startMs) && !last)
            continue;
        const QString &path = m_timeline->clipAt(i).sourcePath;
        if (clock && !sources.recorded.value(path).isValid())
            unknown << QString::number(i + 1);
        // Nothing said of a file still being read: the note is set again
        // when it's in.
        if ((!gps && !motion) || m_telemetry->pending(path))
            continue;
        // A track may cover only part of its clip: looked at where the
        // title is over it, every half second.
        const qint64 a = last ? to - 1 : std::max(from, c.startMs);
        const qint64 b = last ? to : std::min(to, endMs);
        int have = 0, moving = 0, accelerating = 0, travelling = 0, looked = 0;
        for (qint64 t = a; t < b; t += 500, ++looked) {
            have += gps && readings.gpsAt(t).has_value();
            if (motion) {
                const std::optional<MotionTelemetry::Values> m = readings.motionAt(t);
                moving += m.has_value();
                accelerating += m && m->gKnown;
                travelling += m && m->travelKnown;
            }
        }
        if (gps && have == 0)
            noGps << QString::number(i + 1);
        else if (gps && have < looked)
            partGps << QString::number(i + 1);
        if (motion && moving == 0)
            noMotion << QString::number(i + 1);
        else if (gForce && accelerating == 0)
            noG << QString::number(i + 1);
        else if (gForce && travelling == 0)
            noTravel << QString::number(i + 1);
    }
    QStringList notes;
    if (!unknown.isEmpty())
        notes << (unknown.size() == 1
                      ? tr("Clip %1 doesn't say when it was recorded: the time shows --:-- and "
                           "the date nothing while the title is over it.")
                            .arg(unknown.front())
                      : tr("Clips %1 don't say when they were recorded: the time shows --:-- "
                           "and the date nothing while the title is over them.")
                            .arg(QLocale().createSeparatedList(unknown)));
    // A gauge stays empty where a title's fields show "--".
    const bool gauge = c.isGauge();
    if (!noGps.isEmpty())
        notes << (noGps.size() == 1
                      ? (gauge ? tr("Clip %1 has no GPS where the gauge is over it: the gauge "
                                    "stays empty there.")
                               : tr("Clip %1 has no GPS where the title is over it: speed, "
                                    "altitude and heading show -- there."))
                            .arg(noGps.front())
                      : (gauge ? tr("Clips %1 have no GPS where the gauge is over them: the "
                                    "gauge stays empty there.")
                               : tr("Clips %1 have no GPS where the title is over them: speed, "
                                    "altitude and heading show -- there."))
                            .arg(QLocale().createSeparatedList(noGps)));
    if (!partGps.isEmpty())
        notes << (partGps.size() == 1
                      ? (gauge ? tr("Clip %1 has GPS for only part of the time the gauge is "
                                    "over it: elsewhere the gauge stays empty.")
                               : tr("Clip %1 has GPS for only part of the time the title is "
                                    "over it: elsewhere speed, altitude and heading show --."))
                            .arg(partGps.front())
                      : (gauge ? tr("Clips %1 have GPS for only part of the time the gauge is "
                                    "over them: elsewhere the gauge stays empty.")
                               : tr("Clips %1 have GPS for only part of the time the title is "
                                    "over them: elsewhere speed, altitude and heading show --."))
                            .arg(QLocale().createSeparatedList(partGps)));
    if (!noMotion.isEmpty())
        notes << (noMotion.size() == 1
                      ? (gauge ? tr("Clip %1 has no motion data where the gauge is over it: "
                                    "the gauge stays empty there.")
                               : tr("Clip %1 has no motion data where the title is over it: "
                                    "lean and G-force show -- there."))
                            .arg(noMotion.front())
                      : (gauge ? tr("Clips %1 have no motion data where the gauge is over "
                                    "them: the gauge stays empty there.")
                               : tr("Clips %1 have no motion data where the title is over "
                                    "them: lean and G-force show -- there."))
                            .arg(QLocale().createSeparatedList(noMotion)));
    if (!noG.isEmpty())
        notes << (noG.size() == 1
                      ? (gauge ? tr("Clip %1 records how the camera turned but no G-force "
                                    "(a timelapse): the G circle stays empty there.")
                               : tr("Clip %1 records how the camera turned but no G-force "
                                    "(a timelapse): the G-force shows -- there."))
                            .arg(noG.front())
                      : (gauge ? tr("Clips %1 record how the camera turned but no G-force "
                                    "(timelapses): the G circle stays empty there.")
                               : tr("Clips %1 record how the camera turned but no G-force "
                                    "(timelapses): the G-force shows -- there."))
                            .arg(QLocale().createSeparatedList(noG)));
    if (!noTravel.isEmpty())
        notes << (noTravel.size() == 1
                      ? (gauge ? tr("Clip %1 hardly turns, so which way it travels isn't "
                                    "known: the G circle stays empty there.")
                               : tr("Clip %1 hardly turns, so which way it travels isn't "
                                    "known: the G-force shows -- there."))
                            .arg(noTravel.front())
                      : (gauge ? tr("Clips %1 hardly turn, so which way they travel isn't "
                                    "known: the G circle stays empty there.")
                               : tr("Clips %1 hardly turn, so which way they travel isn't "
                                    "known: the G-force shows -- there."))
                            .arg(QLocale().createSeparatedList(noTravel)));
    return notes.join(QLatin1Char(' '));
}

const TrackClip *MainWindow::selectedOverlayClip(int *trackId) const
{
    int tid = 0;
    const TrackClip *c =
        m_selectedTrackClipId > 0 ? m_timeline->trackClipById(m_selectedTrackClipId, &tid) : nullptr;
    if (!c || m_timeline->trackById(tid)->kind != Track::Kind::Video)
        return nullptr;
    if (trackId)
        *trackId = tid;
    return c;
}

void MainWindow::refreshOverlayPanel()
{
    int trackId = 0;
    const TrackClip *c = selectedOverlayClip(&trackId);
    if (!c) {
        m_overlayPanel->setNoClip();
        m_overlayAnimationPanel->setNoClip();
        m_titleTextPanel->setNoTitle(QString());
        m_titleLookPanel->setNoTitle(QString());
        m_titleAnimationPanel->setNoClip();
        m_titlePlacementPanel->setNoClip();
        return;
    }
    // A title shows on the Overlay tab, an overlay video on the Picture in picture tab;
    // the other says where to look.
    OverlayPanel *panel = c->isDrawn() ? m_titlePlacementPanel : m_overlayPanel;
    m_sidebar->showGaugeSections(c->isGauge());
    if (c->isDrawn()) {
        const QString scope = c->isGauge() ? tr("Selected gauge") : tr("Selected title");
        m_titleAnimationPanel->setScope(scope);
        m_titlePlacementPanel->setScope(scope);
    }
    if (c->isTitle()) {
        m_titleTextPanel->setTitle(*c->title, titleClockNote(*c));
        m_titleLookPanel->setTitle(*c->title);
        m_titleAnimationPanel->setMotion(c->motion);
        const QString hint = tr("A title is selected: its settings are in the Overlay tab.");
        m_overlayPanel->setNoClip(hint);
        m_overlayAnimationPanel->setNoClip(hint);
    } else if (c->isGauge()) {
        m_sidebar->gauge()->setGauge(*c->gauge, titleClockNote(*c));
        m_titleAnimationPanel->setMotion(c->motion, false);
        const QString hint = tr("A gauge is selected: its settings are in the Overlay tab.");
        m_overlayPanel->setNoClip(hint);
        m_overlayAnimationPanel->setNoClip(hint);
    } else {
        m_overlayAnimationPanel->setMotion(c->motion);
        const QString hint = tr("A picture in picture is selected: its settings are in the "
                                "Picture in picture tab.");
        m_titleTextPanel->setNoTitle(hint);
        m_titleLookPanel->setNoTitle(hint);
        m_titleAnimationPanel->setNoClip(hint);
        m_titlePlacementPanel->setNoClip(hint);
    }
    OverlayPanel::State st;
    st.label = overlayLabel(*c);
    st.gauge = c->isGauge();
    st.trackName = m_timeline->trackById(trackId)->name;
    // The layer: the overlay tracks in order, the first in front.
    QStringList overlays;
    for (int i = 0; i < m_timeline->trackCount(); ++i) {
        const Track &t = m_timeline->trackAt(i);
        if (t.kind != Track::Kind::Video)
            continue;
        overlays << t.name;
        if (t.id == trackId)
            st.layer = int(overlays.size());
    }
    st.layerCount = int(overlays.size());
    if (st.layer > 1)
        st.behind = overlays[st.layer - 2];
    if (st.layer > 0 && st.layer < st.layerCount)
        st.inFrontOf = overlays[st.layer];
    st.playheadInClip = m_lastTimelineMs >= c->startMs && m_lastTimelineMs < c->endMs();
    const qint64 src = c->sourceAtLocalMs(
        std::clamp<qint64>(m_lastTimelineMs - c->startMs, 0, c->timelineDurationMs()));
    st.look = c->lookAt(src);
    st.frame = c->frame;
    st.fadeInMs = c->fadeInMs;
    st.fadeOutMs = c->fadeOutMs;
    st.spanMs = c->timelineDurationMs();
    st.maxSpanMs = std::llround((c->sourceDurationMs - c->trimInMs) / c->speed);
    st.startMs = c->startMs;
    st.keyCount = c->insetKeys.count();
    for (const InsetKey &k : c->insetKeys.keys())
        st.keyAtPlayhead |= st.playheadInClip &&
                            std::llabs(k.timeMs - src) <= Timeline::kInsetKeyDeleteSnapMs;
    const int seg = st.playheadInClip ? keytrack::segmentAt(c->insetKeys.keys(), src,
                                                            Timeline::kInsetKeyDeleteSnapMs)
                                      : -1;
    st.easeAvailable = seg >= 0;
    if (seg >= 0)
        st.ease = c->insetKeys.keys()[seg].ease;
    panel->setState(st);
}

void MainWindow::moveSelectedOverlayLayer(int step)
{
    // Past the neighbouring overlay track (with its audio track): moveTrack
    // puts it before that track going up, after it going down.
    int trackId = 0;
    if (!selectedOverlayClip(&trackId))
        return;
    int prev = -1, next = -1, at = -1;
    for (int i = 0; i < m_timeline->trackCount(); ++i) {
        if (m_timeline->trackAt(i).kind != Track::Kind::Video)
            continue;
        if (m_timeline->trackAt(i).id == trackId)
            at = i;
        else if (at < 0)
            prev = i;
        else if (next < 0)
            next = i;
    }
    const int to = step < 0 ? prev : next;
    if (to >= 0)
        m_timeline->moveTrack(trackId, to);
}

void MainWindow::setOverlayKeyAtPlayhead()
{
    const TrackClip *c = selectedOverlayClip();
    if (!c)
        return;
    if (m_lastTimelineMs < c->startMs || m_lastTimelineMs >= c->endMs()) {
        m_editToolbar->showNotice(tr("Move the playhead into the overlay clip to set a key"), false);
        return;
    }
    const qint64 src = c->sourceAtLocalMs(m_lastTimelineMs - c->startMs);
    m_timeline->upsertTrackClipInsetKey(c->id, src, c->lookAt(src));
}

void MainWindow::deleteOverlayKeyAtPlayhead()
{
    if (const TrackClip *c = selectedOverlayClip())
        m_timeline->removeTrackClipInsetKeyNear(
            c->id, c->sourceAtLocalMs(m_lastTimelineMs - c->startMs));
}

void MainWindow::clearOverlayKeys()
{
    if (const TrackClip *c = selectedOverlayClip())
        m_timeline->clearTrackClipInsetKeys(
            c->id, c->sourceAtLocalMs(std::clamp<qint64>(m_lastTimelineMs - c->startMs, 0,
                                                         c->timelineDurationMs())));
}

void MainWindow::applyInsetLook(int clipId, const inset::Look &look)
{
    const TrackClip *c = m_timeline->trackClipById(clipId);
    if (!c)
        return;
    if (c->insetKeys.isEmpty()) {
        m_timeline->setTrackClipInset(clipId, look, c->frame);
        return;
    }
    // Keyed: the edit becomes a key at the playhead, which has to be over it.
    if (m_lastTimelineMs < c->startMs || m_lastTimelineMs >= c->endMs()) {
        m_editToolbar->showNotice(tr("Move the playhead into the overlay clip to set a key"), false);
        refreshOverlayPanel(); // put the fields back
        pushInsetsToController();
        return;
    }
    m_timeline->upsertTrackClipInsetKey(clipId, c->sourceAtLocalMs(m_lastTimelineMs - c->startMs),
                                        look);
}

void MainWindow::trimAtPlayhead(bool in)
{
    // A selected audio clip takes the trim, cut at the playhead's point
    // in it; the playhead has to be over the clip.
    int trackId = 0;
    if (const TrackClip *a = m_selectedTrackClipId > 0
                                 ? m_timeline->trackClipById(m_selectedTrackClipId, &trackId)
                                 : nullptr) {
        if (m_lastTimelineMs <= a->startMs || m_lastTimelineMs >= a->endMs()) {
            m_editToolbar->showNotice(tr("Move the playhead into the selected clip to trim it"),
                                    false);
            return;
        }
        const qint64 src = a->sourceAtLocalMs(m_lastTimelineMs - a->startMs);
        if (in)
            m_timeline->setTrackClipTrimIn(a->id, src);
        else
            m_timeline->setTrackClipTrimOut(a->id, src);
        return;
    }
    // A selected video clip only if the playhead is over it (the playhead's
    // source time, m_lastPositionMs, is m_clipId's).
    if (!m_clipId)
        return;
    if (editClipId() != m_clipId) {
        m_editToolbar->showNotice(tr("Move the playhead into the selected clip to trim it"), false);
        return;
    }
    if (in)
        m_timeline->setClipTrimIn(m_clipId, m_lastPositionMs);
    else
        m_timeline->setClipTrimOut(m_clipId, m_lastPositionMs);
}

void MainWindow::addMarkAtPlayhead()
{
    if (const ClipItem *c = m_timeline->clipById(m_clipId))
        m_timeline->addClipMark(c->id, m_lastPositionMs, cameraMarks(*c));
}

void MainWindow::deleteMarkAtPlayhead()
{
    if (const ClipItem *c = m_timeline->clipById(m_clipId))
        m_timeline->removeClipMarkNear(c->id, m_lastPositionMs, cameraMarks(*c));
}

QList<qint64> MainWindow::cameraMarks(const ClipItem &c) const
{
    return c.flat ? QList<qint64>() : m_clipFacts->highlights(c.sourcePath);
}

void MainWindow::addKey(const QString &group, const QString &what,
                        const QList<QKeySequence> &keys, const std::function<void()> &fn,
                        const QString &keysLabel)
{
    for (const QKeySequence &seq : keys) {
        auto *sc = new QShortcut(seq, this);
        sc->setContext(Qt::ApplicationShortcut);
        sc->setAutoRepeat(true);
        connect(sc, &QShortcut::activated, this, fn);
        m_editorShortcuts.push_back(sc);
    }
    m_keyHelp.append({group, what, keys, keysLabel});
}

void MainWindow::setupViewMenu()
{
    // View: what's seen while editing. The preview's stitch size
    // is part of the project's stitch settings (Project::previewStitch) but
    // changes only the preview, never the export.
    QMenu *viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu->setToolTipsVisible(true);
    const auto setPreview = [this](const std::function<void(stitch::PreviewStitchConfig &)> &edit) {
        stitch::PreviewStitchConfig cfg = m_project->previewStitch();
        edit(cfg);
        m_project->setPreviewStitch(cfg);
    };

    // 2:1 presets only -- equirect is 360x180 and the reprojection shader
    // assumes it. Width is the source of truth; height is always width / 2.
    // Above 3840, check real time for the clip's mode (tools/playback_bench).
    QMenu *sizeMenu = viewMenu->addMenu(tr("Preview &size"));
    sizeMenu->setObjectName(QStringLiteral("previewSizeMenu"));
    sizeMenu->setToolTipsVisible(true);
    const QString sizeTip =
        tr("Almost never matters: the viewport normally draws straight from the two lens "
           "pictures at full detail. Only when the graphics card or driver can't do that is a "
           "flat 360° preview stitched first, and this sets its size. Auto uses the clip's "
           "full detail, as much as plays smoothly at its frame rate.");
    m_previewSize = new QActionGroup(this);
    for (const int w : {0, 1920, 2560, 3072, 3840, 5120, 5760, 7680}) {
        QAction *a = sizeMenu->addAction(w == 0 ? tr("&Auto (match source)")
                                                : QStringLiteral("%1 x %2").arg(w).arg(w / 2));
        a->setObjectName(QStringLiteral("previewSize%1Action").arg(w));
        a->setData(w);
        a->setCheckable(true);
        a->setToolTip(sizeTip);
        m_previewSize->addAction(a);
        if (w == 0)
            sizeMenu->addSeparator();
    }
    connect(m_previewSize, &QActionGroup::triggered, this, [setPreview](QAction *a) {
        setPreview([a](stitch::PreviewStitchConfig &c) {
            c.width = a->data().toInt(); // 0 = Auto
            c.height = c.width / 2;
        });
    });
    m_editorActions += sizeMenu->menuAction();
    updatePreviewMenu(m_project->previewStitch());

    // The app's colours, per user (QSettings ui/theme, read in main()).
    // Also on the start screen, unlike the preview's settings.
    viewMenu->addSeparator();
    QMenu *themeMenu = viewMenu->addMenu(tr("&Theme"));
    themeMenu->setObjectName(QStringLiteral("themeMenu"));
    auto *themeGroup = new QActionGroup(this);
    for (const theme::Theme &t : theme::themes()) {
        QAction *a = themeMenu->addAction(t.name);
        a->setObjectName(QStringLiteral("theme_%1_Action").arg(t.id));
        a->setData(t.id);
        a->setCheckable(true);
        a->setChecked(t.id == theme::current().id);
        themeGroup->addAction(a);
    }
    connect(themeGroup, &QActionGroup::triggered, this, [](QAction *a) {
        const QString id = a->data().toString();
        if (id == theme::current().id)
            return;
        theme::apply(*qApp, theme::byId(id));
        QSettings(QStringLiteral("orbis-reframe"), QStringLiteral("orbis-reframe"))
            .setValue(QStringLiteral("ui/theme"), id);
    });
}

void MainWindow::editProjectSettings()
{
    ProjectSettingsDialog dialog(m_project->output(),
                                 m_timeline->count() > 0 ? m_timeline->clipAt(0).fps : 0.0, this);
    if (dialog.exec() == QDialog::Accepted)
        m_project->setOutput(dialog.output()); // a no-op when nothing changed
}

void MainWindow::setupKeyboardShortcuts()
{
    // The player bar's buttons do what these keys do.
    const auto playPause = [this] {
        QMetaObject::invokeMethod(m_controller, "togglePlay", Qt::QueuedConnection);
    };
    // In a Media tab file previewed, they move in it (stepSource): a file
    // has no cuts, so those go to its start / end.
    const auto frameBack = [this] {
        if (!stepSource(SourceStep::Frame, -1))
            navigateTo(m_timeline->stepFrames(m_lastTimelineMs, -1), true);
    };
    const auto frameForward = [this] {
        if (!stepSource(SourceStep::Frame, 1))
            navigateTo(m_timeline->stepFrames(m_lastTimelineMs, 1), true);
    };
    const auto previousCut = [this] {
        if (!stepSource(SourceStep::Edge, -1))
            navigateTo(m_timeline->adjacentEditPoint(m_lastTimelineMs, -1), false);
    };
    const auto nextCut = [this] {
        if (!stepSource(SourceStep::Edge, 1))
            navigateTo(m_timeline->adjacentEditPoint(m_lastTimelineMs, 1), false);
    };
    const auto toStart = [this] {
        if (!stepSource(SourceStep::Edge, -1))
            navigateTo(0, false);
    };
    const auto toEnd = [this] {
        if (!stepSource(SourceStep::Edge, 1))
            navigateTo(m_timeline->totalDurationMs(), false);
    };
    connect(m_playerBar, &PlayerBar::frameBackClicked, this, frameBack);
    connect(m_playerBar, &PlayerBar::frameForwardClicked, this, frameForward);
    connect(m_playerBar, &PlayerBar::previousCutClicked, this, previousCut);
    connect(m_playerBar, &PlayerBar::nextCutClicked, this, nextCut);
    connect(m_playerBar, &PlayerBar::toStartClicked, this, toStart);
    connect(m_playerBar, &PlayerBar::toEndClicked, this, toEnd);

    const QString play = tr("Playback");
    addKey(play, tr("Play / pause"), {QKeySequence(Qt::Key_Space)}, playPause);
    addKey(play, tr("Previous / next frame (pauses)"), {QKeySequence(Qt::Key_Left)}, frameBack);
    addKey(play, QString(), {QKeySequence(Qt::Key_Right)}, frameForward);
    addKey(play, tr("Back / forward 1 second"), {QKeySequence(Qt::SHIFT | Qt::Key_Left)},
           [this] {
               if (!stepSource(SourceStep::Second, -1))
                   navigateTo(m_lastTimelineMs - 1000, false);
           });
    addKey(play, QString(), {QKeySequence(Qt::SHIFT | Qt::Key_Right)}, [this] {
        if (!stepSource(SourceStep::Second, 1))
            navigateTo(m_lastTimelineMs + 1000, false);
    });
    addKey(play, tr("Previous / next cut or clip edge"), {QKeySequence(Qt::Key_Up)}, previousCut);
    addKey(play, QString(), {QKeySequence(Qt::Key_Down)}, nextCut);
    // With an overlay clip selected, its keys (as K / Shift+K).
    const auto toKey = [this](int direction) {
        if (stepSource(SourceStep::None, direction)) // a file has no keyframes
            return;
        const TrackClip *o = selectedOverlayClip();
        navigateTo(m_timeline->adjacentKey(m_lastTimelineMs, direction, o ? o->id : 0,
                                           m_viewport->ActivePane()),
                   false);
    };
    addKey(play, tr("Previous / next keyframe: the selected overlay's, else the reframe ones"),
           {QKeySequence(Qt::SHIFT | Qt::Key_Up)}, [toKey] { toKey(-1); });
    addKey(play, QString(), {QKeySequence(Qt::SHIFT | Qt::Key_Down)}, [toKey] { toKey(1); });
    const auto toMark = [this](int direction) {
        if (stepSource(SourceStep::Mark, direction)) // the file's camera marks
            return;
        navigateTo(m_timeline->adjacentMark(
                       m_lastTimelineMs, direction,
                       [this](const QString &path) { return m_clipFacts->highlights(path); }),
                   false);
    };
    addKey(play, tr("Previous / next highlight mark"), {QKeySequence(Qt::CTRL | Qt::Key_Up)},
           [toMark] { toMark(-1); });
    addKey(play, QString(), {QKeySequence(Qt::CTRL | Qt::Key_Down)}, [toMark] { toMark(1); });
    addKey(play, tr("Start / end of the timeline"), {QKeySequence(Qt::Key_Home)}, toStart);
    addKey(play, QString(), {QKeySequence(Qt::Key_End)}, toEnd);
    // J / L: the player bar's speed (K is "set keyframe", so Space stops).
    addKey(play, tr("Slower / faster playback (L also starts it); the sound plays at 1× only"),
           {QKeySequence(Qt::Key_J)}, [this] { m_playerBar->stepSpeed(-1); });
    addKey(play, QString(), {QKeySequence(Qt::Key_L)}, [this, playPause] {
        if (m_playing)
            m_playerBar->stepSpeed(1);
        else
            playPause();
    });
    addKey(play, tr("Type a time to jump to"), {QKeySequence(Qt::CTRL | Qt::Key_G)},
           [this] {
               if (m_fullScreen)
                   showPlayerBarForAWhile();
               m_playerBar->editTime();
           });
    addKey(play, tr("Full screen on / off (also a double-click on the picture; Esc leaves)"),
           {QKeySequence(Qt::Key_F11)}, [this] { setFullScreenView(!m_fullScreen); });
    // The Media list's own Space (MediaPoolList), in the list.
    m_keyHelp.append({play,
                      tr("In the Media tab: play the selected file in the viewport, not on the "
                         "timeline (again: pause; Esc goes back to the timeline)"),
                      {QKeySequence(Qt::Key_Space)}, QString()});
    // The window-level screenshot action (no menu holds it) in the list.
    m_keyHelp.append({play, tr("Save a screenshot of the frame at the playhead"),
                      m_screenshotAction->shortcuts(), QString()});

    const QString edit = tr("Editing");
    addKey(edit, tr("Set the trim in / out point at the playhead"),
           {QKeySequence(Qt::Key_BracketLeft)}, [this] { trimAtPlayhead(true); });
    addKey(edit, QString(), {QKeySequence(Qt::Key_BracketRight)},
           [this] { trimAtPlayhead(false); });
    addKey(edit, tr("Restore: give the selected audio / overlay clip, else the video clip, its "
                    "full length"),
           {QKeySequence(Qt::Key_R)}, [this] { clearTrim(); });
    addKey(edit, tr("Split the selected audio / overlay clip, else the video clip, at the playhead"),
           {QKeySequence(Qt::Key_S)}, [this] { splitAtPlayhead(); });
    addKey(edit,
           tr("Delete the selected clip or transition, else the reframe keyframe at the "
              "playhead"),
           {QKeySequence(Qt::Key_Delete), QKeySequence(Qt::Key_Backspace)},
           [this] { deleteAtPlayhead(); });
    addKey(edit,
           tr("Clear the selection (or cancel drawing a Track subject / Blur a plate box, "
              "leave full screen, or go back to the timeline from a Media tab file)"),
           {QKeySequence(Qt::Key_Escape)}, [this] {
               if (m_trackSelecting) {
                   setTrackSelecting(false);
                   return;
               }
               if (m_plateSelecting) {
                   setPlateSelecting(false);
                   return;
               }
               if (m_fullScreen) {
                   setFullScreenView(false);
                   return;
               }
               if (previewing()) {
                   leaveSource();
                   return;
               }
               selectTrackClip(-1);
               selectVideoClip(0);
               selectTransition(0);
           });

    // The Edit menu's (setupMenus), in the list.
    m_keyHelp.append({edit, tr("Add a highlight mark at the playhead"),
                      m_addMarkAction->shortcuts(), QString()});
    m_keyHelp.append({edit,
                      tr("Delete the highlight mark at the playhead (one set while recording is "
                         "hidden)"),
                      m_deleteMarkAction->shortcuts(), QString()});

    const QString reframe = tr("Reframe");
    addKey(reframe, tr("Arm / disarm reframe authoring (drags and zooms set keyframes)"),
           {QKeySequence(Qt::Key_A)}, [this] { m_editToolbar->toggleReframeArmed(); });
#ifdef ORBIS_REFRAME_HAVE_TRACKING
    addKey(reframe, tr("Track subject: draw a box around it (again to cancel)"),
           {QKeySequence(Qt::Key_T)}, [this] { setTrackSelecting(!m_trackSelecting); });
#endif
    // With an overlay clip selected, K / Shift+K act on its keys instead (the
    // Overlay panel's Set key / Delete).
    addKey(reframe,
           tr("Set a keyframe at the playhead: the selected overlay's look, else the "
              "current view"),
           {QKeySequence(Qt::Key_K)}, [this] {
               leaveSource(); // the timeline's view and playhead
               if (selectedOverlayClip())
                   setOverlayKeyAtPlayhead();
               else if (m_clipId)
                   m_timeline->upsertClipReframeKey(m_clipId, m_lastPositionMs,
                                                    m_viewport->Pose(),
                                                    playingPane());
           });
    addKey(reframe,
           tr("Delete the keyframe at the playhead: the selected overlay's, else the "
              "reframe one"),
           {QKeySequence(Qt::SHIFT | Qt::Key_K)}, [this] {
               leaveSource(); // the timeline's view and playhead
               if (selectedOverlayClip())
                   deleteOverlayKeyAtPlayhead();
               else if (m_clipId)
                   m_timeline->removeClipReframeKeyNear(m_clipId, m_lastPositionMs,
                                                        playingPane());
           });
    addKey(reframe,
           tr("Delete all keyframes: the selected overlay's, else the video clip's reframe ones"),
           {QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_K)}, [this] {
               leaveSource(); // the timeline's view and playhead
               if (selectedOverlayClip())
                   clearOverlayKeys();
               else if (m_clipId)
                   m_timeline->clearClipReframe(m_clipId, playingPane());
           });

#ifdef ORBIS_REFRAME_HAVE_PLATE_SCAN
    addKey(tr("Privacy"), tr("Blur a plate: draw a box around it (again to cancel or stop)"),
           {QKeySequence(Qt::Key_B)}, [this] { togglePlateBlur(); });
#endif

    // Timeline zoom (also Ctrl+wheel over the timeline).
    const QString view = tr("Timeline view");
    addKey(view, tr("Zoom in"),
           {QKeySequence(Qt::CTRL | Qt::Key_Equal), QKeySequence(Qt::CTRL | Qt::Key_Plus)},
           [this] { m_timelineWidget->zoomIn(); });
    addKey(view, tr("Zoom out"), {QKeySequence(Qt::CTRL | Qt::Key_Minus)},
           [this] { m_timelineWidget->zoomOut(); });
    addKey(view, tr("Zoom to fit"), {QKeySequence(Qt::CTRL | Qt::Key_0)},
           [this] { m_timelineWidget->zoomToFit(); });

    const QString sidebars = tr("Sidebars");
    addKey(sidebars, tr("Open / close the left sidebar (Media)"),
           {QKeySequence(Qt::CTRL | Qt::Key_B)}, [this] { m_sourcesSidebar->toggle(); });
    addKey(sidebars, tr("Open / close the right sidebar (settings)"),
           {QKeySequence(Qt::CTRL | Qt::SHIFT | Qt::Key_B)}, [this] { m_sidebar->toggle(); });
    // The right sidebar's tabs, left to right; the one showing closes it.
    constexpr Qt::Key kDigits[] = {Qt::Key_1, Qt::Key_2, Qt::Key_3, Qt::Key_4, Qt::Key_5,
                                   Qt::Key_6, Qt::Key_7, Qt::Key_8, Qt::Key_9};
    const int tabs = std::min(m_sidebar->count(), 9);
    for (int i = 0; i < tabs; ++i)
        addKey(sidebars,
               i == 0 ? tr("Show a settings tab (Video, Audio, PiP, Overlay, Transition, "
                           "Privacy); again to close the sidebar")
                      : QString(),
               {QKeySequence(Qt::ALT | kDigits[i])}, [this, i] { m_sidebar->toggleTab(i); },
               i == 0 ? QKeySequence(Qt::ALT | Qt::Key_1).toString(QKeySequence::NativeText) +
                            QStringLiteral(" … ") +
                            QKeySequence(Qt::ALT | kDigits[tabs - 1])
                                .toString(QKeySequence::NativeText)
                      : QString());

    QMenu *helpMenu = menuBar()->addMenu(tr("&Help"));
    QAction *manualAction = helpMenu->addAction(tr("&User manual"), this, [] {
        QDesktopServices::openUrl(userManualUrl(QString::fromUtf8(core::version::string())));
    });
    manualAction->setObjectName(QStringLiteral("userManualAction"));
    QAction *keysAction =
        helpMenu->addAction(tr("&Keyboard shortcuts"), this,
                           [this] { showShortcutHelp(this, m_keyHelp, menuBar()); });
    keysAction->setObjectName(QStringLiteral("shortcutHelpAction"));
    keysAction->setShortcut(QKeySequence(Qt::Key_F1));
    helpMenu->addSeparator();
    QAction *aboutAction = helpMenu->addAction(tr("&About orbis-reframe"), this,
                                               [this] {
        showAboutDialog(this, m_viewport, QString::fromStdString(m_audioPlayer->outputDescription()));
    });
    aboutAction->setObjectName(QStringLiteral("aboutAction"));
}

void MainWindow::navigateTo(qint64 timelineMs, bool pause)
{
    if (m_timeline->isEmpty())
        return;
    timelineMs = std::clamp<qint64>(timelineMs, 0, m_timeline->totalDurationMs());
    if (pause && m_playing)
        QMetaObject::invokeMethod(m_controller, "pause", Qt::QueuedConnection);
    QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                              Q_ARG(qint64, timelineMs));
    m_lastTimelineMs = timelineMs;
    showPlayhead(timelineMs);
    bindActiveClipAt(timelineMs);
}

void MainWindow::setFullScreenView(bool on)
{
    if (on == m_fullScreen || (on && m_pages->currentWidget() != m_editorPage))
        return;
    m_fullScreen = on;
    if (on)
        m_wasMaximized = isMaximized();
    // Everything but the viewport and the player bar.
    for (QWidget *w : {static_cast<QWidget *>(menuBar()), static_cast<QWidget *>(m_sourcesSidebar),
                       static_cast<QWidget *>(m_sidebar), static_cast<QWidget *>(m_timelinePane)})
        w->setVisible(!on);
    m_playerBar->setFullScreen(on);
    m_playerBar->setVisible(true);
    if (on) {
        showFullScreen();
        m_playerBarHide->start();
    } else {
        m_playerBarHide->stop();
        if (m_wasMaximized)
            showMaximized();
        else
            showNormal();
    }
}

void MainWindow::showPlayerBarForAWhile()
{
    if (!m_fullScreen)
        return;
    m_playerBar->setVisible(true);
    m_playerBarHide->start();
}

void MainWindow::updatePlayerBar()
{
    if (previewing()) { // a Media tab file's times (showSource)
        m_playerBar->setFrameRate(m_sourceFps);
        m_playerBar->setCuts({});
        return;
    }
    const double firstFps = m_timeline->count() > 0 ? m_timeline->clipAt(0).fps : 0.0;
    m_playerBar->setFrameRate(m_project->output().effectiveFps(firstFps));
    QList<qint64> cuts;
    qint64 t = 0;
    for (int i = 0; i + 1 < m_timeline->count(); ++i) {
        t += m_timeline->clipAt(i).timelineDurationMs();
        cuts.push_back(t);
    }
    m_playerBar->setCuts(cuts);
}

void MainWindow::applyPreviewVolume()
{
    // Squared: the slider's middle sounds about half as loud, not barely quieter.
    const double v = m_playerBar->volume() / 100.0;
    m_audioPlayer->setVolume(m_playerBar->isMuted() ? 0.0f : static_cast<float>(v * v));
}

void MainWindow::splitAtPlayhead()
{
    if (const TrackClip *a = m_selectedTrackClipId > 0
                                 ? m_timeline->trackClipById(m_selectedTrackClipId)
                                 : nullptr) {
        if (m_lastTimelineMs <= a->startMs || m_lastTimelineMs >= a->endMs()) {
            m_editToolbar->showNotice(tr("Move the playhead into the selected clip to split it"),
                                    false);
            return;
        }
        if (const int right = m_timeline->splitTrackClip(a->id, m_lastTimelineMs))
            selectTrackClip(right);
        else
            m_editToolbar->showNotice(tr("Too close to the clip's edge to split"), false);
        return;
    }
    if (!m_clipId)
        return;
    if (editClipId() != m_clipId) {
        m_editToolbar->showNotice(tr("Move the playhead into the selected clip to split it"), false);
        return;
    }
    if (!m_timeline->splitClip(m_clipId, m_lastPositionMs))
        m_editToolbar->showNotice(tr("Too close to the clip's edge to split"), false);
}

void MainWindow::deleteAtPlayhead()
{
    if (m_selectedTransition) {
        m_timeline->removeTransition(m_selectedTransition);
        return;
    }
    if (m_selectedTrackClipId > 0) {
        m_timeline->removeTrackClip(m_selectedTrackClipId);
        return;
    }
    if (m_selectedClipId > 0) {
        m_timeline->removeClip(m_selectedClipId);
        return;
    }
    if (m_clipId)
        m_timeline->removeClipReframeKeyNear(m_clipId, m_lastPositionMs, playingPane());
}

void MainWindow::clearTrim()
{
    if (const TrackClip *a = m_selectedTrackClipId > 0
                                 ? m_timeline->trackClipById(m_selectedTrackClipId)
                                 : nullptr) {
        const int id = a->id;
        const qint64 full = a->sourceDurationMs;
        m_timeline->setTrackClipTrimIn(id, 0); // the start moves back with it
        m_timeline->setTrackClipTrimOut(id, full);
        return;
    }
    if (const int id = editClipId())
        m_timeline->clearClipTrim(id);
}

void MainWindow::putOverlayAudioOnTrack(int clipId)
{
    if (const int id = addOverlayAudio(clipId))
        selectTrackClip(id);
}

int MainWindow::addOverlayAudio(int clipId)
{
    int trackId = 0;
    const TrackClip *o = m_timeline->trackClipById(clipId, &trackId);
    if (!o || m_timeline->trackById(trackId)->kind != Track::Kind::Video || o->isDrawn() ||
        audioStreamCount(o->sourcePath) < 1)
        return 0;
    return m_timeline->addOverlaySound(clipId);
}

const camera::MediaInfo *MainWindow::mediaInfoFor(const QString &path, QString *error)
{
    auto it = m_mediaInfo.constFind(path);
    if (it == m_mediaInfo.constEnd()) {
        camera::MediaInfo info;
        std::string err;
        if (!camera::ProbeMediaInfo(path.toStdString(), info, err)) {
            if (error)
                *error = QString::fromStdString(err);
            return nullptr;
        }
        it = m_mediaInfo.insert(path, info);
    }
    return &*it;
}

void MainWindow::syncMediaInfoPanel(const ClipItem &c)
{
    // A Media tab file previewed is the one on screen (MainWindowSource.cpp).
    if (previewing())
        showMediaInfo(m_sourcePath, true);
    else
        showMediaInfo(c.sourcePath, false);
}

void MainWindow::showMediaInfo(const QString &path, bool previewed)
{
    QString error;
    if (const camera::MediaInfo *info = mediaInfoFor(path, &error))
        m_mediaInfoPanel->setInfo(*info, previewed);
    else
        m_mediaInfoPanel->setError(path, error, previewed);
}

void MainWindow::pushTimelineToController()
{
    pushBlur(); // the clips' trims / sources may have changed
    QList<PlaybackController::Segment> segments;
    segments.reserve(m_timeline->count());
    m_captureTimingOn.clear(); // ids don't survive a load / undo
    for (int i = 0; i < m_timeline->count(); ++i) {
        const ClipItem &c = m_timeline->clipAt(i);
        segments.push_back({c.sourcePath, c.trimInMs, c.trimOutMs, c.speed, c.id, c.flat, c.fps,
                            c.sourceDurationMs, c.lensGuard, c.stitchMethod, c.mediaMissing,
                            c.lensCalibration, c.seamColourBlend, c.seamFlow});
        m_captureTimingOn[c.id] = StabilizerCache::captureTimingOn(c);
    }
    pushInsetsToController(); // flat main clips are drawn as layers
    // Queued lambda (not a slot) so QList<Segment> needs no metatype.
    QMetaObject::invokeMethod(m_controller,
                              [ctrl = m_controller, segments] { ctrl->setTimeline(segments); });
    m_audioPlayer->setTimeline(segments); // GUI-thread resident -- no invokeMethod needed
    ensureStabilizers(); // the stabilizers by the clips' (new) ids
}

void MainWindow::refreshTimelineWidget()
{
    updateMediaInUse();
    QVector<TimelineWidget::Clip> clips;
    clips.reserve(m_timeline->count());
    bool activeHasKeys = false;
    for (int i = 0; i < m_timeline->count(); ++i) {
        const ClipItem &c = m_timeline->clipAt(i);
        TimelineWidget::Clip w;
        w.id = c.id;
        w.label = QFileInfo(c.sourcePath).fileName();
        w.trimInMs = c.trimInMs;
        w.trimOutMs = c.trimOutMs;
        w.sourceDurationMs = c.sourceDurationMs;
        w.missing = c.mediaMissing;
        w.speed = c.speed;
        // A split clip's diamonds are the active pane's keys.
        const ReframeTrack &keys = c.paneTrack(paneOf(c));
        for (qint64 t : keys.keyTimes())
            w.keySourceMs.push_back(t);
        // The file's marks unless it's missing (not read then); the clip's
        // own either way.
        const QList<qint64> camera = c.flat || c.mediaMissing
                                         ? QList<qint64>()
                                         : m_clipFacts->highlights(c.sourcePath);
        for (const ClipItem::Mark &m : c.shownMarks(camera))
            w.marks.push_back({m.sourceMs, m.own});
        for (const qint64 t : c.hiddenMarks)
            w.hiddenMarks += camera.contains(t);
        clips.push_back(std::move(w));
        if (c.id == m_clipId && !keys.isEmpty())
            activeHasKeys = true;
    }
    m_timelineWidget->setClips(clips);
    m_timelineWidget->setActiveClip(editClipId());
    refreshTransitions(); // a trim or speed change moves what they play
    refreshTrackRows();
    m_editToolbar->setHasReframeKeys(activeHasKeys);
    updatePlayerBar();
    m_reframePanel->setClipUnkeyed(m_timeline->clipById(m_clipId) && !activeHasKeys);
    updateExportEnabled();
    updateScreenshotEnabled();
}

void MainWindow::syncTimeline()
{
    pushTimelineToController();
    refreshTimelineWidget();
}

void MainWindow::remapPlayheadAfterEdit()
{
    // A trim / insert / remove / reorder changes the timeline<->source mapping.
    // Rebuild the controller's segments, then re-seek so the frame the user was
    // looking at (this clip's source time m_lastPositionMs) stays under the
    // playhead -- clamped into the clip's new [in, out] if the edit cut past it.
    if (m_rebindingModel || !m_clipId) {
        syncTimeline();
        return;
    }
    const int idx = m_timeline->indexOfId(m_clipId);
    if (idx < 0) { // the clip under the playhead is gone -- let the clamp settle it
        syncTimeline();
        return;
    }
    const ClipItem &c = m_timeline->clipAt(idx);
    const qint64 srcClamped = std::clamp(m_lastPositionMs, c.trimInMs, c.trimOutMs);
    const qint64 newTimelineMs = m_timeline->clipToTimeline(idx, c.localAtSourceMs(srcClamped));

    syncTimeline();

    m_lastPositionMs = srcClamped;
    QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                              Q_ARG(qint64, newTimelineMs));
}

void MainWindow::undo()
{
    if (!m_project->canUndo())
        return;
    m_rebindingModel = true; // suppress the storm of remapPlayheadAfterEdit calls this triggers
    m_project->undo();
    m_rebindingModel = false;
    afterUndoRedo();
}

void MainWindow::redo()
{
    if (!m_project->canRedo())
        return;
    m_rebindingModel = true;
    m_project->redo();
    m_rebindingModel = false;
    afterUndoRedo();
}

void MainWindow::showPlayhead(qint64 timelineMs)
{
    m_playerBar->setPosition(timelineMs);
    m_timelineWidget->setPlayhead(timelineMs);
}

void MainWindow::afterUndoRedo()
{
    // undo()/redo() replace the whole Timeline (Project::applyDocument), so
    // every ClipItem has a fresh id -- rebind by the timeline position the
    // playhead was already at rather than trying to find the "same" clip id.
    syncTimeline();
    bindActiveClipAt(m_lastTimelineMs);
    showPlayhead(m_lastTimelineMs);
    QMetaObject::invokeMethod(m_controller, "seek", Qt::QueuedConnection,
                              Q_ARG(qint64, m_lastTimelineMs));
}

// "*.insv *.mp4 ...": the files the main track takes, 360 clips and flat
// videos, for a file dialog's filter.
static QString clipFileGlobs()
{
    QStringList globs;
    for (const auto kind : {MediaItem::Kind::Clip360, MediaItem::Kind::Video})
        for (const QString &ext : media::extensions(kind))
            globs << QStringLiteral("*.") + ext;
    return globs.join(QLatin1Char(' '));
}

void MainWindow::addClipToTimeline(int index)
{
    const QString path = QFileDialog::getOpenFileName(
        this, tr("Add clip to timeline"),
        m_clipPath.isEmpty() ? QDir::homePath() : QFileInfo(m_clipPath).absolutePath(),
        tr("Videos (%1);;All files (*)").arg(clipFileGlobs()));
    if (!path.isEmpty())
        addClipFiles({path}, index);
}

void MainWindow::addClipFiles(const QStringList &paths, int index)
{
    if (index < 0 || index > m_timeline->count())
        index = m_timeline->count();
    QStringList failed;
    QSet<QString> added; // clips this drop added ...
    QSet<QString> takes; // ... and those reached through another file of their take
    for (const QString &file : paths) {
        // A 360 clip through the clip probe, a flat video through FFmpeg.
        QString why;
        stitch::ClipProbe probe;
        probe.lens_guards = stitch::LensGuardProfiles::all(); // a flat video's
        const std::optional<MediaItem> m = probeMedia(file, &why, m_clipBackend.probe, &probe);
        if (!m || m->kind == MediaItem::Kind::Audio) {
            failed << tr("%1: %2").arg(QFileInfo(file).fileName(),
                                        m ? tr("not a video") : why);
            continue;
        }
        // Another file of a take is its clip; dropped together with the
        // clip's own file or another of its files, the clip goes in once. (A
        // file dropped twice still goes in twice.)
        const QString path = m->path;
        if (path != file ? added.contains(path) : takes.contains(path))
            continue;
        added << path;
        if (path != file)
            takes << path;
        // Into the pool as probed (a take's other files with it); the
        // timeline would add it from the clip's facts alone.
        m_project->mediaPool()->add(*m);
        const bool flat = m->kind == MediaItem::Kind::Video;
        const bool wasEmpty = m_timeline->count() == 0;
        if (!flat)
            m_clipFacts->set(path, probe);
        m_timeline->insertClip(index++, path, m->durationMs, m->fps, m->width, m->height,
                               audioStreamCount(path), flat, probe.lens_guards);
        if (wasEmpty) {
            m_clipPath = path;
            m_fps = m->fps;
        }
    }
    if (!failed.isEmpty())
        QMessageBox::warning(this, tr("Could not add clip"), failed.join(QLatin1Char('\n')));
}

void MainWindow::addMediaToTimeline(const QStringList &paths)
{
    QStringList clips, videos, audio;
    for (const QString &path : paths) {
        const MediaItem *m = m_project->mediaPool()->item(path);
        if (!m || m->missing)
            continue;
        switch (m->kind) {
        case MediaItem::Kind::Clip360:
            clips << path;
            break;
        case MediaItem::Kind::Video:
            videos << path;
            break;
        case MediaItem::Kind::Audio:
            audio << path;
            break;
        }
    }
    // Clips first: overlays and audio need a video track to lie over. Flat
    // videos are overlays over a main clip; with none, they become the
    // main clips.
    if (m_timeline->count() == 0 && clips.isEmpty())
        std::swap(clips, videos);
    if (!clips.isEmpty())
        addClipFiles(clips, -1);
    if (!audio.isEmpty() && m_timeline->count() == 0) {
        QMessageBox::information(this, tr("Add to timeline"),
                                 tr("Audio goes under a video: add a clip to the timeline "
                                    "first."));
        return;
    }
    if (!videos.isEmpty())
        selectAdded(m_trackFiles->addVideo(videos, 0, m_lastTimelineMs));
    if (!audio.isEmpty())
        selectAdded(m_trackFiles->addAudio(audio, 0, m_lastTimelineMs));
}

void MainWindow::locateMedia(const QString &path)
{
    const MediaImporter::Relinks relinks = m_mediaImport->locate(path);
    if (relinks.isEmpty())
        return;
    for (const auto &[from, to] : relinks) {
        QSet<QString> keys;
        for (int i = 0; i < m_timeline->count(); ++i)
            if (m_timeline->clipAt(i).sourcePath == from)
                keys.insert(m_timeline->clipAt(i).plateScan);
        for (const QString &key : keys)
            m_privacy.scans().carryOver(from, to.path, key);
        m_project->relinkMedia(from, to);
        if (m_clipPath == from)
            m_clipPath = to.path;
    }
    refreshClipPanels();
    m_measurements->schedule(); // sync / seam for a clip that had no file until now
    m_mediaImport->showRelinked(relinks);
}

void MainWindow::recheckMissingMedia()
{
    const Project::MediaRecheck r = m_project->recheckMissingMedia();
    if (r.isEmpty())
        return;
    const QStringList &gone = r.gone, &back = r.back;
    bool mainTrack = false;
    for (int i = 0; i < m_timeline->count() && !mainTrack; ++i) {
        const QString &path = m_timeline->clipAt(i).sourcePath;
        mainTrack = gone.contains(path) || back.contains(path) || r.replaced.contains(path);
    }

    // A file that's back is opened afresh: the source cached for it may have
    // lost its file (a drive unplugged). So is one replaced in place: what
    // was read from it -- a source, the black stand-in for a file that
    // couldn't be read, a thumbnail, a failed measurement -- was of the old
    // file. One that's gone keeps playing from what's open as long as it can.
    const QStringList fresh = back + r.replaced;
    m_controller->reopenSources(fresh);
    m_mediaPanel->forgetFiles(fresh);
    m_waveforms->forget(fresh);
    m_clipFacts->forget(fresh);
    m_telemetry->forget(fresh);
    m_measurements->forgetFailures(fresh);
    if (mainTrack)
        syncTimeline(); // the ⚠ marks; a clip that's back plays again
    onTracksChanged(); // the track rows, overlays and sound skip missing clips
    refreshClipPanels();
    if (!fresh.isEmpty())
        m_measurements->schedule(); // sync / seam for a clip that had no file until now

    const auto names = [](QStringList paths) {
        paths.sort();
        for (QString &p : paths)
            p = QFileInfo(p).fileName();
        return paths.join(QStringLiteral(", "));
    };
    // A take is gone when one of its files is: name that one.
    QStringList goneFiles;
    for (const QString &path : gone) {
        const MediaItem *item = m_project->mediaPool()->item(path);
        const QString f = item ? media::firstMissingFile(*item) : QString();
        goneFiles << (f.isEmpty() ? path : f);
    }
    QStringList notice;
    if (!gone.isEmpty())
        notice << tr("File not found: %1").arg(names(goneFiles));
    if (!back.isEmpty())
        notice << tr("Found again: %1").arg(names(back));
    // A replaced file just plays: nothing to tell (and a file being copied
    // over changes at every check).
    if (!notice.isEmpty())
        m_editToolbar->showNotice(notice.join(QStringLiteral(" · ")), false);
}

void MainWindow::updateMediaInUse()
{
    QSet<QString> used;
    for (int i = 0; i < m_timeline->count(); ++i)
        used.insert(m_timeline->clipAt(i).sourcePath);
    for (int i = 0; i < m_timeline->trackCount(); ++i)
        for (const TrackClip &c : m_timeline->trackAt(i).clips)
            used.insert(c.sourcePath);
    m_mediaPanel->setInUse(used);
}


