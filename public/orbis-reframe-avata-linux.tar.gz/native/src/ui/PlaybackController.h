#pragma once

#include <QElapsedTimer>
#include <QList>
#include <QObject>
#include <QString>

#include <IStitchSource.h> // stitch::Frame
#include <LensColour.h>     // insv::LensColour
#include <SeamCorrection.h> // insv::SeamCorrection
#include <LensFrame.h>     // render::LensFrame

#include "InsetFeed.h" // video-track insets
#include "LayerLease.h" // a crossfade's layer reading our sources
#include "../render/FrameStats.h" // ORBIS_FRAME_STATS

#include <QStringList>

#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <thread>

class QTimer;
class EquirectViewportWindow;

namespace stitch {
class IStitchSource;
}

// Plays a *timeline* -- an ordered list of clip segments laid end to end --
// through the stitch sources into the Vulkan viewport. Frames are decoded
// fisheye pairs (render::LensFrame: the viewport renders the view from them)
// whenever both the source and the viewport can share them, else stitched
// equirects. Positions and seeks are in *timeline time* (0 .. total), not any
// single clip's source time; the per-clip trims are baked into each segment's
// [inMs, outMs] source window, so there is no separate "trim" concept here.
//
// Two threads cooperate through a bounded frame queue:
//
//   * a decoder thread runs SeekTo/ReadFrame on the current segment's source,
//     rewrites each frame's timestamp into timeline time, and pushes into
//     m_queue. When a frame reaches the segment's trim-out (or the source
//     hits EOF) it advances to the next segment -- opening that source if the
//     path changed, whose first SeekTo blocks on that clip's first stitch;
//     the "Buffering…" indicator covers it. Consecutive segments that share
//     a source path switch with just a SeekTo.
//
//   * the GUI-facing side (this QObject, on its own worker QThread -- see
//     MainWindow) runs a fixed-cadence present QTimer that only *presents*:
//     wall clock in timeline time, pop the newest frame that isn't in the
//     future, drop the rest.
//
// setTimeline() replaces the whole segment list and may be called repeatedly
// (a trim edit, a project (re)load). It re-clamps the playhead and re-seeks.
// Only the decoder thread ever touches the stitch sources. Opened sources are
// kept in a small LRU cache (kMaxCachedSources) so scrubbing back and forth
// across a clip boundary doesn't re-open (and re-parse the trailer of) the
// same file each time; sources dropped from the timeline entirely are
// released on the next setTimeline(). What a cached source holds on the
// graphics card (an 8K clip's decoders: ~0.9 GB) stays there while the
// card has room and is given back, coldest first, when it hasn't
// (balanceGpuMemory): a large card keeps every clip ready, a small one
// only the clip playing.
class PlaybackController : public QObject {
    Q_OBJECT

public:
    explicit PlaybackController(QObject *parent = nullptr);
    ~PlaybackController() override;

    // Set once, before the first setTimeline(). Not owned.
    void setViewport(EquirectViewportWindow *viewport) { m_viewport = viewport; }
    // What opens a clip's stitch source (ClipBackend::makeSource); the
    // default is stitch::MakeStitchSource. Set before the first clip plays.
    using SourceFactory = std::function<std::unique_ptr<stitch::IStitchSource>()>;
    void setSourceFactory(SourceFactory factory) { m_makeSource = std::move(factory); }

    // One clip on the timeline: a source file and the [in, out) source-time
    // window to play from it. MainWindow builds these from the Timeline.
    // AudioPlayer reuses this same struct for its own setTimeline() (the
    // timeline's length and cuts; the sound is on the audio tracks).
    struct Segment {
        QString sourcePath;
        qint64 inMs = 0;
        qint64 outMs = 0;
        // Playback speed (ClipItem::speed): the segment spans (outMs - inMs) /
        // speed on the timeline. Same rounding as ClipItem::timelineDurationMs.
        double speed = 1.0;
        // The Timeline clip it plays (ClipItem::id): what the per-clip
        // capture timing and stabilization are looked up by, since two clips
        // of one file can differ.
        int clipId = 0;
        // A flat video (ClipItem::flat): played through a BlankClipSource of
        // this rate and length, its picture drawn by the insets.
        bool flat = false;
        double fps = 0.0;
        qint64 sourceDurationMs = 0;
        // The clip's stitch settings (ClipItem::lensGuard / stitchMethod /
        // lensCalibration), the same for every segment of a file; the source
        // is opened with them over the preview config's (setPreviewConfig).
        stitch::PreviewStitchConfig::LensGuard lensGuard = stitch::PreviewStitchConfig::LensGuard::Premium;
        stitch::PreviewStitchConfig::Method stitchMethod = stitch::PreviewStitchConfig::Method::New;
        // The file was gone when the timeline was pushed (ClipItem::
        // mediaMissing): the decoder doesn't try to open it, or open it
        // ahead of time, reports it through openFailed and plays black.
        bool missing = false;
        std::optional<stitch::LensCalibration> lensCalibration;
        bool seamColourBlend = true; // ClipItem::seamColourBlend, as lensGuard
        bool seamFlow = true; // ClipItem::seamFlow, likewise
        qint64 timelineSpanMs() const { return std::llround((outMs - inMs) / speed); }
        qint64 sourceAtLocalMs(qint64 localMs) const { return inMs + std::llround(localMs * speed); }
        qint64 localAtSourceMs(qint64 sourceMs) const
        {
            return std::llround((sourceMs - inMs) / speed);
        }
    };

    // A segment plus its offset on the timeline. Both this controller and
    // AudioPlayer place the same Segment list with placeSegments() and look
    // positions up with segmentAt(), so picture and sound cut at the same
    // instants.
    struct Placed {
        Segment seg;
        qint64 startMs = 0; // timeline offset of seg.inMs
        qint64 durationMs() const { return seg.timelineSpanMs(); }
        qint64 endMs() const { return startMs + durationMs(); }
    };
    // `segments` laid end to end from 0; the timeline's total is the last
    // one's endMs().
    static QList<Placed> placeSegments(const QList<Segment> &segments);
    // Index into `placed` whose timeline span contains `timelineMs` (past the
    // end -> the last); -1 only if `placed` is empty.
    static int segmentAt(const QList<Placed> &placed, qint64 timelineMs);
    // The monotonic clock positionChanged's atNs is on, in ns.
    static qint64 steadyNs()
    {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
                   std::chrono::steady_clock::now().time_since_epoch())
            .count();
    }

    // Replace the timeline. NOT a slot: MainWindow invokes it through a queued
    // lambda (QMetaObject::invokeMethod), so QList<Segment> needs no metatype
    // registration. Runs on the worker thread.
    // While a source is shown (showSource) the timeline is kept, not played:
    // it plays again, from where it was, at showTimeline().
    void setTimeline(const QList<Segment> &segments);
    // A file from the media pool played on its own, not on the timeline
    // (the Media tab's preview): `segment` (its whole length; its clipId is
    // replaced by kSourceClipId) and `insets` (a flat video's full-frame
    // layer) take the timeline's place, paused at the start, until
    // showTimeline(). The timeline's segments, position and insets are kept
    // meanwhile: setTimeline(), setInsets(), seek() and scrub() go on
    // changing them, and seekSource() / scrubSource() move in the source.
    // A source has the stabilization the stab provider gives kSourceClipId
    // (none without), but no reframe path, grade, split screen or region
    // outlines: its view is the viewport's own, looking forward when it
    // starts. Invoked like setTimeline (worker thread).
    // sourceShownChanged comes before the durationChanged / positionChanged
    // of the program switched to.
    static constexpr int kSourceClipId = -1;
    void showSource(Segment segment, std::vector<InsetFeed::Clip> insets);
    void showTimeline();
    // Open these files afresh from the next setTimeline() on, not from the
    // sources cached for them: a file that was gone and is back (a drive
    // plugged in again) left a cached source that can't read any more, and
    // one replaced in place a source of the old file (or the black stand-in
    // for one that couldn't be read). The video tracks' insets reopen them
    // at once.
    void reopenSources(const QStringList &paths);

    // Change the preview-stitch settings (Stitching panel). Like
    // setTimeline(), invoked via a queued lambda so it runs on the worker
    // thread. If the config actually changed and a timeline is loaded, the
    // decoder drops its open sources and re-stitches from the current
    // position under the new cache tag -- a brief "Buffering…" like a cold
    // scrub. No-op if unchanged.
    void setPreviewConfig(const stitch::PreviewStitchConfig &config);

    // Per-clip capture-time correction for the stitch (see
    // stitch::IStitchSource::SetCaptureTiming), by Segment::clipId; replaces
    // the whole set, and a clip not in it = off. Thread-safe, callable from
    // the GUI thread; the decoder applies a clip's timing to its source
    // before the clip's next frame.
    void setCaptureTimings(std::map<int, stitch::CaptureTiming> timings);
    // Seam alignment fine-tune and lens colour for one source
    // (IStitchSource::SetSeamCorrection / SetLensColour). Thread-safe; applies
    // from the next decoded frame -- seek to refresh a paused picture.
    void setSeamCorrection(const QString &path, const insv::SeamCorrection &seam,
                           const insv::LensColour &colour);
    // Privacy blur per clip id (IStitchSource::SetBlurQuads): the whole set,
    // a clip not in it = none. Per clip, not per source, as two clips of one
    // file may differ. Thread-safe; applies from the next decoded frame --
    // seek to refresh a paused picture.
    void setBlurQuads(std::map<int, stitch::BlurQuadsFn> blurs);
    // Clip `clipId`'s blur as set; empty = none. Thread-safe.
    stitch::BlurQuadsFn blurQuads(int clipId);

    // Gyro de-rotation for a presented frame: fills `m` (row-major 3x3) for
    // source time `sourceUs` (exact, in microseconds) of clip `clipId`
    // (Segment::clipId) and returns true, or returns false when it has nothing
    // for that clip (the viewport then keeps its current matrix). Called on
    // the controller thread for every presented frame, with the frame's own
    // source time, and handed to the viewport with the frame. Thread-safe to
    // set from the GUI thread.
    using StabProvider = std::function<bool(int clipId, qint64 sourceUs, float m[9])>;
    void setStabilizationProvider(StabProvider provider);
    // The frame on screen's exact source time (us) if it is clip `clipId`'s:
    // where a paused refresh of its stabilization has to take the matrix.
    // Thread-safe.
    bool shownSourceUs(int clipId, qint64 &sourceUs) const;

    // Region outlines for a presented frame (the Privacy panel's "Show
    // regions"): appends those of source time `sourceMs` of clip `clipId`.
    // Called like the StabProvider, and handed to the viewport with the
    // frame. Empty = none. Thread-safe to set from the GUI thread; seek to
    // refresh a paused picture.
    using OutlineProvider = std::function<void(
        int clipId, qint64 sourceMs, std::vector<EquirectViewportWindow::RegionOutline> &out)>;
    void setOutlineProvider(OutlineProvider provider);

    // The view and colour grade for a presented frame (its clip's reframe
    // path at source time `sourceMs`, its grade). Called like the
    // StabProvider and handed to the viewport with the frame, so a cut
    // changes the view on the frame it changes the picture. Thread-safe to
    // set from the GUI thread.
    using ViewProvider = std::function<void(int clipId, qint64 sourceMs,
                                            EquirectViewportWindow::FrameView &view)>;
    void setViewProvider(ViewProvider provider);

    // The video tracks' inset clips, bottom-most first. Thread-safe,
    // callable from the GUI thread; they're drawn over the view from the next
    // present tick, at the playhead.
    // While a source is shown they're kept for showTimeline().
    void setInsets(std::vector<InsetFeed::Clip> clips);
    // Where a crossfade's layer asks for the source of its clip
    // (renderjobs::insetFeed's `lender`): the decoder lends it the next
    // clip's, sought to the layer's start, and takes it back at the cut; or
    // the clip it plays, once it has read up to its trim-out, and takes it
    // back when the layer is done -- one source for the layer and the clip
    // (LayerLease). Thread-safe.
    std::shared_ptr<LayerLender> layerLender() const { return m_lender; }

public slots:
    void play();
    void pause();
    void togglePlay();
    // Before a job opens its own stitch on the GPU (an export, a subject
    // track, a plate scan): give back graphics memory until there's room
    // for one more clip -- the cached clips' first, and with `evenShown`,
    // while paused, the one on screen too (it comes back on the next play
    // or seek). Nothing on a card with room to spare. A background
    // measurement asks without `evenShown`: the clip on screen must be
    // there again the moment play is pressed.
    void makeGpuRoom(bool evenShown = true);
    // The viewport couldn't import a lens frame (EquirectViewportWindow::
    // lensFramesLost) and takes equirects for a while: paused, the frame on
    // screen is read again, as one; playing, the next reads are anyway.
    void viewportLostLensFrames();
    // seek() and scrub() move the timeline's playhead; while a source is
    // shown, only the position it comes back to (showSource).
    void seek(qint64 timelineMs);
    // seek() / scrub() in the source shown (showSource); nothing otherwise.
    void seekSource(qint64 sourceMs);
    void scrubSource(qint64 sourceMs);
    // A seek while dragging the playhead: shows the source's nearest keyframe
    // (inside the clip's trim) instead of the exact frame -- one decode instead
    // of up to a GOP's worth -- and the drag's final seek() lands on the exact
    // frame. During playback the first scrub pauses and that final seek()
    // resumes, so a drag behaves the same playing or paused.
    void scrub(qint64 timelineMs);
    // Playback speed of the preview (the player bar's 0.25x .. 2x): the clock
    // runs at `rate` times real time. Every frame is still decoded, so a fast
    // rate shows what the decoder keeps up with. Not the clips' own speed
    // (Segment::speed), which is part of the edit.
    void setRate(double rate);

signals:
    // A source couldn't be opened (or is marked missing): its clip plays
    // black. `path` is the file, `clipId` the clip that first asked for it
    // (Segment::clipId), `error` why.
    void openFailed(const QString &path, int clipId, const QString &error);
    // Part of the playing source's stitch runs on the CPU because the GPU
    // part didn't start (IStitchSource::GetGpuFallback): it plays, slowly.
    // `codec` is set when the GPU can't decode the clip's codec at all.
    // May come again for the same file when it's opened again.
    void gpuFallback(const QString &path, int clipId, bool decode, bool stitch,
                     const QString &codec);
    void durationChanged(qint64 totalMs);
    // The playhead is at timelineMs, read at atNs (steadyNs()). While playing
    // the clock runs on from there: a listener on another thread gets this
    // late, and adds the time since atNs to know where the video is now.
    void positionChanged(qint64 timelineMs, qint64 atNs);
    // A seek() or scrub() was applied: the playhead is at timelineMs (clamped
    // to the timeline) from here on. Emitted just before that positionChanged,
    // so a listener on another thread sees it in order with the ticks: every
    // positionChanged before it is from the old position, every one after
    // from the new. AudioPlayer::seek follows this, not the request, so a
    // tick still queued from before the seek can't read as a jump.
    void seeked(qint64 timelineMs);
    void playingChanged(bool playing);
    // showSource() / showTimeline() switched what plays: the position,
    // duration and seek signals after this one are the source's (in source
    // ms) / the timeline's.
    void sourceShownChanged(bool shown);
    // A scrub started (the first scrub() of a drag) or ended (no scrub() for
    // kScrubSettleMs, or playback started): background work that competes
    // for the GPU holds off meanwhile.
    void scrubbingChanged(bool scrubbing);
    // True while the presenter wants a frame it doesn't have (decoder behind,
    // or a new clip still opening). The UI debounces this.
    void bufferingChanged(bool buffering);
    // True while the playback clock is frozen (a seek / stall, until
    // kResumeFrames are queued). Unlike bufferingChanged -- which also fires
    // when a tick merely finds the queue empty while the clock runs on --
    // this is what audio must follow: AudioPlayer::setHold.
    void clockHeldChanged(bool held);

private:
    // A decoded frame (timestamp already rewritten to timeline time) plus the
    // seek generation it was produced for.
    struct QueuedFrame {
        stitch::Frame frame; // timestamp always set; rgba empty for a lens frame
        std::shared_ptr<const render::LensFrame> lens; // set => a lens frame
        uint64_t gen = 0;
        QString sourcePath;  // clip the frame came from
        qint64 sourceMs = 0; // its source time (frame.timestamp_ms is timeline time)
        qint64 sourceUs = 0; // the same, exact (the stabilizer's time)
        int clipId = 0;      // Segment::clipId
    };

    void startDecoder();
    void stopDecoder();
    void decoderLoop();
    // Caller holds m_mx; bumps m_seekGen. `keyframe`: land on the nearest
    // keyframe instead of the exact frame (scrub()).
    void requestSeekLocked(qint64 timelineMs, bool keyframe = false);
    // Paused: is the frame shown at `timelineMs` on screen already, or among
    // the queued lookahead (then the frames before it are dropped, and tick()
    // shows it next)? Either way no seek is needed. Caller holds m_mx.
    enum class Handy { No, OnScreen, Queued };
    Handy frameAtLocked(qint64 timelineMs);
    void settle(); // a scrub's pointer rested: the exact frame
    void tick();                                // present step, on the QObject's thread
    void presentInsets(qint64 timelineMs, bool playing); // tick's inset step
    void setClockHeld(bool held);               // emits clockHeldChanged on change
    // setTimeline's work for the program shown: play `segments` from
    // `positionMs` (clamped). `switched`: a showSource / showTimeline, which
    // also says seeked.
    void applyTimeline(const QList<Segment> &segments, qint64 positionMs, bool switched);
    void seekShown(qint64 ms);
    void scrubShown(qint64 ms);

    // --- decoder-thread helpers ---
    // Returns the open source for `path` (from the small cache, or freshly
    // opened). nullptr + *err set on failure.
    std::shared_ptr<stitch::IStitchSource> acquireSource(const Segment &seg, QString *err);
    // After a read from the active source: emits gpuFallback when part of it
    // has newly fallen back to the CPU (at its open, or at a frame the GPU
    // stitch couldn't allocate for).
    void noteGpuFallback(int clipId);
    // A new, unopened source for `seg`: a BlankClipSource for a flat clip,
    // else m_makeSource's, or the real one. Any thread.
    std::unique_ptr<stitch::IStitchSource> makeSource(const Segment &seg) const;
    // What `seg`'s source is opened with: the preview config with the clip's
    // stitch settings.
    static stitch::PreviewStitchConfig openConfig(stitch::PreviewStitchConfig preview,
                                                  const Segment &seg);
    // Make segment `index` the one being decoded, opening its source if the
    // path changed. A file that can't be opened, or a segment marked missing
    // (not tried), emits openFailed and plays black for its span.
    void switchToSegment(int index);
    // Graphics memory (decoder thread). Gives back the GPU memory of cached
    // sources, least recently used first, until the headroom the driver
    // reports (core::sharedDeviceMemory) is the margin plus `need` --
    // never `keep`'s, nor the active source's unless `includeActive`.
    // Without a budget from the driver every cached source but the active
    // one goes: playback then holds only what it plays (and the prefetch).
    // A source lent to a crossfade's layer is taken back and goes after the
    // cached ones, before the active one.
    void balanceGpuMemory(uint64_t need, bool includeActive, const QString &keep = {});
    // `src` (cached under `path`) gives its GPU memory back; what that freed
    // is noted as the file's need.
    bool releaseSourceGpu(const QString &path, stitch::IStitchSource &src);
    // What `path`'s source takes on the GPU when taken up: measured when it
    // last opened or let go, else the largest any clip took
    // (core::clipGpuBytes), else 0.
    uint64_t sourceGpuNeed(const QString &path) const;
    // A measurement of what `path`'s source takes; also sets
    // core::clipGpuBytes, the largest file's.
    void noteSourceGpuBytes(const QString &path, uint64_t bytes);
    // A released `src` taken up again, its open measured. False when it
    // can't be (its file is gone).
    bool resumeSource(const QString &path, stitch::IStitchSource &src);
    // The active source fell back to the CPU (its open found the graphics
    // memory full) and the card has room for it now: back onto the GPU.
    void retryGpuFallback();
    // After a read of the active source that failed with `err` (not its
    // end): true while the frame is to be tried again -- the decoder holds
    // there, behind "Buffering…" when playing -- false once playing has
    // given up on it (the clip is then taken as ended).
    bool holdFailedRead(const std::string &err, bool playing);
    qint64 clampTimeline(qint64 ms) const {
        return ms < 0 ? 0 : (ms > m_totalMs ? m_totalMs : ms);
    }

    EquirectViewportWindow *m_viewport = nullptr;
    QTimer *m_timer = nullptr;

    // --- presenter-thread (the controller's QThread) only ---
    bool m_haveTimeline = false;
    qint64 m_totalMs = 0;
    qint64 m_positionMs = 0; // timeline time
    QElapsedTimer m_clock;
    qint64 m_clockBaseMs = 0;
    double m_rate = 1.0; // setRate()
    // Timeline ms played since m_clock's restart, at m_rate.
    qint64 clockElapsedMs() const { return std::llround(double(m_clock.nsecsElapsed()) * 1e-6 * m_rate); }
    bool m_presentAfterSeek = false;
    uint64_t m_shownGen = 0; // seek generation of the frame on screen
    qint64 m_shownMs = 0;    // and its timeline time
    int m_shownClipId = 0;   // and clip (Segment::clipId): what a transition's layer goes over
    qint64 m_shownSourceUs = -1; // and its exact source time; -1 = none
    QTimer *m_settleTimer = nullptr; // scrub(): the pointer rested -> settle()
    QTimer *m_scrubEndTimer = nullptr; // scrub(): none for a while -> scrubbingChanged(false)
    bool m_scrubbing = false;
    void setScrubbing(bool on);
    bool m_buffering = false;
    bool m_reachedEnd = false;
    bool m_prerolling = false; // frozen after a stall until kResumeFrames are queued
    bool m_clockHeld = false;  // last clockHeldChanged value
    // ORBIS_FRAME_STATS: while playing, a per-second summary of what the
    // presenter showed and skipped, and what the decoder took per frame.
    struct Stats {
        render::framestats::Clock::time_point windowStart{};
        int shown = 0;
        int skipped = 0;        // decoded but never shown: the clock had passed them
        int bufferingTicks = 0; // ticks spent frozen, waiting for the decoder
        size_t minQueue = SIZE_MAX;
        render::framestats::Samples lateMs; // clock minus the shown frame's time
        render::framestats::Samples stabMs; // the stabilization lookup
    } m_stats;
    void statsTick(bool playing, size_t queued);

    // --- shared with the decoder thread, guarded by m_mx ---
    mutable std::mutex m_mx;
    std::condition_variable m_cv;
    QList<Placed> m_placed;       // authoritative timeline
    bool m_timelineDirty = false; // decoder should re-copy m_placed
    QStringList m_reopenPaths; // drop these cached sources with the next timeline
    stitch::PreviewStitchConfig m_pendingPreviewConfig;
    bool m_previewConfigDirty = false; // decoder should drop sources + re-stitch
    std::deque<QueuedFrame> m_queue;
    size_t m_frameBytes = 0; // size of the last decoded frame; sets the queue cap
    bool m_lensQueue = false; // the last decoded frame was a lens frame (kLensQueueMax cap)
    render::framestats::Samples m_statsReadMs; // ORBIS_FRAME_STATS: decoder read per frame
    std::thread m_decoder;
    bool m_playing = false;
    bool m_stop = false;
    bool m_decoderEof = false;
    bool m_seekPending = false;
    qint64 m_seekTargetMs = 0; // timeline time
    bool m_seekToKeyframe = false; // the pending seek is a scrub (see scrub())
    bool m_resumeAfterScrub = false; // a drag paused playback; the next seek() resumes
    uint64_t m_seekGen = 0;
    // The decoder is seeking: from a seek or a clip boundary until the first
    // frame after it is read. While set, tick() freezes the playhead once the
    // queue runs dry instead of letting the wall clock run on over a frozen
    // picture.
    bool m_hardStall = false;
    // A read failed with an error, not at the clip's end (holdFailedRead):
    // the decoder reads that frame again at m_readRetryAt -- or, a paused
    // lookahead's (m_readParked), at the next play or seek.
    bool m_readFailed = false;
    bool m_readParked = false;
    std::chrono::steady_clock::time_point m_readRetryAt;
    bool m_gpuRoomPending = false; // makeGpuRoom: the decoder makes room
    bool m_gpuRoomEvenShown = false; // ... the active source's too, if paused

    // --- decoder-thread only ---
    static constexpr int kMaxCachedSources = 4;
    QList<Placed> m_decPlaced;
    // Preview-stitch config the decoder opens sources with. Updated from
    // m_pendingPreviewConfig when m_previewConfigDirty is seen.
    stitch::PreviewStitchConfig m_decPreviewConfig;
    SourceFactory m_makeSource;
    int m_decSegIndex = -1;
    qint64 m_decLastSourceMs = -1; // source time of the last frame read; -1 after a seek
    int m_readRetries = 0; // holdFailedRead's tries while playing, since the last good read
    std::map<QString, std::shared_ptr<stitch::IStitchSource>> m_srcCache;
    QStringList m_srcLru; // paths, least-recently-used first
    // Graphics memory (balanceGpuMemory): what each file's source took on
    // the GPU (noteSourceGpuBytes), when it was last checked, and whether the last check found
    // too little with nothing left to give back (said once until it eases).
    std::map<QString, uint64_t> m_srcGpuBytes;
    std::chrono::steady_clock::time_point m_lastGpuCheck;
    bool m_gpuShortSaid = false;
    std::chrono::steady_clock::time_point m_gpuRetryAt; // retryGpuFallback's next try
    std::shared_ptr<stitch::IStitchSource> m_activeSource;
    QString m_activePath;
    // What of the active source has been reported as fallen back to the CPU
    // (noteGpuFallback), and for which source.
    std::weak_ptr<stitch::IStitchSource> m_fallbackSource;
    stitch::GpuFallback m_fallbackSeen;

    // The next segment's source, sought and its first frame read on a worker
    // thread shortly before the boundary, so the cut doesn't wait for the
    // seek's decode (startPrefetch / takePrefetch). The source is the
    // job's own until taken: a cached one is moved out of m_srcCache, and a
    // jump within the active file opens a second one.
    struct Prefetch {
        int segIndex = -1;
        QString path;
        std::shared_ptr<stitch::IStitchSource> src;
        bool opened = false; // src open, SeekTo done, the read below tried
        stitch::Frame frame;
        std::shared_ptr<render::LensFrame> lens;
        bool got = false;
        bool stale = false; // a seek / edit since: dropped once done
        // A crossfade's layer asked for the source: sought to its start
        // and lent to it (`lent`) instead of the read above.
        std::shared_ptr<LayerLease> lease;
        bool lent = false;
        std::future<void> done; // last: destroyed (waited for) first
    };
    std::unique_ptr<Prefetch> m_prefetch;
    // The segment startPrefetch found no graphics memory for: not tried
    // again until the next seek or edit (invalidatePrefetch).
    int m_prefetchDeclined = -1;
    // A read already made for the active segment (a taken prefetch's first
    // frame); the decoder's next read returns it.
    struct HeldRead {
        stitch::Frame frame;
        std::shared_ptr<render::LensFrame> lens;
        bool got = false;
    };
    std::optional<HeldRead> m_heldRead;

    // Capture-timing settings per clip id, written by the GUI thread.
    using RsSetting = stitch::CaptureTiming;
    std::mutex m_stabMx;
    StabProvider m_stabProvider; // guarded by m_stabMx
    OutlineProvider m_outlineProvider; // guarded by m_stabMx
    ViewProvider m_viewProvider;       // guarded by m_stabMx
    std::mutex m_rsMx;
    std::map<int, RsSetting> m_rsSettings; // guarded by m_rsMx
    // guarded by m_rsMx, same generation
    std::map<QString, std::pair<insv::SeamCorrection, insv::LensColour>> m_seamCorrection;
    std::map<int, stitch::BlurQuadsFn> m_blurQuads;        // guarded by m_rsMx, same generation
    std::atomic<uint64_t> m_rsGen{0};          // bumped on every change
    uint64_t m_decRsGen = ~uint64_t(0);        // decoder: generation last applied
    QString m_decRsPath;                        // decoder: source it was applied to
    int m_decRsClipId = 0;                      // decoder: clip it was applied for
    // The hand-over to the next clip in the same file, if any (see
    // ClipHandOver): what was applied, so a timeline edit re-applies.
    qint64 m_decRsUntilMs = 0;
    int m_decRsAfterClipId = 0;
    void applyCaptureTimingIfChanged();         // decoder thread
    // Where segment `index`'s source hands over to the next segment's capture
    // timing: the next segment reads on in the same file (a split), so the
    // frame that crosses the cut -- read before the decoder knows it crosses
    // -- is stitched with the next clip's timing, not this one's. No
    // hand-over: untilMs = INT64_MAX. Decoder thread (reads m_decPlaced).
    struct ClipHandOver {
        qint64 untilMs = INT64_MAX;
        int afterClipId = 0;
    };
    ClipHandOver handOverAfter(int index) const;
    // Reads m_rsMx: `path`'s settings, and clip `clipId`'s capture timing
    // and blur (then `handOver.afterClipId`'s from `handOver.untilMs` on).
    void applySourceSettings(stitch::IStitchSource &src, const QString &path, int clipId,
                             ClipHandOver handOver);

    // Before m_insets, whose clips hold it.
    std::shared_ptr<LayerLender> m_lender;
    // The insets' own decoder, and what was last handed to the viewport
    // (frame key + look per inset) so an unchanged picture isn't re-sent.
    InsetFeed m_insets;
    // The timeline program while a source is shown (showSource): its
    // segments and playhead (presenter thread) and its insets (setInsets
    // is called from the GUI thread: guarded by m_programMx, as is
    // m_sourceShown, which the presenter thread also reads without it).
    QList<Segment> m_timelineSegments;
    qint64 m_timelinePositionMs = 0;
    std::mutex m_programMx;
    std::vector<InsetFeed::Clip> m_timelineInsets;
    std::atomic<bool> m_sourceShown{false};
    bool m_sourceLookForward = false; // the source's next frame shown looks forward
    std::vector<EquirectViewportWindow::InsetDraw> m_lastInsets;

    void touchSourceLru(const QString &path);   // decoder thread
    void pruneSourcesToTimeline();               // decoder thread
    void setHardStall(bool on);                   // decoder thread
    void startPrefetch(const Placed &cur, qint64 timelineMs); // decoder thread
    // Room on the graphics card to open segment `next` ahead of the cut;
    // else it's declined until the next seek or edit (m_prefetchDeclined).
    bool roomForPrefetch(int next);                 // decoder thread
    // Open segment `next` ahead of the cut on a worker: its first frame
    // read, or with `lease` sought to the layer's start and lent to it.
    void launchPrefetch(int next, std::shared_ptr<LayerLease> lease); // decoder thread
    // Answer the layers' asks (LayerLender): a first half's when its clip
    // comes next and nothing has read it ahead yet (or it can be sought
    // back in time), a second half's at the playing clip's trim-out
    // (lendAtTrimOut); else decline.
    void serveLayerAsks(bool playing);              // decoder thread
    enum class LayerAnswer { Lent, Declined, Later };
    LayerAnswer lendForLayer(const std::shared_ptr<LayerLease> &lease); // decoder thread
    // Asks answered Later: a prefetch job still running, or the clip a
    // second half blends out still playing. Answered again on each pass
    // (playing, the decoder wakes for every frame shown; paused, they're
    // declined). Decoder thread.
    std::vector<std::shared_ptr<LayerLease>> m_layerAsksLater;
    // Does `lease` want `seg`'s frames from its trim-out on?
    bool wantsPastTrimOut(const LayerLease &lease, const Segment &seg) const;
    // The active clip's last frame is read and a crossfade's second half
    // wants the frames past it: its source lent there (m_lentOut) instead
    // of read on. The caller goes on to the next segment.
    bool lendAtTrimOut(const Placed &cur);
    // The source lent past its trim-out back into the cache, once its layer
    // is done or (`force`) now: its file wanted again, a seek or an edit.
    void takeBackLentOut(bool force);
    // Make segment `next` the one decoded, from its trim-in: the prefetch's
    // source if it has one, else opened and sought.
    void goToSegment(int next);
    struct LentOut {
        QString path;
        std::shared_ptr<stitch::IStitchSource> src;
        std::shared_ptr<LayerLease> lease;
    };
    std::optional<LentOut> m_lentOut;
    bool takePrefetch(int next);                  // decoder thread
    void invalidatePrefetch();                    // decoder thread
};
