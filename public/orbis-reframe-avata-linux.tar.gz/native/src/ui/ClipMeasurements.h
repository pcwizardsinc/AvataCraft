#pragma once

#include <QHash>
#include <QObject>
#include <QString>
#include <QStringList>

#include <atomic>

class QThread;
class Project;
struct ClipItem;
namespace stitch {
enum class MeasureFailure;
}

// The per-source measurements run in the background: the gyro sync
// fine-tune (stitch::MeasureClipSync, only with ORBIS_REFRAME_HAVE_CLIP_SYNC),
// the seam alignment (stitch::MeasureClipSeam) and, once that is done, the
// lens colour (stitch::MeasureClipLensColour, which needs the lenses lined
// up), then the seam analysis of the clips' stretches of the source
// (stitch::AnalyseClipSeam, for the depth-aware seam: it depends on both),
// one of each kind at a time, for the timeline's sources in order, the
// playhead's source first. A sync / seam / colour result lands on the
// Timeline (setSourceSyncAdjust / setSourceSeamCorrection /
// setSourceLensColour), whose clipSyncChanged / clipSeamChanged say what to
// rebuild; the seam analysis lands in its cache (stitch::SeamAnalysisFor),
// where every stitch of the source finds it, and seamAnalysed() says so.
//
// They run when a clip is added or a project opened, never while playing:
// a measurement competes with playback for the GPU and shows as a hitch.
// One running when play starts is cancelled (it would stall playback its
// whole run) and starts over on the pause; the seam analysis goes on from
// where it stopped. The sync and the seam analysis stitch on the graphics
// card, so they start only while it has room for them (roomForAnother):
// beside an export, or on a card with little memory, they wait.
class ClipMeasurements : public QObject {
    Q_OBJECT

public:
    // `enabled` false (tests): nothing is ever measured.
    ClipMeasurements(Project *project, bool enabled, QObject *parent = nullptr);
    // Cancels a running measurement and waits for it.
    ~ClipMeasurements() override;

    // Start whichever measurement is due next. Runs after the current event
    // (a load or add finishes first); not while playing.
    void schedule();
    // Playing: cancel the running ones. Paused: schedule() again.
    void setPlaying(bool playing);
    // Scrubbing (PlaybackController::scrubbingChanged) likewise: the GPU is
    // the scrub's.
    void setScrubbing(bool scrubbing);
    // A job needs the graphics memory (an export, ...): the measurements on
    // the GPU running now stop (the seam analysis keeps what it has done)
    // and none starts while the job runs (core::GpuJobScope).
    void yieldGpu();
    // The source under the playhead: measured first.
    void setPriorityPath(const QString &clipPath);
    // A source's lens-guard setting changed: its seam and colour
    // measurements, if they failed, may work under the new one.
    void forgetSeamFailure(const QString &clipPath)
    {
        m_seamFailed.remove(clipPath);
        m_colourFailed.remove(clipPath);
        m_analysisFailed.remove(clipPath);
    }
    // These files were replaced in place or are back after they were gone:
    // a measurement that failed on what was there may work now.
    void forgetFailures(const QStringList &clipPaths)
    {
        for (const QString &p : clipPaths) {
            m_syncFailed.remove(p);
            m_seamFailed.remove(p);
            m_colourFailed.remove(p);
            m_analysisFailed.remove(p);
        }
    }

    // The Stabilization / Stitching panels' status lines for clip `c` (null =
    // none): measured, measuring, failed, or empty.
    QString syncStatus(const ClipItem *c) const;
    // The Stitching panel's one line for the seam alignment and the lens
    // colour together; `details` (optional) gets the measured figures, for
    // its tooltip.
    QString stitchStatus(const ClipItem *c, QString *details = nullptr) const;

signals:
    // A measurement started or finished: the status lines changed.
    void statusChanged();
    // More of `clipPath`'s seam analysis is done (a pass finished or stopped).
    void seamAnalysed(const QString &clipPath);
    // A measurement on the GPU is waiting for graphics memory: playback may
    // give back what its idle clips hold (PlaybackController::makeGpuRoom).
    void gpuRoomWanted();

private:
    void maybeMeasureSync(const QString &clipPath);
    void maybeMeasureSeam(const QString &clipPath);
    void maybeMeasureColour(const QString &clipPath);
    void maybeAnalyseSeam(const QString &clipPath);
    // A measurement on the GPU (the sync, the seam analysis) may start: no
    // job on the GPU runs (core::gpuJobRunning), and the graphics card has room for one more clip
    // (core::clipGpuBytes) beside its margin -- without a budget from the
    // driver, when neither runs. Else asks for room (gpuRoomWanted, not
    // during a job) and schedules again shortly.
    bool roomForAnother();
    bool m_roomRetry = false; // roomForAnother's schedule() pending
    // The first main-track clip cut from `clipPath`, if its file is there.
    const ClipItem *measurableClip(const QString &clipPath) const;
    static bool usesOldStitcher(const ClipItem &c);
    // Why a measurement failed, in plain words for the status lines; the
    // technical text goes to the log. `seam`: the seam's, else the sync's.
    static QString failureText(stitch::MeasureFailure why, bool seam);

    Project *m_project;
    bool m_enabled;
    bool m_playing = false;
    bool m_scrubbing = false;
    bool m_queued = false; // schedule() already pending

    QThread *m_syncThread = nullptr;
    QString m_syncMeasuringPath;
    std::atomic<bool> m_syncCancel{false};
    // Sources that gave no result this session, with why, for the panel:
    // each its own, two clips can fail differently.
    QHash<QString, stitch::MeasureFailure> m_syncFailed;

    QThread *m_seamThread = nullptr;
    QString m_seamMeasuringPath;
    std::atomic<bool> m_seamCancel{false};
    QHash<QString, stitch::MeasureFailure> m_seamFailed; // as m_syncFailed

    QThread *m_colourThread = nullptr;
    QString m_colourMeasuringPath;
    std::atomic<bool> m_colourCancel{false};
    QHash<QString, stitch::MeasureFailure> m_colourFailed; // as m_syncFailed

    QThread *m_analysisThread = nullptr;
    QString m_analysisPath;
    std::atomic<bool> m_analysisCancel{false};
    std::atomic<int> m_analysisPermille{0}; // its progress
    QHash<QString, QString> m_analysisFailed; // the technical reason, for the log
    QString m_priorityPath;
};
