#include "ClipViewSource.h"

#include <NativeStitchSource.h>
#include <ReframeRenderer.h> // exportpipe::RenderRectilinear

#include <algorithm>
#include <cmath>
#include <utility>

ClipViewSource::ClipViewSource(Spec spec) : m_spec(std::move(spec)) {}

ClipViewSource::~ClipViewSource() = default;

bool ClipViewSource::open(std::string &err)
{
    prepare();
    return openOwn(err);
}

void ClipViewSource::prepare()
{
    const ReframeExportController::ClipJob &job = m_spec.job;
    if (!job.stab && m_spec.buildStab.mode != insv::StabMode::Off)
        m_spec.job.stab = ReframeExportController::buildStabilizer(job.clipPath, m_spec.buildStab,
                                                                   m_spec.syncMs);
    if (m_spec.fps > 0.0)
        m_fps = m_spec.fps;
}

bool ClipViewSource::openOwn(std::string &err, bool cpuDecode)
{
    const ReframeExportController::ClipJob &job = m_spec.job;
    stitch::PreviewStitchConfig sc;
    sc.width = m_spec.stitchWidth & ~1;
    sc.height = sc.width / 2 & ~1;
    sc.lensGuard = job.lensGuard;
    sc.lensCalibration = job.lensCalibration;
    sc.method = job.stitchMethod;
    sc.seamColourBlend = job.seamColourBlend;
    sc.seamFlow = job.seamFlow;
    m_src = std::make_unique<stitch::NativeStitchSource>();
    m_src->SetCpuDecode(cpuDecode);
    if (!m_src->Open(job.clipPath.toStdString(), sc)) {
        err = m_src->GetLastError();
        m_src.reset();
        return false;
    }
    m_src->SetCaptureTiming(ReframeExportController::captureTimingFor(job.stab));
    m_src->SetSeamCorrection(job.seamCorrection);
    m_src->SetLensColour(job.lensColour);
    if (job.blur && !m_src->SetBlurQuads(job.blur)) {
        err = "this stitch can't apply the privacy blur: " + job.clipPath.toStdString();
        m_src.reset();
        return false;
    }
    if (m_src->GetInfo().fps > 0.0)
        m_fps = m_src->GetInfo().fps;
    return true;
}

void ClipViewSource::setOutputSize(int width, int height)
{
    m_w = std::max(4, width & ~3); // the fused pass's needs
    m_h = std::max(2, height & ~1);
}

bool ClipViewSource::read(exportpipe::VideoFrame &out)
{
    if (!m_src)
        return false;
    if (readFrom(*m_src, out))
        return true;
    m_error = m_src->GetLastError(); // empty at the end of the clip
    return false;
}

bool ClipViewSource::readFrom(stitch::NativeStitchSource &src, exportpipe::VideoFrame &out)
{
    const ReframeExportController::ClipJob &job = m_spec.job;
    // The view and stabilization at the frame's own time, as the export.
    auto poseAt = [&job](const insv::FramePts &pts, view::Pose &pose, float stab[9]) {
        if (job.poseAt)
            job.poseAt(pts.ms, pose);
        if (job.stab) {
            float m[3][3];
            job.stab->correctionMatrix(pts.sec(), m);
            std::copy(&m[0][0], &m[0][0] + 9, stab);
        }
    };
    stitch::Frame f;
    if (src.GpuViewAvailable()) {
        ReframeExportController::applyPanes(src, job, m_w, m_h); // at this size
        f = src.ReadViewFrame(m_w, m_h, poseAt, &job.colorGrade);
    } else {
        const stitch::Frame eq = src.ReadFrame();
        if (!eq.rgba.empty()) {
            exportpipe::ReframeView view;
            poseAt({eq.timestamp_ms, eq.timestamp_us}, view.pose, view.stab);
            view.aspect = float(m_w) / m_h;
            view.colorGrade = job.colorGrade;
            f.rgba.resize(size_t(m_w) * m_h * 4);
            const std::vector<exportpipe::PaneView> panes =
                ReframeExportController::paneViews(job, m_w, m_h, eq.timestamp_ms, view.pose);
            if (panes.empty())
                exportpipe::RenderRectilinear(eq.rgba.data(), eq.width, eq.height, f.rgba.data(),
                                              m_w, m_h, view);
            else
                exportpipe::RenderRectilinearPanes(eq.rgba.data(), eq.width, eq.height,
                                                   f.rgba.data(), m_w, m_h, panes,
                                                   ReframeExportController::fillRgba(job.split),
                                                   view);
            f.width = m_w;
            f.height = m_h;
            f.timestamp_ms = eq.timestamp_ms;
            f.timestamp_us = eq.timestamp_us;
        }
    }
    if (f.rgba.empty())
        return false;
    out.ptsMs = f.timestamp_ms;
    out.width = f.width;
    out.height = f.height;
    out.rgba = std::move(f.rgba);
    return true;
}

const exportpipe::VideoFrame *ClipViewSource::frameAt(int64_t ms)
{
    if (!m_src)
        return nullptr;
    const double halfFrame = 500.0 / m_fps;
    // Behind the frame shown, or well ahead of it: jump there. The source
    // seeks to the first frame at or after a time, so half a frame early:
    // that's the frame whose window holds `ms`, as below. At `ms` itself it
    // can be the next one, which at a transition layer's end lies past the
    // layer's span.
    if (!m_haveCur || ms + halfFrame < m_cur.ptsMs || ms > m_cur.ptsMs + 1000) {
        m_haveCur = m_haveNext = false;
        if (!m_src->SeekTo(std::max<int64_t>(0, std::llround(ms - halfFrame)))) {
            m_error = m_src->GetLastError();
            return nullptr;
        }
        if (!read(m_cur))
            return nullptr;
        m_haveCur = true;
        return &m_cur;
    }
    // Else on: the frame whose time window [pts - half, pts + half) holds
    // `ms`, as the export conforms the main clip's.
    for (;;) {
        if (!m_haveNext) {
            if (!read(m_next))
                break; // the end: the last one stays
            m_haveNext = true;
        }
        if (m_next.ptsMs - halfFrame > ms)
            break;
        std::swap(m_cur, m_next);
        m_haveNext = false;
    }
    return &m_cur;
}

bool ClipViewSource::readNext(exportpipe::VideoFrame &out)
{
    if (m_haveNext) {
        out = std::move(m_next);
        m_haveNext = false;
        return true;
    }
    return read(out);
}
