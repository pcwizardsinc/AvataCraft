#include "Project.h"

#include "LensCalibrationJson.h"
#include "TitleClock.h"

#include "MediaPool.h"
#include "Timeline.h"

#include <limits>
#include <cmath>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSaveFile>

#include <nlohmann/json.hpp>

#include <algorithm>
#include <exception>
#include <functional>
#include <vector>

using nlohmann::json;

namespace {

// Store a source path relative to the project directory when it sits inside
// it, absolute otherwise -- so a project folder stays portable but a clip
// elsewhere on disk still resolves.
QString storedPath(const QString &sourcePath, const QDir &projectDir)
{
    const QString abs = QFileInfo(sourcePath).absoluteFilePath();
    const QString rel = projectDir.relativeFilePath(abs);
    if (!rel.startsWith(QStringLiteral("../")) && !QDir::isAbsolutePath(rel))
        return rel;
    return abs;
}

QString resolvedPath(const QString &stored, const QDir &projectDir)
{
    if (QDir::isAbsolutePath(stored))
        return QDir::cleanPath(stored);
    return QDir::cleanPath(projectDir.absoluteFilePath(stored));
}

const char *lensGuardName(stitch::PreviewStitchConfig::LensGuard g)
{
    return g == stitch::PreviewStitchConfig::LensGuard::None       ? "none"
           : g == stitch::PreviewStitchConfig::LensGuard::Standard ? "standard"
                                                                  : "premium";
}

// An unknown or missing name leaves `g` as it is.
void lensGuardFromJson(const json &j, stitch::PreviewStitchConfig::LensGuard &g)
{
    const std::string guard = j.value("lensGuard", std::string());
    if (guard == "none")
        g = stitch::PreviewStitchConfig::LensGuard::None;
    else if (guard == "standard")
        g = stitch::PreviewStitchConfig::LensGuard::Standard;
    else if (guard == "premium")
        g = stitch::PreviewStitchConfig::LensGuard::Premium;
}

json previewStitchToJson(const stitch::PreviewStitchConfig &c)
{
    return json{
        {"width", c.width},
        {"height", c.height},
        {"lensGuard", lensGuardName(c.lensGuard)},
        {"depthSeam", c.depthSeam()},
    };
}

stitch::PreviewStitchConfig previewStitchFromJson(const json &j)
{
    stitch::PreviewStitchConfig c; // defaults for any missing field
    c.method = Project::kOlderFileStitchMethod;
    if (!j.is_object())
        return c;
    c.width = j.value("width", c.width);
    c.height = j.value("height", c.height);
    lensGuardFromJson(j, c.lensGuard);
    c.method = j.value("depthSeam", c.depthSeam()) ? stitch::PreviewStitchConfig::Method::DepthSeam
                                                   : stitch::PreviewStitchConfig::Method::FixedSeam;
    return c;
}

// A source's measured seam fine-tune. "method" says which estimator measured
// it; one from an older estimator (no "method": lens-1 rotation only) isn't
// read back, so the clip is measured again.
json seamAdjustToJson(const insv::SeamCorrection &c, int lensGuard)
{
    return json{
        {"deg", {c.lens1RotDeg[0], c.lens1RotDeg[1], c.lens1RotDeg[2]}},
        {"centre", {c.lens1Centre[0], c.lens1Centre[1]}},
        {"scale", c.radialScale},
        {"lensGuard", lensGuard},
        {"method", insv::kSeamCorrectionMethod},
    };
}

bool seamAdjustFromJson(const json &j, insv::SeamCorrection &c, int &lensGuard)
{
    if (!j.is_object() || j.value("method", 1) != insv::kSeamCorrectionMethod ||
        !j.contains("deg") || !j.at("deg").is_array() || j.at("deg").size() != 3 ||
        !j.contains("centre") || !j.at("centre").is_array() || j.at("centre").size() != 2 ||
        !j.contains("scale") || !j.at("scale").is_number() || !j.contains("lensGuard") ||
        !j.at("lensGuard").is_number_integer())
        return false;
    for (int k = 0; k < 3; ++k)
        c.lens1RotDeg[k] = j.at("deg")[k].get<double>();
    for (int k = 0; k < 2; ++k)
        c.lens1Centre[k] = j.at("centre")[k].get<double>();
    c.radialScale = j.at("scale").get<double>();
    lensGuard = j.at("lensGuard").get<int>();
    return true;
}

// A source's measured lens colour, likewise with the estimator's "method".
json lensColourToJson(const insv::LensColour &c, int lensGuard)
{
    return json{
        {"logRatio", {c.logRatio[0], c.logRatio[1], c.logRatio[2]}},
        {"slope", {c.slope[0], c.slope[1], c.slope[2]}},
        {"spread", c.spread},
        {"lensGuard", lensGuard},
        {"method", insv::kLensColourMethod},
    };
}

bool lensColourFromJson(const json &j, insv::LensColour &c, int &lensGuard)
{
    auto triple = [&j](const char *key) {
        return j.contains(key) && j.at(key).is_array() && j.at(key).size() == 3 &&
               j.at(key)[0].is_number() && j.at(key)[1].is_number() && j.at(key)[2].is_number();
    };
    if (!j.is_object() || j.value("method", 0) != insv::kLensColourMethod || !triple("logRatio") ||
        !triple("slope") || !j.contains("spread") || !j.at("spread").is_number() ||
        !j.contains("lensGuard") || !j.at("lensGuard").is_number_integer())
        return false;
    for (int k = 0; k < 3; ++k) {
        c.logRatio[k] = j.at("logRatio")[k].get<double>();
        c.slope[k] = j.at("slope")[k].get<double>();
    }
    c.spread = j.at("spread").get<double>();
    lensGuard = j.at("lensGuard").get<int>();
    return true;
}

json stabilizationToJson(const insv::StabConfig &c)
{
    json j{
        {"mode", insv::stabModeToString(c.mode)},
        {"windowYawSec", c.windowYawSec},
        {"windowPitchSec", c.windowPitchSec},
        {"windowRollSec", c.windowRollSec},
        {"horizonLockAmount", c.horizonLockAmount},
        {"horizonGain", c.horizonGain},
        {"accelLowPassHz", c.accelLowPassHz},
        {"pitchOffsetRad", c.pitchOffsetRad},
        {"rollOffsetRad", c.rollOffsetRad},
        {"autoLevel", c.autoLevel},
    };
    if (c.lockDirection) {
        j["lockDirection"] = true;
        j["directionSec"] = c.directionSec;
    }
    return j;
}

json outputToJson(const OutputSettings &o)
{
    const char *aspect = o.aspect == OutputSettings::Aspect::Portrait9x16 ? "9:16"
                         : o.aspect == OutputSettings::Aspect::Square1x1  ? "1:1"
                         : o.aspect == OutputSettings::Aspect::Classic4x3 ? "4:3"
                                                                          : "16:9";
    json j{{"aspect", aspect}, {"width", o.width}, {"height", o.height}, {"fps", o.fps}};
    if (o.tenBit)
        j["bitDepth"] = 10;
    return j;
}

OutputSettings outputFromJson(const json &j)
{
    OutputSettings o; // defaults for any missing field
    if (!j.is_object())
        return o;
    const std::string aspect = j.value("aspect", std::string("16:9"));
    if (aspect == "9:16")
        o.aspect = OutputSettings::Aspect::Portrait9x16;
    else if (aspect == "1:1")
        o.aspect = OutputSettings::Aspect::Square1x1;
    else if (aspect == "4:3")
        o.aspect = OutputSettings::Aspect::Classic4x3;
    const auto def = OutputSettings::presets(o.aspect)[OutputSettings::defaultPresetIndex()];
    o.width = j.value("width", def.w);
    o.height = j.value("height", def.h);
    if (o.width < 16 || o.height < 16) { // nonsense -> the aspect's default size
        o.width = def.w;
        o.height = def.h;
    }
    o.fps = std::max(0.0, j.value("fps", 0.0));
    o.tenBit = j.value("bitDepth", 8) == 10;
    return o;
}

insv::StabConfig stabilizationFromJson(const json &j)
{
    insv::StabConfig c; // defaults for any missing field
    if (!j.is_object())
        return c;
    c.mode = insv::stabModeFromString(j.value("mode", std::string("off")));
    c.windowYawSec = j.value("windowYawSec", c.windowYawSec);
    c.windowPitchSec = j.value("windowPitchSec", c.windowPitchSec);
    c.windowRollSec = j.value("windowRollSec", c.windowRollSec);
    c.horizonLockAmount = j.value("horizonLockAmount", c.horizonLockAmount);
    c.horizonGain = j.value("horizonGain", c.horizonGain);
    c.accelLowPassHz = j.value("accelLowPassHz", c.accelLowPassHz);
    c.pitchOffsetRad = j.value("pitchOffsetRad", c.pitchOffsetRad);
    c.rollOffsetRad = j.value("rollOffsetRad", c.rollOffsetRad);
    c.autoLevel = j.value("autoLevel", c.autoLevel); // absent (older files) => on
    c.lockDirection = j.value("lockDirection", c.lockDirection);
    c.directionSec = j.value("directionSec", c.directionSec);
    return c;
}

json reframeToJson(const ReframeTrack &track)
{
    json keys = json::array();
    for (const ReframeKey &k : track.keys()) {
        json jk{{"tMs", static_cast<qint64>(k.timeMs)},
                {"yaw", k.pose.yaw},
                {"pitch", k.pose.pitch},
                {"roll", k.pose.roll},
                {"diag", k.pose.fov}};
        if (!k.pose.distortionIsAuto())
            jk["distortion"] = k.pose.distortion;
        if (k.ease != keytrack::Ease::Linear)
            jk["ease"] = keytrack::easeName(k.ease);
        keys.push_back(std::move(jk));
    }
    return json{{"keys", std::move(keys)}};
}

// `version` is the file's; before kWideViewFormatVersion a key held the
// vertical angle of a rectilinear view of `aspect` (the output's, or its
// pane's): it takes the diagonal that frames the same corners, and the
// automatic distortion.
std::vector<ReframeKey> reframeKeysFromJson(const json &j, int version, double aspect)
{
    std::vector<ReframeKey> keys;
    if (!j.is_object() || !j.contains("keys") || !j.at("keys").is_array())
        return keys;
    for (const json &jk : j.at("keys")) {
        ReframeKey k;
        k.timeMs = jk.value("tMs", qint64(0));
        k.pose.yaw = jk.value("yaw", 0.0f);
        k.pose.pitch = jk.value("pitch", 0.0f);
        k.pose.roll = jk.value("roll", 0.0f);
        if (version >= Project::kWideViewFormatVersion) {
            k.pose.fov = jk.value("diag", k.pose.fov);
            if (jk.contains("distortion"))
                k.pose.distortion = std::clamp(jk.value("distortion", 0.0f), 0.0f, 1.0f);
        } else {
            k.pose.fov = view::fovFor<double>(jk.value("fovY", 1.309f), 0.0, aspect);
        }
        k.ease = keytrack::easeFromName(jk.value("ease", std::string()));
        keys.push_back(k);
    }
    return keys;
}

json colorGradeToJson(const ColorGrade &g, const QDir *projectDir)
{
    json j{
        {"exposureEv", g.exposureEv},
        {"contrast", g.contrast},
        {"saturation", g.saturation},
        {"temperature", g.temperature},
    };
    if (!g.lut.isEmpty()) {
        j["lut"] = (projectDir ? storedPath(g.lut, *projectDir) : g.lut).toStdString();
        j["lutStrength"] = g.lutStrength;
    }
    return j;
}

ColorGrade colorGradeFromJson(const json &j, const QDir *projectDir)
{
    ColorGrade g; // defaults for any missing field
    if (!j.is_object())
        return g;
    g.exposureEv = j.value("exposureEv", g.exposureEv);
    g.contrast = j.value("contrast", g.contrast);
    g.saturation = j.value("saturation", g.saturation);
    g.temperature = j.value("temperature", g.temperature);
    const QString lut = QString::fromStdString(j.value("lut", std::string()));
    if (!lut.isEmpty()) {
        g.lut = projectDir ? resolvedPath(lut, *projectDir) : lut;
        g.lutStrength = j.value("lutStrength", g.lutStrength);
    }
    return g;
}

// "noise": {"mode": "wind" | "windGeneral" | "hiss" | "voice" |
// "voiceAmbience", "strength": 0.7} -- written only when on. "wind" is the
// motorcycle one (it came first).
json noiseToJson(const insv::NoiseReduction &n)
{
    const char *mode = "wind";
    switch (n.mode) {
    case insv::NoiseMode::Wind: mode = "windGeneral"; break;
    case insv::NoiseMode::Hiss: mode = "hiss"; break;
    case insv::NoiseMode::Voice: mode = "voice"; break;
    case insv::NoiseMode::VoiceAmbience: mode = "voiceAmbience"; break;
    default: break;
    }
    return json{{"mode", mode}, {"strength", n.strength}};
}

insv::NoiseReduction noiseFromJson(const json &j)
{
    insv::NoiseReduction n; // off unless a known mode is given
    if (!j.is_object())
        return n;
    const std::string mode = j.value("mode", std::string());
    if (mode == "wind")
        n.mode = insv::NoiseMode::MotorcycleWind;
    else if (mode == "windGeneral")
        n.mode = insv::NoiseMode::Wind;
    else if (mode == "hiss")
        n.mode = insv::NoiseMode::Hiss;
    else if (mode == "voice")
        n.mode = insv::NoiseMode::Voice;
    else if (mode == "voiceAmbience")
        n.mode = insv::NoiseMode::VoiceAmbience;
    n.strength = std::clamp(j.value("strength", n.strength), 0.0f, 1.0f);
    return n;
}

json blurRemovalsToJson(const std::vector<privacy::BlurRemoval> &removals)
{
    json arr = json::array();
    for (const privacy::BlurRemoval &r : removals) {
        json path = json::array();
        for (const privacy::BlurRemoval::Point &p : r.path)
            path.push_back({p.tMs, p.dir[0], p.dir[1], p.dir[2]});
        arr.push_back(json{{"fromMs", r.fromMs}, {"toMs", r.toMs}, {"wholeTrack", r.wholeTrack},
                           {"path", std::move(path)}});
    }
    return arr;
}

// Corner coordinates in millionths (unit vectors: ~0.00006 deg), as
// integers -- a followed plate is a region per frame, and full floats made
// a 20 s plate ~150 KB of project.
json blurAdditionsToJson(const std::vector<privacy::BlurAddition> &additions)
{
    json arr = json::array();
    for (const privacy::BlurAddition &a : additions) {
        json frames = json::array();
        for (const privacy::BlurAddition::Frame &f : a.frames) {
            json jf = json::array({f.tMs, f.kind});
            for (int k = 0; k < 4; ++k)
                for (int i = 0; i < 3; ++i)
                    jf.push_back(std::lround(f.corner[k][i] * 1e6));
            frames.push_back(std::move(jf));
        }
        const char *timing = a.timing == privacy::StitchTiming::Uncorrected ? "uncorrected"
                             : a.timing == privacy::StitchTiming::NoGyro    ? "noGyro"
                                                                            : "corrected";
        arr.push_back(json{{"frames", std::move(frames)}, {"timing", timing}});
    }
    return arr;
}

// Malformed frames / entries are skipped.
std::vector<privacy::BlurAddition> blurAdditionsFromJson(const json &j)
{
    std::vector<privacy::BlurAddition> out;
    if (!j.is_array())
        return out;
    for (const json &ja : j) {
        if (!ja.is_object() || !ja.contains("frames") || !ja.at("frames").is_array())
            continue;
        privacy::BlurAddition a;
        if (const auto t = ja.find("timing"); t != ja.end() && t->is_string())
            a.timing = *t == "uncorrected" ? privacy::StitchTiming::Uncorrected
                       : *t == "noGyro"    ? privacy::StitchTiming::NoGyro
                                           : privacy::StitchTiming::Corrected;
        for (const json &jf : ja.at("frames")) {
            if (!jf.is_array() || jf.size() != 14 ||
                !std::all_of(jf.begin(), jf.end(), [](const json &v) { return v.is_number(); }))
                continue;
            privacy::BlurAddition::Frame f;
            f.tMs = jf[0].get<int64_t>();
            f.kind = static_cast<uint8_t>(std::clamp(jf[1].get<int>(), 0, 3));
            for (int k = 0; k < 4; ++k)
                for (int i = 0; i < 3; ++i)
                    f.corner[k][i] = static_cast<float>(jf[2 + k * 3 + i].get<double>() * 1e-6);
            if (a.frames.empty() || f.tMs > a.frames.back().tMs)
                a.frames.push_back(f);
        }
        if (!a.frames.empty())
            out.push_back(std::move(a));
    }
    return out;
}

// Malformed entries are skipped (a removal that matches nothing is harmless,
// a dropped one only brings a blur back).
std::vector<privacy::BlurRemoval> blurRemovalsFromJson(const json &j)
{
    std::vector<privacy::BlurRemoval> out;
    if (!j.is_array())
        return out;
    for (const json &jr : j) {
        if (!jr.is_object() || !jr.contains("path") || !jr.at("path").is_array())
            continue;
        privacy::BlurRemoval r;
        r.fromMs = jr.value("fromMs", int64_t(0));
        r.toMs = jr.value("toMs", int64_t(0));
        r.wholeTrack = jr.value("wholeTrack", true);
        for (const json &jp : jr.at("path")) {
            if (!jp.is_array() || jp.size() != 4 || !jp[0].is_number() || !jp[1].is_number() ||
                !jp[2].is_number() || !jp[3].is_number())
                continue;
            privacy::BlurRemoval::Point p;
            p.tMs = jp[0].get<int64_t>();
            for (int k = 0; k < 3; ++k)
                p.dir[k] = jp[k + 1].get<float>();
            r.path.push_back(p);
        }
        if (!r.path.empty())
            out.push_back(std::move(r));
    }
    return out;
}

// Parsed form of one clip, before it's committed to the Timeline -- so a
// malformed file can be rejected without half-destroying the current model.
struct ParsedClip {
    QString sourcePath; // already resolved to absolute
    qint64 trimInMs = 0;
    qint64 trimOutMs = 0;
    qint64 sourceDurationMs = 0;
    double fps = 0.0;
    int sourceWidth = 0;
    int sourceHeight = 0;
    bool mediaMissing = false;
    std::vector<ReframeKey> reframeKeys;
    pane::Split split;
    std::array<std::vector<ReframeKey>, pane::kMaxPanes - 1> paneKeys;
    double audioGainDb = 0.0;
    bool audioMuted = false;
    int audioTrack = 0;
    insv::NoiseReduction noise;
    ColorGrade color;
    insv::StabConfig stabilization;
    bool blurPlates = false;
    QString plateScan;
    std::vector<privacy::BlurRemoval> blurRemovals;
    std::vector<privacy::BlurAddition> blurAdditions;
    double speed = 1.0;
    double syncAdjustMs = std::numeric_limits<double>::quiet_NaN();
    insv::SeamCorrection seamCorrection;
    int seamAdjustGuard = -1;
    insv::LensColour lensColour;
    int lensColourGuard = -1;
    stitch::PreviewStitchConfig::LensGuard lensGuard = stitch::PreviewStitchConfig::LensGuard::Premium;
    stitch::PreviewStitchConfig::Method stitchMethod = Project::kOlderFileStitchMethod;
    bool seamColourBlend = true;
    bool seamFlow = true;
    std::optional<stitch::LensCalibration> lensCalibration;
    bool flat = false;
    ClipItem::Fit fit = ClipItem::Fit::Bars;
    QList<qint64> marks;
    QList<qint64> hiddenMarks;
};

json marksToJson(const QList<qint64> &marks)
{
    json j = json::array();
    for (const qint64 ms : marks)
        j.push_back(ms);
    return j;
}

// Sorted, without duplicates; anything but a number is skipped.
QList<qint64> marksFromJson(const json &j)
{
    QList<qint64> out;
    if (j.is_array())
        for (const json &v : j)
            if (v.is_number())
                out.push_back(v.get<qint64>());
    std::sort(out.begin(), out.end());
    out.erase(std::unique(out.begin(), out.end()), out.end());
    return out;
}

// `linkedIndex`: the main-track index of the clip it's linked to, -1 if
// none -- ids don't survive a save, indices do.
json trackClipToJson(const TrackClip &c, const QDir *projectDir, int linkedIndex)
{
    const std::string source =
        (projectDir ? storedPath(c.sourcePath, *projectDir) : c.sourcePath).toStdString();
    json j{
        {"source", source},
        {"stream", c.stream},
        {"sourceDurationMs", static_cast<qint64>(c.sourceDurationMs)},
        {"startMs", static_cast<qint64>(c.startMs)},
        {"trimInMs", static_cast<qint64>(c.trimInMs)},
        {"trimOutMs", static_cast<qint64>(c.trimOutMs)},
        {"speed", c.speed},
        {"gainDb", c.gainDb},
        {"muted", c.muted},
        {"fadeInMs", static_cast<qint64>(c.fadeInMs)},
        {"fadeOutMs", static_cast<qint64>(c.fadeOutMs)},
    };
    if (c.noise.mode != insv::NoiseMode::Off)
        j["noise"] = noiseToJson(c.noise);
    if (linkedIndex >= 0) {
        j["linkedClip"] = linkedIndex;
        j["syncOffsetMs"] = static_cast<qint64>(c.syncOffsetMs);
    }
    return j;
}

TrackClip trackClipFromJson(const json &j, const QDir *projectDir)
{
    TrackClip c;
    const QString stored = QString::fromStdString(j.value("source", std::string()));
    c.sourcePath = projectDir ? resolvedPath(stored, *projectDir) : stored;
    c.stream = j.value("stream", -1);
    c.sourceDurationMs = j.value("sourceDurationMs", qint64(0));
    c.startMs = j.value("startMs", qint64(0));
    c.trimInMs = j.value("trimInMs", qint64(0));
    c.trimOutMs = j.value("trimOutMs", c.sourceDurationMs);
    c.speed = j.value("speed", 1.0);
    c.gainDb = j.value("gainDb", 0.0);
    c.muted = j.value("muted", false);
    c.fadeInMs = j.value("fadeInMs", qint64(0));
    c.fadeOutMs = j.value("fadeOutMs", qint64(0));
    if (j.contains("noise"))
        c.noise = noiseFromJson(j.at("noise"));
    c.mediaMissing = !QFileInfo::exists(c.sourcePath);
    // The linked main-track clip's index + 1 for now (0 = none); applyDocument
    // maps it to that clip's new id.
    c.linkedClipId = j.value("linkedClip", -1) + 1;
    c.syncOffsetMs = j.value("syncOffsetMs", qint64(0));
    return c;
}

json lookToJson(const inset::Look &l)
{
    return json{{"centerX", l.centerX}, {"centerY", l.centerY}, {"width", l.width},
                {"opacity", l.opacity}};
}

inset::Look lookFromJson(const json &j)
{
    inset::Look l;
    l.centerX = j.value("centerX", l.centerX);
    l.centerY = j.value("centerY", l.centerY);
    l.width = j.value("width", l.width);
    l.opacity = j.value("opacity", l.opacity);
    return l;
}

// A video-track clip: the track-clip fields plus its size and inset.
json colorToJson(uint32_t rgb)
{
    return QStringLiteral("#%1").arg(rgb & 0xffffff, 6, 16, QLatin1Char('0')).toStdString();
}

// "#rrggbb" -> rgb; `fallback` if it isn't one.
uint32_t colorFromJson(const json &j, const char *key, uint32_t fallback)
{
    const QString col = QString::fromStdString(j.value(key, std::string()));
    bool ok = false;
    const uint rgb = col.startsWith(QLatin1Char('#')) ? col.mid(1).toUInt(&ok, 16) : 0;
    return ok ? (rgb & 0xffffff) : fallback;
}

// Only what differs from a plain title (title::Style's defaults) is written:
// a plain one reads in every build since version 12.
json titleToJson(const title::Style &t)
{
    json j{{"text", t.text.toStdString()}, {"font", t.font.toStdString()},
           {"bold", t.bold}, {"italic", t.italic}, {"color", colorToJson(t.rgb)}};
    const title::Style plain;
    if (t.align != plain.align)
        j["align"] = t.align == title::Align::Left ? "left" : "right";
    if (t.lineSpacing != plain.lineSpacing)
        j["lineSpacing"] = t.lineSpacing;
    if (t.letterSpacing != plain.letterSpacing)
        j["letterSpacing"] = t.letterSpacing;
    // Kept while switched off too, so switching on again brings them back.
    if (t.outline != plain.outline)
        j["outline"] = {{"on", t.outline.on}, {"width", t.outline.width},
                        {"color", colorToJson(t.outline.rgb)}};
    if (t.shadow != plain.shadow)
        j["shadow"] = {{"on", t.shadow.on}, {"color", colorToJson(t.shadow.rgb)},
                       {"opacity", t.shadow.opacity}, {"distance", t.shadow.distance},
                       {"blur", t.shadow.blur}};
    if (t.box != plain.box)
        j["box"] = {{"on", t.box.on}, {"color", colorToJson(t.box.rgb)},
                    {"opacity", t.box.opacity}, {"padding", t.box.padding},
                    {"cornerRadius", t.box.cornerRadius}};
    if (t.hours != plain.hours)
        j["hours"] = t.hours == title::Hours::H24 ? "24" : "12";
    if (t.units.speed != plain.units.speed)
        j["speedUnit"] = "mph";
    if (t.units.altitude != plain.units.altitude)
        j["altitudeUnit"] = "ft";
    return j;
}

// A gauge's whole style: what it reads, its scale, units and colours.
json gaugeToJson(const gauge::Style &g)
{
    static const char *const kinds[] = {"dial", "bar", "tape", "lean", "g", "route"};
    json j{{"kind", kinds[static_cast<int>(g.kind)]},
           {"reads", g.reads == gauge::Reads::Altitude ? "altitude" : "speed"},
           {"min", g.min},
           {"max", g.max},
           {"accent", colorToJson(g.accent)},
           {"face", colorToJson(g.face)},
           {"faceOpacity", g.faceOpacity},
           {"textColor", colorToJson(g.text)},
           {"font", g.font.toStdString()}};
    if (g.units.speed == title::SpeedUnit::Mph)
        j["speedUnit"] = "mph";
    if (g.units.altitude == title::AltitudeUnit::Feet)
        j["altitudeUnit"] = "ft";
    if (g.kind == gauge::Kind::Route) {
        j["view"] = g.routeView == gauge::RouteView::Trip ? "trip" : "ahead";
        j["aheadS"] = g.aheadS;
    }
    return j;
}

gauge::Style gaugeFromJson(const json &j)
{
    gauge::Style g;
    const std::string kind = j.value("kind", std::string());
    g.kind = kind == "bar"     ? gauge::Kind::Bar
             : kind == "tape"  ? gauge::Kind::Tape
             : kind == "lean"  ? gauge::Kind::Lean
             : kind == "g"     ? gauge::Kind::GForce
             : kind == "route" ? gauge::Kind::Route
                               : gauge::Kind::Dial;
    g.reads = j.value("reads", std::string()) == "altitude" ? gauge::Reads::Altitude
                                                            : gauge::Reads::Speed;
    g.units.speed = j.value("speedUnit", std::string()) == "mph" ? title::SpeedUnit::Mph
                                                                 : title::SpeedUnit::Kmh;
    g.units.altitude = j.value("altitudeUnit", std::string()) == "ft"
                           ? title::AltitudeUnit::Feet
                           : title::AltitudeUnit::Metres;
    g.routeView = j.value("view", std::string()) == "trip" ? gauge::RouteView::Trip
                                                           : gauge::RouteView::Ahead;
    g.aheadS = j.value("aheadS", g.aheadS);
    g.min = j.value("min", g.min);
    g.max = j.value("max", g.max);
    g.accent = colorFromJson(j, "accent", g.accent);
    g.face = colorFromJson(j, "face", g.face);
    g.faceOpacity = j.value("faceOpacity", g.faceOpacity);
    g.text = colorFromJson(j, "textColor", g.text);
    g.font = QString::fromStdString(j.value("font", g.font.toStdString()));
    return g.clamped();
}

// Is the title drawn other than a plain one (kTitleLookFormatVersion)? An
// outline, shadow or box that's off isn't drawn: an older build shows it
// right.
bool styledTitle(const title::Style &t)
{
    const title::Style plain;
    return t.align != plain.align || t.lineSpacing != plain.lineSpacing ||
           t.letterSpacing != plain.letterSpacing || t.outline.on || t.shadow.on || t.box.on;
}

// `version` is the file's: before kClockFormatVersion a brace was just a
// brace, and is escaped so it stays one (title::escapeBraces).
title::Style titleFromJson(const json &j, int version)
{
    title::Style t;
    t.text = QString::fromStdString(j.value("text", std::string()));
    if (version < Project::kClockFormatVersion)
        t.text = title::escapeBraces(t.text);
    t.font = QString::fromStdString(j.value("font", t.font.toStdString()));
    t.bold = j.value("bold", t.bold);
    t.italic = j.value("italic", t.italic);
    t.rgb = colorFromJson(j, "color", t.rgb);
    const std::string align = j.value("align", std::string());
    t.align = align == "left" ? title::Align::Left
              : align == "right" ? title::Align::Right
                                 : title::Align::Centre;
    t.lineSpacing = j.value("lineSpacing", t.lineSpacing);
    t.letterSpacing = j.value("letterSpacing", t.letterSpacing);
    const std::string hours = j.value("hours", std::string());
    t.hours = hours == "24"   ? title::Hours::H24
              : hours == "12" ? title::Hours::H12
                              : title::Hours::System;
    t.units.speed = j.value("speedUnit", std::string()) == "mph" ? title::SpeedUnit::Mph
                                                                 : title::SpeedUnit::Kmh;
    t.units.altitude = j.value("altitudeUnit", std::string()) == "ft" ? title::AltitudeUnit::Feet
                                                                      : title::AltitudeUnit::Metres;
    if (j.contains("outline") && j.at("outline").is_object()) {
        const json &o = j.at("outline");
        t.outline.on = o.value("on", true);
        t.outline.width = o.value("width", t.outline.width);
        t.outline.rgb = colorFromJson(o, "color", t.outline.rgb);
    }
    if (j.contains("shadow") && j.at("shadow").is_object()) {
        const json &o = j.at("shadow");
        t.shadow.on = o.value("on", true);
        t.shadow.rgb = colorFromJson(o, "color", t.shadow.rgb);
        t.shadow.opacity = o.value("opacity", t.shadow.opacity);
        t.shadow.distance = o.value("distance", t.shadow.distance);
        t.shadow.blur = o.value("blur", t.shadow.blur);
    }
    if (j.contains("box") && j.at("box").is_object()) {
        const json &o = j.at("box");
        t.box.on = o.value("on", true);
        t.box.rgb = colorFromJson(o, "color", t.box.rgb);
        t.box.opacity = o.value("opacity", t.box.opacity);
        t.box.padding = o.value("padding", t.box.padding);
        t.box.cornerRadius = o.value("cornerRadius", t.box.cornerRadius);
    }
    return t.clamped();
}

// How a clip comes on and goes off: only the parts it has.
json motionToJson(const inset::Motion &m)
{
    const auto part = [](const inset::Motion::Part &p) {
        json j{{"kind", p.kind == inset::Motion::Kind::Pop    ? "pop"
                        : p.kind == inset::Motion::Kind::Type ? "type"
                                                              : "slide"},
               {"ms", static_cast<qint64>(p.ms)}};
        if (p.kind == inset::Motion::Kind::Slide)
            j["side"] = p.side == inset::Motion::Side::Left    ? "left"
                        : p.side == inset::Motion::Side::Right ? "right"
                        : p.side == inset::Motion::Side::Top   ? "top"
                                                               : "bottom";
        return j;
    };
    json j = json::object();
    if (m.in.kind != inset::Motion::Kind::None)
        j["in"] = part(m.in);
    if (m.out.kind != inset::Motion::Kind::None)
        j["out"] = part(m.out);
    return j;
}

inset::Motion motionFromJson(const json &j)
{
    const auto part = [&j](const char *key) {
        inset::Motion::Part p;
        if (!j.contains(key) || !j.at(key).is_object())
            return p;
        const json &o = j.at(key);
        const std::string kind = o.value("kind", std::string());
        p.kind = kind == "slide" ? inset::Motion::Kind::Slide
                 : kind == "pop"  ? inset::Motion::Kind::Pop
                 : kind == "type" ? inset::Motion::Kind::Type
                                  : inset::Motion::Kind::None;
        const std::string side = o.value("side", std::string());
        p.side = side == "right"    ? inset::Motion::Side::Right
                 : side == "top"    ? inset::Motion::Side::Top
                 : side == "bottom" ? inset::Motion::Side::Bottom
                                    : inset::Motion::Side::Left;
        p.ms = o.value("ms", p.ms);
        return p;
    };
    inset::Motion m;
    m.in = part("in");
    m.out = part("out");
    return m.clamped();
}

// A video-track clip: the track-clip fields plus its size and inset; a
// title has its style instead of a source and size.
json videoClipToJson(const TrackClip &c, const QDir *projectDir)
{
    json j = trackClipToJson(c, projectDir, -1);
    j.erase("stream");
    j.erase("gainDb");
    j.erase("muted");
    j.erase("noise");
    if (c.isTitle()) {
        j.erase("source");
        j["title"] = titleToJson(*c.title);
    } else if (c.isGauge()) {
        j.erase("source");
        j["gauge"] = gaugeToJson(*c.gauge);
    } else {
        j["sourceWidth"] = c.sourceWidth;
        j["sourceHeight"] = c.sourceHeight;
    }
    json in = lookToJson(c.look);
    in["cornerRadius"] = c.frame.cornerRadius;
    in["borderWidth"] = c.frame.borderWidth;
    in["borderColor"] = colorToJson(c.frame.borderRgb);
    j["inset"] = std::move(in);
    json keys = json::array();
    for (const InsetKey &k : c.insetKeys.keys()) {
        json jk = lookToJson(k.look);
        jk["tMs"] = static_cast<qint64>(k.timeMs);
        if (k.ease != keytrack::Ease::Linear)
            jk["ease"] = keytrack::easeName(k.ease);
        keys.push_back(std::move(jk));
    }
    j["insetKeys"] = std::move(keys);
    if (!c.motion.isNone())
        j["motion"] = motionToJson(c.motion);
    return j;
}

TrackClip videoClipFromJson(const json &j, const QDir *projectDir, int version)
{
    TrackClip c = trackClipFromJson(j, projectDir);
    c.stream = -1;
    c.linkedClipId = 0;
    c.sourceWidth = j.value("sourceWidth", 0);
    c.sourceHeight = j.value("sourceHeight", 0);
    if (j.contains("title") && j.at("title").is_object()) {
        c.title = titleFromJson(j.at("title"), version);
        c.sourcePath.clear();
        c.mediaMissing = false;
    } else if (j.contains("gauge") && j.at("gauge").is_object()) {
        c.gauge = gaugeFromJson(j.at("gauge"));
        c.sourcePath.clear();
        c.mediaMissing = false;
    }
    if (j.contains("inset") && j.at("inset").is_object()) {
        const json &in = j.at("inset");
        c.look = lookFromJson(in);
        c.frame.cornerRadius = in.value("cornerRadius", c.frame.cornerRadius);
        c.frame.borderWidth = in.value("borderWidth", c.frame.borderWidth);
        c.frame.borderRgb = colorFromJson(in, "borderColor", c.frame.borderRgb);
    }
    if (j.contains("insetKeys") && j.at("insetKeys").is_array()) {
        for (const json &jk : j.at("insetKeys"))
            c.insetKeys.upsert(jk.value("tMs", qint64(0)), lookFromJson(jk), 0);
        // Once every key is in: a key's ease needs the next key there.
        for (const json &jk : j.at("insetKeys"))
            c.insetKeys.setEase(jk.value("tMs", qint64(0)), 0,
                                keytrack::easeFromName(jk.value("ease", std::string())));
    }
    if (j.contains("motion") && j.at("motion").is_object())
        c.motion = motionFromJson(j.at("motion"));
    return c;
}

const char *mediaKindName(MediaItem::Kind kind)
{
    switch (kind) {
    case MediaItem::Kind::Clip360:
        return "360";
    case MediaItem::Kind::Video:
        return "video";
    case MediaItem::Kind::Audio:
        break;
    }
    return "audio";
}

// A project from before version 10 (see kFormatVersion).
void convertClipSound(Timeline *timeline, const std::function<int(const QString &)> &counter,
                      const std::vector<ParsedClip> &parsed, const std::vector<int> &clipIds,
                      bool mainMuted)
{
    // Each clip played one of its streams itself (pc.audioTrack): now every
    // stream is a linked clip on its stream track. The one it played gets
    // its level, mute and noise reduction (and the video track's "M"); the
    // others are muted, so the project sounds as it did. A stream already put
    // on a track by hand ("Put the other mic on an audio track") moves to its
    // stream track too, with its track's level and mute folded into its own;
    // a track left empty by that goes.
    QList<int> emptied;
    for (size_t i = 0; i < parsed.size() && i < clipIds.size(); ++i) {
        const ParsedClip &pc = parsed[i];
        struct Placed {
            int id, stream;
            double gainDb;
            bool muted;
        };
        QList<Placed> placed; // its streams on free tracks
        int streams = counter && !pc.mediaMissing ? counter(pc.sourcePath)
                                                  : std::max(1, pc.audioTrack + 1);
        for (int t = 0; t < timeline->trackCount(); ++t) {
            const Track &track = timeline->trackAt(t);
            if (track.kind != Track::Kind::Audio || track.role != Track::Role::Free)
                continue;
            for (const TrackClip &a : track.clips)
                if (a.linkedClipId == clipIds[i] && a.stream >= 0) {
                    placed.append({a.id, a.stream, a.gainDb + track.gainDb,
                                   a.muted || track.muted});
                    if (!emptied.contains(track.id))
                        emptied.append(track.id);
                    if (pc.mediaMissing || !counter)
                        streams = std::max(streams, a.stream + 1);
                }
        }
        for (const Placed &a : placed) {
            const Track::Role role = Track::roleOfStream(a.stream, streams);
            if (role == Track::Role::Free)
                continue;
            int trackId = timeline->streamTrackId(role);
            if (!trackId)
                trackId = timeline->addTrack(Track::Kind::Audio, QString(), role);
            const TrackClip *c = timeline->trackClipById(a.id);
            timeline->moveTrackClip(a.id, trackId, c ? c->startMs : 0);
            timeline->setAudioClipLevel(a.id, a.gainDb, a.muted);
        }

        const QList<int> ids = timeline->addClipSound(clipIds[i], streams);
        const int picked = pc.audioTrack < streams ? pc.audioTrack : 0;
        for (int s = 0; s < ids.size(); ++s) {
            if (!ids[s])
                continue;
            if (s == picked) {
                timeline->setAudioClipLevel(ids[s], pc.audioGainDb, pc.audioMuted || mainMuted);
                timeline->setAudioClipNoise(ids[s], pc.noise);
            } else {
                timeline->setAudioClipLevel(ids[s], 0.0, true);
            }
        }
    }
    for (int trackId : emptied)
        if (const Track *t = timeline->trackById(trackId); t && t->clips.isEmpty())
            timeline->removeTrack(trackId);
}

} // namespace

Project::Project(QObject *parent)
    : QObject(parent)
    , m_timeline(new Timeline(this))
    , m_mediaPool(new MediaPool(this))
{
    connect(m_mediaPool, &MediaPool::changed, this, [this] {
        if (m_rebuilding)
            return;
        setModified(true);
        onUndoableEdited();
    });
    // Whatever goes on the timeline is in the pool too.
    connect(m_timeline, &Timeline::clipInserted, this, [this] { addTimelineSourcesToPool(); });
    connect(m_timeline, &Timeline::tracksChanged, this, [this] { addTimelineSourcesToPool(); });

    const auto edited = [this] { onTimelineEdited(); onUndoableEdited(); };
    connect(m_timeline, &Timeline::clipInserted, this, edited);
    connect(m_timeline, &Timeline::clipRemoved, this, edited);
    connect(m_timeline, &Timeline::clipsReordered, this, edited);
    connect(m_timeline, &Timeline::clipTrimChanged, this, edited);
    connect(m_timeline, &Timeline::clipReframeChanged, this, edited);
    connect(m_timeline, &Timeline::clipColorChanged, this, edited);
    connect(m_timeline, &Timeline::clipStabilizationChanged, this, edited);
    connect(m_timeline, &Timeline::clipPrivacyChanged, this, edited);
    connect(m_timeline, &Timeline::clipSpeedChanged, this, edited);
    connect(m_timeline, &Timeline::clipMarksChanged, this, edited);
    connect(m_timeline, &Timeline::clipStitchChanged, this, edited);
    connect(m_timeline, &Timeline::tracksChanged, this, edited);
    connect(m_timeline, &Timeline::transitionsChanged, this, edited);
    // A measured sync or seam fine-tune is saved with the project but isn't
    // an edit: nothing to undo, and not an unsaved change.
    connect(m_timeline, &Timeline::clipSyncChanged, this, [this](int id) { onMeasured(id); });
    connect(m_timeline, &Timeline::clipSeamChanged, this, [this](int id) { onMeasured(id); });

    m_undoDebounce.setSingleShot(true);
    connect(&m_undoDebounce, &QTimer::timeout, this, &Project::commitPendingUndoPoint);
    m_lastSettledSnapshot = snapshot(); // baseline for the empty starting project
}

void Project::addTimelineSourcesToPool(bool rebuilt)
{
    // Mid-rebuild the timeline is half old, half new (clear() empties the
    // tracks before the clips): the rebuild calls this once at its end.
    if (m_rebuilding && !rebuilt)
        return;
    for (int i = 0; i < m_timeline->count(); ++i) {
        const ClipItem &c = m_timeline->clipAt(i);
        if (!m_mediaPool->contains(c.sourcePath))
            m_mediaPool->add({c.sourcePath,
                              c.flat ? MediaItem::Kind::Video : MediaItem::Kind::Clip360,
                              c.sourceDurationMs, c.sourceWidth, c.sourceHeight, c.fps});
    }
    for (int i = 0; i < m_timeline->trackCount(); ++i) {
        const Track &t = m_timeline->trackAt(i);
        const bool video = t.kind == Track::Kind::Video;
        for (const TrackClip &c : t.clips) {
            if (c.isDrawn() || m_mediaPool->contains(c.sourcePath))
                continue;
            // A camera mic on an audio track is the .insv's sound: the pool
            // lists the clip, whose duration and size the main track knows.
            MediaItem m{c.sourcePath, video ? MediaItem::Kind::Video : MediaItem::Kind::Audio,
                        c.sourceDurationMs};
            if (video) {
                m.width = c.sourceWidth;
                m.height = c.sourceHeight;
            } else if (media::kindForPath(c.sourcePath) == MediaItem::Kind::Clip360) {
                m.kind = MediaItem::Kind::Clip360;
                for (int j = 0; j < m_timeline->count(); ++j)
                    if (m_timeline->clipAt(j).sourcePath == c.sourcePath) {
                        const ClipItem &v = m_timeline->clipAt(j);
                        m.width = v.sourceWidth;
                        m.height = v.sourceHeight;
                        m.fps = v.fps;
                        break;
                    }
            }
            m_mediaPool->add(m);
        }
    }
}

int Project::relinkMedia(const QString &from, const MediaItem &to)
{
    // The pool first: the timeline's change notices add sources missing from
    // it, and `to` is there by then.
    m_mediaPool->relink(from, to);
    return m_timeline->relinkSource(from, to.path);
}

Project::MediaRecheck Project::recheckMissingMedia()
{
    // One look per file; the pool lists every timeline source, but a clip
    // checked here doesn't depend on that.
    QHash<QString, bool> missing;
    MediaRecheck r;
    const auto look = [&](const QString &path) {
        if (path.isEmpty() || missing.contains(path))
            return;
        const QFileInfo fi(path);
        missing.insert(path, !fi.exists());
        if (!fi.exists()) {
            m_mediaStamps.remove(path);
            return;
        }
        const FileStamp stamp{fi.size(), fi.lastModified().toMSecsSinceEpoch()};
        const auto it = m_mediaStamps.find(path);
        if (it == m_mediaStamps.end()) {
            m_mediaStamps.insert(path, stamp);
        } else if (!(*it == stamp)) {
            *it = stamp;
            r.replaced << path;
        }
    };
    for (const MediaItem &m : m_mediaPool->items())
        for (const QString &f : m.files())
            look(f);
    for (int i = 0; i < m_timeline->count(); ++i)
        look(m_timeline->clipAt(i).sourcePath);
    for (int i = 0; i < m_timeline->trackCount(); ++i)
        for (const TrackClip &c : m_timeline->trackAt(i).clips)
            look(c.sourcePath);
    // Files no longer in the project: a stamp kept for one would call it
    // replaced when it's added again.
    m_mediaStamps.removeIf([&](const auto &it) { return !missing.contains(it.key()); });
    // A take is its clip file and its other files: gone if any of them is,
    // replaced if any of them was. Reported by the clip file, which is what
    // everything else keys by.
    for (const MediaItem &m : m_mediaPool->items()) {
        for (const QString &f : m.companions) {
            if (missing.value(f))
                missing[m.path] = true;
            if (r.replaced.removeAll(f) > 0 && !r.replaced.contains(m.path))
                r.replaced << m.path;
        }
    }

    QSet<QString> changed;
    for (const QString &path : m_mediaPool->setMissing(missing))
        changed.insert(path);
    for (const QString &path : m_timeline->setSourcesMissing(missing))
        changed.insert(path);
    for (const QString &path : changed)
        (missing.value(path) ? r.gone : r.back) << path;
    return r;
}

void Project::onTimelineEdited()
{
    if (!m_rebuilding)
        setModified(true);
}

void Project::onMeasured(int clipId)
{
    const ClipItem *clip = m_timeline->clipById(clipId);
    if (!m_rebuilding && clip)
        writeMeasured(*clip);
}

void Project::writeMeasured(const ClipItem &clip)
{
    if (m_filePath.isEmpty())
        return;
    QFile in(m_filePath);
    if (!in.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    json doc;
    try {
        doc = json::parse(in.readAll().toStdString());
    } catch (const std::exception &) {
        return;
    }
    in.close();
    if (!doc.is_object() || !doc.contains("timeline") || !doc.at("timeline").is_object() ||
        !doc.at("timeline").contains("clips") || !doc.at("timeline").at("clips").is_array())
        return;

    const QDir projectDir = QFileInfo(m_filePath).absoluteDir();
    bool changed = false;
    for (json &jc : doc["timeline"]["clips"]) {
        if (!jc.is_object())
            continue;
        const QString source =
            resolvedPath(QString::fromStdString(jc.value("source", std::string())), projectDir);
        if (source != clip.sourcePath)
            continue;
        json updated = jc;
        if (!std::isnan(clip.syncAdjustMs)) {
            updated["syncFineTuneMs"] = clip.syncAdjustMs;
            updated.erase("syncAdjustMs"); // measured against the old timing, see the reader
        }
        if (clip.seamAdjustGuard >= 0)
            updated["seamAdjust"] = seamAdjustToJson(clip.seamCorrection, clip.seamAdjustGuard);
        if (clip.lensColourGuard >= 0)
            updated["lensColour"] = lensColourToJson(clip.lensColour, clip.lensColourGuard);
        if (updated != jc) {
            jc = std::move(updated);
            changed = true;
        }
    }
    if (!changed)
        return;
    const QByteArray text = QByteArray::fromStdString(doc.dump()) + "\n";
    QSaveFile out(m_filePath);
    if (!out.open(QIODevice::WriteOnly | QIODevice::Text) || out.write(text) != text.size() ||
        !out.commit())
        return;
    emit measurementsWritten();
}

void Project::setAudioStreamCounter(std::function<int(const QString &)> counter)
{
    m_audioStreamCounter = std::move(counter);
    m_timeline->setAudioStreamCounter(m_audioStreamCounter);
}

void Project::setModified(bool modified)
{
    if (m_modified == modified)
        return;
    m_modified = modified;
    emit modifiedChanged(m_modified);
}

void Project::setFilePath(const QString &path)
{
    if (m_filePath == path)
        return;
    m_filePath = path;
    emit filePathChanged(m_filePath);
}

void Project::setPreviewStitch(const stitch::PreviewStitchConfig &config)
{
    if (m_previewStitch == config)
        return;
    m_previewStitch = config;
    emit previewStitchChanged(m_previewStitch);
    if (!m_rebuilding) {
        setModified(true);
        onUndoableEdited();
    }
}

void Project::setOutput(const OutputSettings &output)
{
    if (m_output == output)
        return;
    m_output = output;
    emit outputChanged(m_output);
    if (!m_rebuilding) {
        setModified(true);
        onUndoableEdited();
    }
}

void Project::newProject()
{
    m_rebuilding = true;
    m_mediaPool->clear();
    m_timeline->clear();
    setPreviewStitch(stitch::PreviewStitchConfig{});
    setOutput(OutputSettings{});
    m_rebuilding = false;
    setFilePath(QString());
    setModified(false);
    clearUndoHistory();
    emit projectReset();
}

int Project::resetWithClip(const QString &sourcePath, qint64 durationMs, double fps, int width,
                           int height, int audioStreams, stitch::LensGuardProfiles lensGuards)
{
    m_rebuilding = true;
    m_mediaPool->clear();
    m_timeline->clear();
    setPreviewStitch(stitch::PreviewStitchConfig{});
    setOutput(OutputSettings{});
    const int id = m_timeline->appendClip(sourcePath, durationMs, fps, width, height, audioStreams,
                                          false, lensGuards);
    addTimelineSourcesToPool(true);
    m_rebuilding = false;

    setFilePath(QString());
    setModified(false);
    clearUndoHistory();
    emit projectReset();
    return id;
}

QByteArray Project::buildDocument(const QDir *projectDir) const
{
    json clips = json::array();
    bool anyFlat = false;
    bool anyLut = false;
    bool anyDirectionLock = false;
    bool anySplit = false;
    bool anyReframeKey = false; // keys hold the diagonal field of view
    // The first 360 clip's stitch settings, and whether every 360 clip has
    // them (else an older build, which reads one setting for all, misreads).
    const ClipItem *firstStitched = nullptr;
    bool mixedStitch = false;
    bool anyLensCalibration = false; // a clip stitched with its camera's own calibration
    bool anyNewStitcher = false;     // a clip stitched with the new stitcher
    bool anyMark = false;            // a mark of the user's, or a hidden camera one
    for (int i = 0; i < m_timeline->count(); ++i) {
        const ClipItem &c = m_timeline->clipAt(i);
        const std::string source =
            (projectDir ? storedPath(c.sourcePath, *projectDir) : c.sourcePath).toStdString();
        if (c.flat) {
            anyFlat = true;
            clips.push_back({
                {"source", source},
                {"flat", true},
                {"trimInMs", static_cast<qint64>(c.trimInMs)},
                {"trimOutMs", static_cast<qint64>(c.trimOutMs)},
                {"sourceDurationMs", static_cast<qint64>(c.sourceDurationMs)},
                {"fps", c.fps},
                {"sourceWidth", c.sourceWidth},
                {"sourceHeight", c.sourceHeight},
                {"color", colorGradeToJson(c.color, projectDir)},
                {"speed", c.speed},
            });
            anyLut = anyLut || !c.color.lut.isEmpty();
            if (c.fit == ClipItem::Fit::Fill)
                clips.back()["fit"] = "fill";
            if (!c.marks.isEmpty()) {
                clips.back()["marks"] = marksToJson(c.marks);
                anyMark = true;
            }
            continue;
        }
        clips.push_back({
            {"source", source},
            {"trimInMs", static_cast<qint64>(c.trimInMs)},
            {"trimOutMs", static_cast<qint64>(c.trimOutMs)},
            {"sourceDurationMs", static_cast<qint64>(c.sourceDurationMs)},
            {"fps", c.fps},
            {"sourceWidth", c.sourceWidth},
            {"sourceHeight", c.sourceHeight},
            {"reframe", reframeToJson(c.reframe)},
            {"color", colorGradeToJson(c.color, projectDir)},
            {"speed", c.speed},
            {"stabilization", stabilizationToJson(c.stabilization)},
            {"stitch", json{{"lensGuard", lensGuardName(c.lensGuard)},
                            {"depthSeam", c.stitchMethod == stitch::PreviewStitchConfig::Method::DepthSeam}}},
        });
        if (c.stitchMethod == stitch::PreviewStitchConfig::Method::New && !c.flat) {
            clips.back()["stitch"]["method"] = "new";
            clips.back()["stitch"]["seamColourBlend"] = c.seamColourBlend;
            clips.back()["stitch"]["seamFlow"] = c.seamFlow;
            anyNewStitcher = true;
        }
        if (c.lensCalibration && !c.flat) {
            clips.back()["stitch"]["calibration"] = lenscal::ToJson(*c.lensCalibration);
            anyLensCalibration = true;
        }
        // The split, with every pane camera (kept ones of a smaller layout
        // too); absent when there's neither.
        const bool paneKeys = std::any_of(c.panes.begin(), c.panes.end(),
                                          [](const ReframeTrack &t) { return !t.isEmpty(); });
        anyReframeKey = anyReframeKey || paneKeys || !c.reframe.isEmpty();
        if (c.split.isSplit() || paneKeys) {
            json jp = json::array();
            for (const ReframeTrack &t : c.panes)
                jp.push_back(reframeToJson(t));
            clips.back()["split"] = json{{"layout", pane::layoutName(c.split.layout)},
                                         {"gap", c.split.gap},
                                         {"gapColor", colorToJson(c.split.gapRgb)},
                                         {"panes", std::move(jp)}};
            anySplit = anySplit || c.split.isSplit();
        }
        anyLut = anyLut || !c.color.lut.isEmpty();
        anyDirectionLock = anyDirectionLock || c.stabilization.lockDirection ||
                           c.stabilization.mode == insv::StabMode::DirectionLock;
        if (!firstStitched)
            firstStitched = &c;
        else if (c.lensGuard != firstStitched->lensGuard ||
                 c.stitchMethod != firstStitched->stitchMethod)
            mixedStitch = true;
        if (c.blurPlates || !c.plateScan.isEmpty() || !c.blurRemovals.empty() ||
            !c.blurAdditions.empty()) {
            json &jp = clips.back()["privacy"] = json::object();
            if (c.blurPlates)
                jp["plates"] = true;
            if (!c.plateScan.isEmpty())
                jp["scan"] = c.plateScan.toStdString();
            if (!c.blurRemovals.empty())
                jp["removed"] = blurRemovalsToJson(c.blurRemovals);
            if (!c.blurAdditions.empty())
                jp["added"] = blurAdditionsToJson(c.blurAdditions);
        }
        if (!c.marks.isEmpty())
            clips.back()["marks"] = marksToJson(c.marks);
        if (!c.hiddenMarks.isEmpty())
            clips.back()["hiddenMarks"] = marksToJson(c.hiddenMarks);
        anyMark = anyMark || !c.marks.isEmpty() || !c.hiddenMarks.isEmpty();
        if (!std::isnan(c.syncAdjustMs))
            clips.back()["syncFineTuneMs"] = c.syncAdjustMs; // absent until measured
        if (c.seamAdjustGuard >= 0) // absent until measured
            clips.back()["seamAdjust"] = seamAdjustToJson(c.seamCorrection, c.seamAdjustGuard);
        if (c.lensColourGuard >= 0) // absent until measured
            clips.back()["lensColour"] = lensColourToJson(c.lensColour, c.lensColourGuard);
    }

    // Each at its cut: the index of the clip before it.
    json transitions = json::array();
    for (int i = 0; i + 1 < m_timeline->count(); ++i)
        if (const Transition *t = m_timeline->transitionAfter(m_timeline->clipAt(i).id))
            transitions.push_back({{"cut", i},
                                   {"type", Transition::typeName(t->type)},
                                   {"durationMs", static_cast<qint64>(t->durationMs)}});

    json tracks = json::array();
    bool anyTitle = false;
    bool anyStyledTitle = false; // outline, shadow, box, alignment or spacing
    bool anyMotion = false;
    bool anyBrace = false; // a clock field, or an escaped brace
    bool anyGauge = false;
    bool anyMotionOverlay = false; // a lean, G or route gauge, a lean or G field
    for (int i = 0; i < m_timeline->trackCount(); ++i) {
        const Track &t = m_timeline->trackAt(i);
        const bool video = t.kind == Track::Kind::Video;
        json tc = json::array();
        for (const TrackClip &c : t.clips) {
            if (video) {
                anyTitle |= c.isTitle();
                anyStyledTitle |= c.isTitle() && styledTitle(*c.title);
                anyMotion |= !c.motion.isNone();
                anyBrace |= c.isTitle() && c.title->text.contains(QLatin1Char('{'));
                anyGauge |= c.isGauge();
                anyMotionOverlay |= (c.isGauge() && (c.gauge->kind == gauge::Kind::Lean ||
                                                     c.gauge->kind == gauge::Kind::GForce ||
                                                     c.gauge->kind == gauge::Kind::Route)) ||
                                    (c.isTitle() && title::hasMotionFields(c.title->text));
                tc.push_back(videoClipToJson(c, projectDir));
                continue;
            }
            tc.push_back(trackClipToJson(
                c, projectDir, c.linkedClipId ? m_timeline->indexOfId(c.linkedClipId) : -1));
            int overlayTrackId = 0; // linked to an overlay clip: [track, clip] index
            if (c.linkedClipId && m_timeline->trackClipById(c.linkedClipId, &overlayTrackId)) {
                const Track &ot = *m_timeline->trackById(overlayTrackId);
                const auto at = std::find_if(ot.clips.begin(), ot.clips.end(),
                                             [&](const TrackClip &o) { return o.id == c.linkedClipId; });
                tc.back()["linkedOverlay"] = {m_timeline->trackIndexOfId(overlayTrackId),
                                              static_cast<int>(at - ot.clips.begin())};
                tc.back()["syncOffsetMs"] = static_cast<qint64>(c.syncOffsetMs);
            }
        }
        tracks.push_back({
            {"kind", video ? "video" : "audio"},
            {"name", t.name.toStdString()},
            {"gainDb", t.gainDb},
            {"muted", t.muted},
            {"clips", std::move(tc)},
        });
        if (t.role == Track::Role::CameraMic)
            tracks.back()["role"] = "cameraMic";
        else if (t.role == Track::Role::ExternalMic)
            tracks.back()["role"] = "externalMic";
        else if (t.role == Track::Role::OverlayAudio) {
            tracks.back()["role"] = "overlayAudio";
            tracks.back()["owner"] = m_timeline->trackIndexOfId(t.ownerTrackId);
        }
        // An undo snapshot keeps the track's id, so whatever the view keys by
        // it (a folded overlay track) survives the undo; not in the file.
        if (!projectDir)
            tracks.back()["id"] = t.id;
    }

    json media = json::array();
    for (const MediaItem &m : m_mediaPool->items()) {
        media.push_back({
            {"source", (projectDir ? storedPath(m.path, *projectDir) : m.path).toStdString()},
            {"kind", mediaKindName(m.kind)},
            {"durationMs", m.durationMs},
        });
        if (m.width > 0 && m.height > 0) {
            media.back()["width"] = m.width;
            media.back()["height"] = m.height;
        }
        if (m.fps > 0)
            media.back()["fps"] = m.fps;
        if (!m.companions.isEmpty()) {
            json files = json::array();
            for (const QString &f : m.companions)
                files.push_back((projectDir ? storedPath(f, *projectDir) : f).toStdString());
            media.back()["files"] = std::move(files);
        }
    }

    // The project-wide stitch settings an older build reads: the clips' own.
    stitch::PreviewStitchConfig stitchForOlder = m_previewStitch;
    if (firstStitched) {
        stitchForOlder.lensGuard = firstStitched->lensGuard;
        stitchForOlder.method = firstStitched->stitchMethod;
    }
    json doc = {
        {"format", kFormatTag},
        {"version", anyMark                   ? kMarkFormatVersion
                    : anyNewStitcher || anyLensCalibration ? kStitchFormatVersion
                    : anyMotionOverlay        ? kMotionOverlayFormatVersion
                    : anyGauge                ? kGaugeFormatVersion
                    : anyBrace                ? kClockFormatVersion
                    : anyMotion               ? kMotionFormatVersion
                    : anyStyledTitle          ? kTitleLookFormatVersion
                    : anyReframeKey           ? kWideViewFormatVersion
                    : anySplit                ? kSplitFormatVersion
                    : anyDirectionLock        ? kDirectionLockFormatVersion
                    : anyLut                  ? kLutFormatVersion
                    : !transitions.empty()    ? kTransitionFormatVersion
                    : anyTitle                ? kTitleFormatVersion
                    : anyFlat || mixedStitch ? kFlatClipFormatVersion
                                             : kPlainFormatVersion},
        {"previewStitch", previewStitchToJson(stitchForOlder)},
        {"output", outputToJson(m_output)},
        {"timeline",
         {{"clips", std::move(clips)},
          {"tracks", std::move(tracks)}}},
    };
    if (!transitions.empty())
        doc["timeline"]["transitions"] = std::move(transitions);
    if (!media.empty())
        doc["media"] = std::move(media);
    return QByteArray::fromStdString(doc.dump());
}

bool Project::applyDocument(const QByteArray &text, const QDir *projectDir, QString *error)
{
    std::vector<ParsedClip> parsed;
    std::vector<Track> parsedTracks; // ids unassigned; clips carry everything else
    // Per parsed track and clip: the [track, clip] index of the overlay clip
    // it's linked to, or {-1, -1}.
    std::vector<std::vector<std::pair<int, int>>> overlayLinks;
    stitch::PreviewStitchConfig parsedStitch;
    parsedStitch.method = kOlderFileStitchMethod; // a file without "previewStitch"
    OutputSettings parsedOutput;
    bool parsedMainMuted = false;
    struct ParsedTransition {
        int cut = 0; // index of the clip before it
        Transition::Type type = Transition::Type::Crossfade;
        qint64 durationMs = Transition::kDefaultMs;
    };
    std::vector<ParsedTransition> parsedTransitions;
    int parsedVersion = kFormatVersion;
    QList<MediaItem> parsedMedia;
    try {
        const json doc = json::parse(text.begin(), text.end());

        const std::string format =
            doc.is_object() ? doc.value("format", std::string()) : std::string();
        if (format != kFormatTag) {
            if (error)
                *error = QStringLiteral("not an orbis-reframe project");
            return false;
        }
        const int version = doc.value("version", 0);
        if (version < kOldestFormatVersion || version > kFormatVersion) {
            if (error)
                *error = QStringLiteral("unsupported project version %1").arg(version);
            return false;
        }

        parsedVersion = version;
        if (doc.contains("previewStitch"))
            parsedStitch = previewStitchFromJson(doc.at("previewStitch"));
        // Version 8: one setting for the whole project, which every clip takes.
        insv::StabConfig projectStab;
        if (version == 8 && doc.contains("stabilization"))
            projectStab = stabilizationFromJson(doc.at("stabilization"));
        if (doc.contains("output"))
            parsedOutput = outputFromJson(doc.at("output"));

        const json &clips = doc.at("timeline").at("clips");
        for (const json &jc : clips) {
            ParsedClip pc;
            const QString stored = QString::fromStdString(jc.value("source", std::string()));
            pc.sourcePath = projectDir ? resolvedPath(stored, *projectDir) : stored;
            pc.sourceDurationMs = jc.value("sourceDurationMs", qint64(0));
            pc.fps = jc.value("fps", 0.0);
            if (!(pc.fps > 0.0)) {
                if (error)
                    *error = QStringLiteral("clip %1 has no frame rate").arg(stored);
                return false;
            }
            pc.sourceWidth = jc.value("sourceWidth", 0);
            pc.sourceHeight = jc.value("sourceHeight", 0);
            pc.trimInMs = jc.value("trimInMs", qint64(0));
            pc.trimOutMs = jc.value("trimOutMs", pc.sourceDurationMs);
            pc.audioGainDb = jc.value("audioGainDb", 0.0);
            pc.audioMuted = jc.value("audioMuted", false);
            pc.audioTrack = jc.value("audioTrack", 0);
            if (jc.contains("noise"))
                pc.noise = noiseFromJson(jc.at("noise"));
            if (jc.contains("color"))
                pc.color = colorGradeFromJson(jc.at("color"), projectDir);
            pc.speed = jc.value("speed", 1.0);
            pc.flat = jc.value("flat", false);
            if (pc.flat && jc.value("fit", std::string()) == "fill")
                pc.fit = ClipItem::Fit::Fill;
            if (jc.contains("marks"))
                pc.marks = marksFromJson(jc.at("marks"));
            if (!pc.flat && jc.contains("hiddenMarks"))
                pc.hiddenMarks = marksFromJson(jc.at("hiddenMarks"));
            pc.stabilization = projectStab;
            if (version >= 9 && jc.contains("stabilization"))
                pc.stabilization = stabilizationFromJson(jc.at("stabilization"));
            if (jc.contains("privacy") && jc.at("privacy").is_object()) {
                pc.blurPlates = jc.at("privacy").value("plates", false);
                pc.plateScan =
                    QString::fromStdString(jc.at("privacy").value("scan", std::string()));
                if (jc.at("privacy").contains("removed"))
                    pc.blurRemovals = blurRemovalsFromJson(jc.at("privacy").at("removed"));
                if (jc.at("privacy").contains("added"))
                    pc.blurAdditions = blurAdditionsFromJson(jc.at("privacy").at("added"));
            }
            // Before per-clip stitch settings: the project's, for every clip.
            pc.lensGuard = parsedStitch.lensGuard;
            pc.stitchMethod = parsedStitch.method;
            if (jc.contains("stitch") && jc.at("stitch").is_object()) {
                const json &js = jc.at("stitch");
                lensGuardFromJson(js, pc.lensGuard);
                pc.stitchMethod = js.value("depthSeam", pc.stitchMethod ==
                                                           stitch::PreviewStitchConfig::Method::DepthSeam)
                                      ? stitch::PreviewStitchConfig::Method::DepthSeam
                                      : stitch::PreviewStitchConfig::Method::FixedSeam;
                if (js.value("method", std::string()) == "new") {
                    pc.stitchMethod = stitch::PreviewStitchConfig::Method::New;
                    pc.seamColourBlend = js.value("seamColourBlend", true);
                    pc.seamFlow = js.value("seamFlow", true);
                }
                if (js.contains("calibration"))
                    pc.lensCalibration = lenscal::FromJson(js.at("calibration"));
            }
            // The sync fine-tune is measured on top of the camera's own
            // timing; "syncAdjustMs" was measured against an older timing
            // (no frame's exposure in it), so it's left out and the clip
            // measured again -- and a build that knows only that key
            // measures again too, rather than read this one against its own.
            if (jc.contains("syncFineTuneMs") && jc.at("syncFineTuneMs").is_number())
                pc.syncAdjustMs = jc.at("syncFineTuneMs").get<double>();
            if (jc.contains("seamAdjust"))
                seamAdjustFromJson(jc.at("seamAdjust"), pc.seamCorrection, pc.seamAdjustGuard);
            if (jc.contains("lensColour"))
                lensColourFromJson(jc.at("lensColour"), pc.lensColour, pc.lensColourGuard);
            pc.mediaMissing = !QFileInfo::exists(pc.sourcePath);
            const double outAspect =
                double(parsedOutput.width) / double(std::max(1, parsedOutput.height));
            if (jc.contains("reframe"))
                pc.reframeKeys = reframeKeysFromJson(jc.at("reframe"), version, outAspect);
            if (jc.contains("split") && jc.at("split").is_object()) {
                const json &js = jc.at("split");
                pc.split.layout = pane::layoutFromName(js.value("layout", std::string()).c_str());
                pc.split.gap = js.value("gap", pc.split.gap);
                pc.split.gapRgb = colorFromJson(js, "gapColor", pc.split.gapRgb);
                // A pane's keys are relative to its own aspect.
                const std::vector<pane::Rect> rects =
                    pane::rects(pc.split, parsedOutput.width, parsedOutput.height);
                if (js.contains("panes") && js.at("panes").is_array())
                    for (size_t i = 0; i < js.at("panes").size() && i < pc.paneKeys.size(); ++i)
                        pc.paneKeys[i] = reframeKeysFromJson(
                            js.at("panes")[i], version,
                            i + 1 < rects.size() ? rects[i + 1].aspect() : outAspect);
            }
            parsed.push_back(std::move(pc));
        }

        // Extra tracks. An unknown track kind is skipped rather than failing
        // the load.
        const json &jtl = doc.at("timeline");
        parsedMainMuted = jtl.value("mainMuted", false);
        if (jtl.contains("transitions") && jtl.at("transitions").is_array())
            for (const json &jt : jtl.at("transitions")) {
                ParsedTransition pt;
                pt.cut = jt.value("cut", -1);
                pt.type = Transition::typeFromName(jt.value("type", std::string()).c_str());
                pt.durationMs = jt.value("durationMs", Transition::kDefaultMs);
                parsedTransitions.push_back(pt);
            }
        if (jtl.contains("tracks") && jtl.at("tracks").is_array()) {
            for (const json &jt : jtl.at("tracks")) {
                const std::string kind = jt.value("kind", std::string());
                if (kind != "audio" && kind != "video")
                    continue;
                Track t;
                t.kind = kind == "video" ? Track::Kind::Video : Track::Kind::Audio;
                t.name = QString::fromStdString(jt.value("name", std::string()));
                t.gainDb = jt.value("gainDb", 0.0);
                t.muted = jt.value("muted", false);
                t.id = projectDir ? 0 : jt.value("id", 0); // see buildDocument
                const std::string role = jt.value("role", std::string());
                if (t.kind == Track::Kind::Audio && role == "cameraMic")
                    t.role = Track::Role::CameraMic;
                else if (t.kind == Track::Kind::Audio && role == "externalMic")
                    t.role = Track::Role::ExternalMic;
                else if (t.kind == Track::Kind::Audio && role == "overlayAudio") {
                    t.role = Track::Role::OverlayAudio;
                    t.ownerTrackId = jt.value("owner", -1) + 1; // the owner's index + 1 for now
                }
                std::vector<std::pair<int, int>> links;
                if (jt.contains("clips"))
                    for (const json &jc : jt.at("clips")) {
                        t.clips.push_back(t.kind == Track::Kind::Video
                                              ? videoClipFromJson(jc, projectDir, version)
                                              : trackClipFromJson(jc, projectDir));
                        std::pair<int, int> link{-1, -1};
                        if (t.kind == Track::Kind::Audio && jc.contains("linkedOverlay")) {
                            const json &jl = jc.at("linkedOverlay");
                            if (jl.is_array() && jl.size() == 2)
                                link = {jl[0].get<int>(), jl[1].get<int>()};
                        }
                        links.push_back(link);
                    }
                parsedTracks.push_back(std::move(t));
                overlayLinks.push_back(std::move(links));
            }
        }

        // The media pool. An unknown kind is skipped like an unknown track.
        if (doc.contains("media") && doc.at("media").is_array()) {
            for (const json &jm : doc.at("media")) {
                const std::string kind = jm.value("kind", std::string());
                MediaItem m;
                if (kind == "360")
                    m.kind = MediaItem::Kind::Clip360;
                else if (kind == "video")
                    m.kind = MediaItem::Kind::Video;
                else if (kind == "audio")
                    m.kind = MediaItem::Kind::Audio;
                else
                    continue;
                const QString stored = QString::fromStdString(jm.value("source", std::string()));
                if (stored.isEmpty())
                    continue;
                m.path = projectDir ? resolvedPath(stored, *projectDir) : stored;
                m.durationMs = jm.value("durationMs", qint64(0));
                m.width = jm.value("width", 0);
                m.height = jm.value("height", 0);
                m.fps = jm.value("fps", 0.0);
                if (jm.contains("files") && jm.at("files").is_array())
                    for (const json &jf : jm.at("files"))
                        if (jf.is_string() && !jf.get<std::string>().empty()) {
                            const QString f = QString::fromStdString(jf.get<std::string>());
                            m.companions << (projectDir ? resolvedPath(f, *projectDir) : f);
                        }
                m.missing = !media::firstMissingFile(m).isEmpty();
                parsedMedia.append(m);
            }
        }
    } catch (const std::exception &e) {
        if (error)
            *error = QStringLiteral("could not be read as a project: %1")
                         .arg(QString::fromUtf8(e.what()));
        return false;
    }

    // Everything parsed -- now it's safe to replace the model. The pool first:
    // rebuilding the timeline adds the sources it lacks (an older project).
    m_rebuilding = true;
    m_mediaPool->setItems(parsedMedia);
    m_timeline->clear();
    setPreviewStitch(parsedStitch);
    setOutput(parsedOutput);
    std::vector<int> clipIds; // main-track index -> new id, for linked audio
    for (const ParsedClip &pc : parsed) {
        const int id = m_timeline->appendClip(pc.sourcePath, pc.sourceDurationMs, pc.fps,
                                              pc.sourceWidth, pc.sourceHeight, 0, pc.flat);
        m_timeline->setClipFit(id, pc.fit);
        // appendClip set the trim to the whole source; narrow it to the saved
        // range (in then out, so the min-gap clamp doesn't fight a valid pair).
        m_timeline->setClipTrimIn(id, pc.trimInMs);
        m_timeline->setClipTrimOut(id, pc.trimOutMs);
        m_timeline->setClipColor(id, pc.color);
        m_timeline->setClipStabilization(id, pc.stabilization);
        m_timeline->setClipBlurPlates(id, pc.blurPlates);
        m_timeline->setClipPlateScan(id, pc.plateScan);
        m_timeline->setClipBlurRemovals(id, pc.blurRemovals);
        m_timeline->setClipBlurAdditions(id, pc.blurAdditions);
        m_timeline->setClipSpeed(id, pc.speed);
        for (const qint64 ms : pc.marks)
            m_timeline->addClipMark(id, ms);
        for (const qint64 ms : pc.hiddenMarks)
            m_timeline->setClipMarkHidden(id, ms, true);
        if (!pc.flat) {
            m_timeline->setSourceStitch(pc.sourcePath, pc.lensGuard, pc.stitchMethod,
                                        pc.lensCalibration);
            m_timeline->setSourceSeamColourBlend(pc.sourcePath, pc.seamColourBlend);
            m_timeline->setSourceSeamFlow(pc.sourcePath, pc.seamFlow);
        }
        if (!std::isnan(pc.syncAdjustMs))
            m_timeline->setSourceSyncAdjust(pc.sourcePath, pc.syncAdjustMs);
        if (pc.seamAdjustGuard >= 0)
            m_timeline->setSourceSeamCorrection(pc.sourcePath, pc.seamCorrection, pc.seamAdjustGuard);
        if (pc.lensColourGuard >= 0)
            m_timeline->setSourceLensColour(pc.sourcePath, pc.lensColour, pc.lensColourGuard);
        for (int pane = 0; pane < pane::kMaxPanes; ++pane) {
            const std::vector<ReframeKey> &keys = pane ? pc.paneKeys[pane - 1] : pc.reframeKeys;
            for (const ReframeKey &k : keys)
                m_timeline->upsertClipReframeKey(id, k.timeMs, k.pose, pane);
            for (const ReframeKey &k : keys) // once the next key is in
                if (k.ease != keytrack::Ease::Linear)
                    m_timeline->setClipReframeEase(id, k.timeMs, k.ease, pane);
        }
        m_timeline->setClipSplit(id, pc.split);
        m_timeline->setClipMediaMissing(id, pc.mediaMissing);
        clipIds.push_back(id);
    }
    for (const ParsedTransition &pt : parsedTransitions) // (one past the last clip: refused)
        if (pt.cut >= 0 && pt.cut < static_cast<int>(clipIds.size()))
            m_timeline->setTransition(clipIds[pt.cut], pt.type, pt.durationMs);
    // Overlay clips before any audio, so sound linked to one finds its new
    // id; overlay audio tracks after their overlay tracks (one whose overlay
    // track is missing becomes a free audio track).
    std::vector<int> trackIds(parsedTracks.size(), 0);
    std::vector<std::vector<int>> overlayIds(parsedTracks.size()); // [track][clip] -> new id
    for (bool overlayAudio : {false, true})
        for (size_t i = 0; i < parsedTracks.size(); ++i) {
            const Track &t = parsedTracks[i];
            if ((t.role == Track::Role::OverlayAudio) != overlayAudio)
                continue;
            if (overlayAudio) {
                const int owner = t.ownerTrackId - 1;
                const bool ok = owner >= 0 && owner < static_cast<int>(parsedTracks.size()) &&
                                parsedTracks[owner].kind == Track::Kind::Video;
                trackIds[i] = m_timeline->addTrack(t.kind, t.name,
                                                   ok ? t.role : Track::Role::Free,
                                                   ok ? trackIds[owner] : 0, t.id);
            } else {
                trackIds[i] = m_timeline->addTrack(t.kind, t.name, t.role, 0, t.id);
            }
            m_timeline->setTrackAudio(trackIds[i], t.gainDb, t.muted);
            if (t.kind == Track::Kind::Video)
                for (const TrackClip &c : t.clips)
                    overlayIds[i].push_back(m_timeline->insertTrackClip(trackIds[i], c));
        }
    for (size_t i = 0; i < parsedTracks.size(); ++i) {
        const Track &t = parsedTracks[i];
        if (t.kind == Track::Kind::Video)
            continue;
        for (int k = 0; k < t.clips.size(); ++k) {
            TrackClip c = t.clips[k];
            const int idx = c.linkedClipId - 1;
            c.linkedClipId = idx >= 0 && idx < static_cast<int>(clipIds.size()) ? clipIds[idx] : 0;
            const auto [ot, oc] = overlayLinks[i][k];
            if (ot >= 0 && ot < static_cast<int>(overlayIds.size()) && oc >= 0 &&
                oc < static_cast<int>(overlayIds[ot].size()))
                c.linkedClipId = overlayIds[ot][oc];
            m_timeline->insertTrackClip(trackIds[i], c);
        }
    }
    // A free track that held only overlays' sound (from before overlay
    // audio tracks; it moved to them) goes.
    for (size_t i = 0; i < parsedTracks.size(); ++i)
        if (const Track *t = m_timeline->trackById(trackIds[i]);
            t && t->group() == Track::Group::Audio && t->clips.isEmpty() &&
            !parsedTracks[i].clips.isEmpty())
            m_timeline->removeTrack(trackIds[i]);
    if (parsedVersion < 10)
        convertClipSound(m_timeline, m_audioStreamCounter, parsed, clipIds, parsedMainMuted);
    addTimelineSourcesToPool(true); // an older project's sources; not an edit
    // A take is missing when any of its files is; the clips were marked by
    // their own file only.
    QHash<QString, bool> takes;
    for (const MediaItem &m : m_mediaPool->items())
        if (!m.companions.isEmpty())
            takes.insert(m.path, m.missing);
    m_timeline->setSourcesMissing(takes);
    m_rebuilding = false;
    emit projectReset();
    return true;
}


bool Project::save(const QString &path, QString *error)
{
    const QByteArray text = fileContents(path);

    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (error)
            *error = QStringLiteral("Cannot open %1 for writing: %2").arg(path, file.errorString());
        return false;
    }
    if (file.write(text) != text.size() || !file.commit()) {
        if (error)
            *error = QStringLiteral("Failed to write %1: %2").arg(path, file.errorString());
        return false;
    }

    setFilePath(path);
    setModified(false);
    return true;
}

bool Project::copyFile(const QString &from, const QString &to, QString *error)
{
    auto fail = [error](const QString &message) {
        if (error)
            *error = message;
        return false;
    };
    QFile in(from);
    if (!in.open(QIODevice::ReadOnly | QIODevice::Text))
        return fail(QStringLiteral("Cannot open %1: %2").arg(from, in.errorString()));
    json doc;
    try {
        doc = json::parse(in.readAll().toStdString());
    } catch (const std::exception &e) {
        return fail(QStringLiteral("%1 is not a valid project file: %2").arg(from, e.what()));
    }
    // Every media path in every version is a "source" string, or one of a
    // media item's "files". A clip's "lut" stays as it is: a project folder's
    // copy brings its luts/ along, and a loose project's copy goes beside it.
    const QDir fromDir = QFileInfo(from).absoluteDir();
    const QDir toDir = QFileInfo(to).absoluteDir();
    std::function<void(json &)> relocate = [&](json &j) {
        if (j.is_object()) {
            for (auto it = j.begin(); it != j.end(); ++it) {
                const auto move = [&](json &path) {
                    const QString stored = QString::fromStdString(path.get<std::string>());
                    if (!stored.isEmpty() && !QDir::isAbsolutePath(stored))
                        path = storedPath(resolvedPath(stored, fromDir), toDir).toStdString();
                };
                if (it.key() == "source" && it->is_string()) {
                    move(*it);
                } else if (it.key() == "files" && it->is_array()) {
                    for (json &f : *it)
                        if (f.is_string())
                            move(f);
                } else {
                    relocate(*it);
                }
            }
        } else if (j.is_array()) {
            for (json &e : j)
                relocate(e);
        }
    };
    relocate(doc);

    const QByteArray text = QByteArray::fromStdString(doc.dump()) + "\n";
    QSaveFile out(to);
    if (!out.open(QIODevice::WriteOnly | QIODevice::Text))
        return fail(QStringLiteral("Cannot open %1 for writing: %2").arg(to, out.errorString()));
    if (out.write(text) != text.size() || !out.commit())
        return fail(QStringLiteral("Failed to write %1: %2").arg(to, out.errorString()));
    return true;
}

QByteArray Project::fileContents(const QString &projectFile) const
{
    const QDir projectDir = QFileInfo(projectFile).absoluteDir();
    return buildDocument(&projectDir) + "\n";
}

bool Project::recover(const QString &autosaveFile, const QString &projectFile, QString *error)
{
    QFile file(autosaveFile);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (error)
            *error = QStringLiteral("Cannot open %1: %2").arg(autosaveFile, file.errorString());
        return false;
    }
    const QDir projectDir = QFileInfo(projectFile).absoluteDir();
    QString innerError;
    if (!applyDocument(file.readAll(), &projectDir, &innerError)) {
        if (error)
            *error = QStringLiteral("%1 %2").arg(autosaveFile, innerError);
        return false;
    }
    setFilePath(projectFile);
    setModified(true);
    clearUndoHistory();
    return true;
}

bool Project::load(const QString &path, QString *error)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (error)
            *error = QStringLiteral("Cannot open %1: %2").arg(path, file.errorString());
        return false;
    }
    const QByteArray bytes = file.readAll();
    const QDir projectDir = QFileInfo(path).absoluteDir();

    QString innerError;
    if (!applyDocument(bytes, &projectDir, &innerError)) {
        if (error)
            *error = QStringLiteral("%1 %2").arg(path, innerError);
        return false;
    }

    setFilePath(path);
    setModified(false);
    clearUndoHistory();
    return true;
}

QSet<QString> Project::plateScansInUse() const
{
    QSet<QString> keys;
    for (int i = 0; i < m_timeline->count(); ++i)
        if (!m_timeline->clipAt(i).plateScan.isEmpty())
            keys.insert(m_timeline->clipAt(i).plateScan);
    QList<QByteArray> steps = m_undoStack + m_redoStack;
    steps.append(m_lastSettledSnapshot); // a burst not settled yet undoes to it
    for (const QByteArray &bytes : steps) {
        const json doc = json::parse(bytes.toStdString(), nullptr, false);
        if (!doc.is_object() || !doc.contains("timeline") || !doc.at("timeline").contains("clips"))
            continue;
        for (const json &jc : doc.at("timeline").at("clips"))
            if (jc.contains("privacy") && jc.at("privacy").is_object())
                if (const std::string k = jc.at("privacy").value("scan", std::string()); !k.empty())
                    keys.insert(QString::fromStdString(k));
    }
    return keys;
}

QByteArray Project::snapshot() const
{
    return buildDocument(nullptr);
}

void Project::restoreSnapshot(const QByteArray &bytes)
{
    applyDocument(bytes, nullptr, nullptr); // generated by us -- never expected to fail
    setModified(true); // may or may not match the saved file; treat it as unsaved either way
}

void Project::clearUndoHistory()
{
    m_undoDebounce.stop();
    m_pendingDirty = false;
    m_undoStack.clear();
    m_redoStack.clear();
    m_lastSettledSnapshot = snapshot();
    emit canUndoChanged(false);
    emit canRedoChanged(false);
}

void Project::onUndoableEdited()
{
    if (m_rebuilding)
        return;
    if (!m_pendingDirty) {
        m_pendingDirty = true;
        if (m_undoStack.isEmpty())
            emit canUndoChanged(true);
        if (!m_redoStack.isEmpty()) {
            m_redoStack.clear();
            emit canRedoChanged(false);
        }
    }
    m_undoDebounce.start(kUndoCoalesceMs);
}

void Project::commitPendingUndoPoint()
{
    if (!m_pendingDirty)
        return;
    m_undoDebounce.stop();
    m_pendingDirty = false;

    const QByteArray now = snapshot();
    if (now == m_lastSettledSnapshot) {
        if (m_undoStack.isEmpty())
            emit canUndoChanged(false); // the whole burst netted out to nothing
        return;
    }
    m_undoStack.push_back(m_lastSettledSnapshot);
    while (m_undoStack.size() > kMaxUndoDepth)
        m_undoStack.removeFirst();
    m_lastSettledSnapshot = now;
}

void Project::undo()
{
    commitPendingUndoPoint(); // don't drop an in-flight edit under Ctrl+Z
    if (m_undoStack.isEmpty())
        return;
    m_redoStack.push_back(m_lastSettledSnapshot);
    const QByteArray prev = m_undoStack.takeLast();
    restoreSnapshot(prev);
    m_lastSettledSnapshot = prev;
    emit canUndoChanged(!m_undoStack.isEmpty());
    emit canRedoChanged(true);
}

void Project::redo()
{
    commitPendingUndoPoint();
    if (m_redoStack.isEmpty())
        return;
    m_undoStack.push_back(m_lastSettledSnapshot);
    const QByteArray next = m_redoStack.takeLast();
    restoreSnapshot(next);
    m_lastSettledSnapshot = next;
    emit canUndoChanged(true);
    emit canRedoChanged(!m_redoStack.isEmpty());
}
