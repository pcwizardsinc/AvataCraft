#pragma once

// Where a video-track clip (a picture-in-picture "inset") sits on the
// output frame, and how each output pixel is shaded by it. The one place the
// placement math lives: the viewport (src/render/shaders/inset.frag, which
// mirrors shade() below line for line) and the export compositor
// (src/export/InsetCompositor) both go through it, so what plays is what
// exports.
//
// Header-only and free of Qt / FFmpeg / Vulkan, so src/export can use it.

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace inset {

// The animatable part (InsetKeyTrack keyframes it). Positions and sizes are
// fractions of the output frame, so they survive a change of output size.
struct Look {
    float centerX = 0.78f; // inset centre, fraction of the output width
    float centerY = 0.75f; // ... of the output height
    float width = 0.30f;   // inset width, fraction of the output width
    float opacity = 1.0f;  // 0..1

    static constexpr float kMinWidth = 0.02f;
    static constexpr float kMaxWidth = 1.0f;

    Look clamped() const
    {
        Look l = *this;
        l.centerX = std::clamp(l.centerX, -0.5f, 1.5f); // may hang off an edge
        l.centerY = std::clamp(l.centerY, -0.5f, 1.5f);
        l.width = std::clamp(l.width, kMinWidth, kMaxWidth);
        l.opacity = std::clamp(l.opacity, 0.0f, 1.0f);
        return l;
    }
    bool operator==(const Look &o) const
    {
        return centerX == o.centerX && centerY == o.centerY && width == o.width &&
               opacity == o.opacity;
    }
    bool operator!=(const Look &o) const { return !(*this == o); }
};

inline Look lerp(const Look &a, const Look &b, float t)
{
    auto l = [t](float x, float y) { return x + (y - x) * t; };
    return {l(a.centerX, b.centerX), l(a.centerY, b.centerY), l(a.width, b.width),
            l(a.opacity, b.opacity)};
}

// The static frame around it (not keyframed).
struct Frame {
    float cornerRadius = 0.0f; // fraction of the inset's shorter side, 0..0.5
    float borderWidth = 0.0f;  // fraction of the output height, 0..kMaxBorder
    uint32_t borderRgb = 0xffffff;

    static constexpr float kMaxBorder = 0.05f;

    Frame clamped() const
    {
        Frame f = *this;
        f.cornerRadius = std::clamp(f.cornerRadius, 0.0f, 0.5f);
        f.borderWidth = std::clamp(f.borderWidth, 0.0f, kMaxBorder);
        f.borderRgb &= 0xffffff;
        return f;
    }
    bool operator==(const Frame &o) const
    {
        return cornerRadius == o.cornerRadius && borderWidth == o.borderWidth &&
               borderRgb == o.borderRgb;
    }
    bool operator!=(const Frame &o) const { return !(*this == o); }
};

// The inset's rectangle in output pixels (x, y = top-left; may lie partly
// outside the frame), plus its corner radius and border width in pixels.
struct Rect {
    double x = 0, y = 0, w = 0, h = 0;
    double radius = 0; // px
    double border = 0; // px
    bool empty() const { return w < 1.0 || h < 1.0; }
};

// `aspect` = the inset video's width / height (display aspect).
inline Rect place(const Look &look, const Frame &frame, double aspect, int outW, int outH)
{
    Rect r;
    if (outW <= 0 || outH <= 0)
        return r;
    if (!(aspect > 0.0))
        aspect = 16.0 / 9.0;
    r.w = double(look.width) * outW;
    r.h = r.w / aspect;
    r.x = look.centerX * outW - r.w / 2.0;
    r.y = look.centerY * outH - r.h / 2.0;
    r.radius = frame.cornerRadius * std::min(r.w, r.h);
    r.border = std::min(double(frame.borderWidth) * outH, std::min(r.w, r.h) / 2.0);
    return r;
}

// Where a picture is drawn whose width is `widthPerSize` times the look's
// width and whose point `anchorX` of the way across sits at the look's
// centreX: a title's picture, its look's width the text size
// (title::drawnLook).
inline Look anchored(Look l, double widthPerSize, double anchorX)
{
    l.width = static_cast<float>(l.width * widthPerSize);
    l.centerX = static_cast<float>(l.centerX + (0.5 - anchorX) * l.width);
    return l;
}

// A flat main-track clip (ClipItem::flat) as a full-frame layer: centred,
// the whole picture inside the frame (`fill` false: bars on two sides), or
// covering it (`fill` true: the overhang cropped). Not clamped -- a fill's
// width can exceed the frame's.
inline Look fitted(double aspect, int outW, int outH, bool fill)
{
    Look l;
    l.centerX = 0.5f;
    l.centerY = 0.5f;
    l.width = 1.0f;
    if (outW > 0 && outH > 0 && aspect > 0.0) {
        const double rel = aspect / (double(outW) / outH); // picture vs frame
        l.width = static_cast<float>(fill ? std::max(1.0, rel) : std::min(1.0, rel));
    }
    return l;
}

// How the output pixel whose centre is at (px, py) is covered: `alpha` is the
// inset's coverage there (antialiased over one pixel at the edge and the
// rounded corners), `border` how much of it is the border colour rather than
// the picture. The picture fills the whole rect; the border is drawn inside
// it, over the picture's edge. The caller multiplies alpha by the opacity.
struct Coverage {
    float alpha = 0.0f;
    float border = 0.0f;
};

inline Coverage shade(double px, double py, const Rect &r)
{
    // Signed distance to the rounded rectangle (negative inside).
    const double hx = r.w / 2.0, hy = r.h / 2.0;
    const double qx = std::abs(px - (r.x + hx)) - (hx - r.radius);
    const double qy = std::abs(py - (r.y + hy)) - (hy - r.radius);
    const double ox = std::max(qx, 0.0), oy = std::max(qy, 0.0);
    const double d = std::sqrt(ox * ox + oy * oy) + std::min(std::max(qx, qy), 0.0) - r.radius;
    Coverage c;
    c.alpha = static_cast<float>(std::clamp(0.5 - d, 0.0, 1.0));
    if (r.border > 0.0)
        c.border = static_cast<float>(std::clamp(d + r.border + 0.5, 0.0, 1.0));
    return c;
}

// Opacity multiplier of a linear fade in / out at clip-local timeline time
// `localMs` of a clip `spanMs` long (the audio fades' shape).
inline float fadeGain(int64_t localMs, int64_t spanMs, int64_t fadeInMs, int64_t fadeOutMs)
{
    double g = 1.0;
    if (fadeInMs > 0 && localMs < fadeInMs)
        g *= std::max(0.0, double(localMs) / double(fadeInMs));
    if (fadeOutMs > 0 && localMs > spanMs - fadeOutMs)
        g *= std::max(0.0, double(spanMs - localMs) / double(fadeOutMs));
    return static_cast<float>(std::clamp(g, 0.0, 1.0));
}

// Opacity multiplier going in a straight line from `from` at the start of a
// clip `spanMs` long to `to` at its end, at clip-local timeline time
// `localMs`: a transition's other clip blending in or out.
inline float rampGain(int64_t localMs, int64_t spanMs, float from, float to)
{
    if (spanMs <= 0)
        return from;
    const double t = std::clamp(double(localMs) / double(spanMs), 0.0, 1.0);
    return static_cast<float>(from + (to - from) * t);
}

// How a clip comes on at its start and goes off at its end, besides its
// fades: tied to the clip's edges like the fades, so it survives trims and
// moves, and on top of its keyframes, so a moving clip can still slide in.
struct Motion {
    enum class Kind {
        None,
        Slide, // in from just past the frame's `side` edge, out to it
        Pop,   // grows from nothing with a small overshoot; out: the reverse
        // A title's text typed on letter by letter; out: typed off from the
        // end. Doesn't move the picture: the title's picture changes
        // (titlerender::visibleAt).
        Type,
    };
    enum class Side { Left, Right, Top, Bottom };
    struct Part {
        Kind kind = Kind::None;
        Side side = Side::Left;
        int64_t ms = 500;
        bool operator==(const Part &) const = default;
    };
    Part in;
    Part out;

    static constexpr int64_t kMinMs = 100;
    static constexpr int64_t kMaxMs = 10000;

    bool isNone() const { return in.kind == Kind::None && out.kind == Kind::None; }
    Motion clamped() const
    {
        Motion m = *this;
        m.in.ms = std::clamp(m.in.ms, kMinMs, kMaxMs);
        m.out.ms = std::clamp(m.out.ms, kMinMs, kMaxMs);
        return m;
    }
    bool operator==(const Motion &) const = default;
};

// Which part of `m` plays at clip-local timeline time `localMs` of a clip
// `spanMs` long, and how far along to rest it is there (`q`, 1 = at rest):
// the out part is the in part played backwards, so it leaves the way it
// would have come. A clip too short for both parts plays each in its share
// of the span. `part` null: at rest.
struct MotionPhase {
    const Motion::Part *part = nullptr;
    double q = 1.0;
    // Where the in part ends and the out part starts, clip-local.
    double inEndMs = 0.0;
    double outStartMs = 0.0;
};
inline MotionPhase motionPhase(const Motion &m, int64_t localMs, int64_t spanMs)
{
    using Kind = Motion::Kind;
    double inMs = m.in.kind == Kind::None ? 0.0 : double(m.in.ms);
    double outMs = m.out.kind == Kind::None ? 0.0 : double(m.out.ms);
    MotionPhase p;
    p.outStartMs = double(spanMs);
    if (spanMs <= 0 || inMs + outMs <= 0.0)
        return p;
    if (inMs + outMs > double(spanMs)) {
        const double k = double(spanMs) / (inMs + outMs);
        inMs *= k;
        outMs *= k;
    }
    p.inEndMs = inMs;
    p.outStartMs = double(spanMs) - outMs;
    if (inMs > 0.0 && localMs < inMs) {
        p.part = &m.in;
        p.q = double(localMs) / inMs;
    } else if (outMs > 0.0 && localMs > spanMs - outMs) {
        p.part = &m.out;
        p.q = double(spanMs - localMs) / outMs;
    }
    p.q = std::clamp(p.q, 0.0, 1.0);
    return p;
}

// `drawn` -- where the picture is drawn: its centre and width -- moved by `m`
// at clip-local timeline time `localMs` of a clip `spanMs` long.
// `pictureAspect` is the picture's width / height, `outAspect` the output's.
inline Look moved(Look drawn, const Motion &m, int64_t localMs, int64_t spanMs,
                  double pictureAspect, double outAspect)
{
    using Kind = Motion::Kind;
    const MotionPhase phase = motionPhase(m, localMs, spanMs);
    const Motion::Part *part = phase.part;
    if (!part)
        return drawn;
    const double q = phase.q;
    if (part->kind == Kind::Slide) {
        const double ease = 1.0 - std::pow(1.0 - q, 3.0); // slows to a stop
        const double halfW = drawn.width / 2.0;
        const double halfH =
            pictureAspect > 0.0 ? drawn.width * outAspect / pictureAspect / 2.0 : 0.0;
        auto from = [ease](float rest, double edge) {
            return static_cast<float>(edge + (rest - edge) * ease);
        };
        switch (part->side) {
        case Motion::Side::Left: drawn.centerX = from(drawn.centerX, -halfW); break;
        case Motion::Side::Right: drawn.centerX = from(drawn.centerX, 1.0 + halfW); break;
        case Motion::Side::Top: drawn.centerY = from(drawn.centerY, -halfH); break;
        case Motion::Side::Bottom: drawn.centerY = from(drawn.centerY, 1.0 + halfH); break;
        }
    } else if (part->kind == Kind::Pop) {
        // Ease-out-back: past full size by about 10 %, then back to it.
        constexpr double c1 = 1.70158, c3 = c1 + 1.0;
        const double s = 1.0 + c3 * std::pow(q - 1.0, 3.0) + c1 * std::pow(q - 1.0, 2.0);
        drawn.width = static_cast<float>(drawn.width * std::max(0.0, s));
    }
    return drawn;
}

} // namespace inset
