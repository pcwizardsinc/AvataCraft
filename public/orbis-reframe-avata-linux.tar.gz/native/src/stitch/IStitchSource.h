#pragma once

#include "LensCalibration.h"

#include <cstdint>
#include <optional>
#include <functional>
#include <string>
#include <utility>
#include <vector>

namespace render {
struct LensFrame; // src/render/LensFrame.h
}
namespace insv {
struct BlurQuad;       // src/insv/BlurQuads.h
struct SeamCorrection; // src/insv/SeamCorrection.h
struct LensColour;     // src/insv/LensColour.h
}

namespace stitch {

// Privacy blur: the regions to mosaic in the frame at source time ptsMs
// (insv::BlurQuad, equirect / sphere frame), appended to `out`. Called on the
// reading thread for every frame stitched.
using BlurQuadsFn = std::function<void(int64_t ptsMs, std::vector<insv::BlurQuad>& out)>;

// Camera rotation from video time tSec to tSec + dtSec as a rotation vector
// (rad, sphere frame at tSec) -- insv::GyroStabilizer::bodyRotation.
using RsRotationFn = std::function<void(double tSec, double dtSec, float r[3])>;

// When each part of a frame was actually captured, relative to the frame time
// the stabilization is computed for, so the stitch can de-rotate every lens /
// sensor row to that one instant (the camera keeps turning in between; at the
// stick mount's ~11 Hz shake a few ms is a visible wobble).
//   lensOffsetSec: capture time of lens 0 / lens 1's picture (mid-sensor
//     row), relative to the frame time.
//   readoutSec: per lens, rows read top to bottom over this time around the
//     lens's capture time (0 = all rows at once).
//   scanColumns: the sensor reads columns instead of rows.
// The app sets readoutSec from GyroStabilizer::readoutSec (the file's rolling
// shutter); lensOffsetSec and scanColumns only tools/residual_stab sets.
struct CaptureTiming {
    double lensOffsetSec[2] = {0.0, 0.0};
    double readoutSec[2] = {0.0, 0.0};
    bool scanColumns = false;
    RsRotationFn rotationAt; // empty => off
    bool active() const
    {
        return rotationAt && (readoutSec[0] != 0.0 || readoutSec[1] != 0.0 ||
                              lensOffsetSec[0] != 0.0 || lensOffsetSec[1] != 0.0);
    }
};

// The stitch knobs, handed to IStitchSource::Open. width / height are the
// preview's (View menu; Project::previewStitch); lensGuard / method /
// seamColourBlend / seamFlow are the clip's own (Stitching panel;
// ClipItem::lensGuard / stitchMethod / seamColourBlend / seamFlow).
//
// NativeStitchSource honours all of them. Stabilization is not a stitch
// setting: insv::StabConfig.
struct PreviewStitchConfig {
    // Equirect preview resolution. Must stay 2:1 (equirect is 360x180 and the
    // reprojection shader assumes it) -- the panel only offers 2:1 presets.
    // 0 = Auto: per clip, AutoPreviewWidth() of its lens size and frame rate.
    int width = 0;
    int height = 0;

    // What's fitted over the lenses. The camera doesn't record it, so the user
    // picks it; it selects the matching lens profile in the clip's trailer
    // (docs/formats/insta360-x5.md §5.4). Guards shift the image ~2 % outward at the
    // seam -- the wrong choice leaves a ~4 deg ghost there. Defaults to
    // Premium: all the project's footage is shot with them.
    enum class LensGuard { None, Standard, Premium };
    LensGuard lensGuard = LensGuard::Premium;

    // How the two lenses are joined.
    //   DepthSeam: the old stitcher with its depth-aware seam -- per frame,
    //     the distance along the seam at which the two lenses agree, each lens
    //     stitched from its own centre at that distance, so near content
    //     (bike, rider, stick) isn't doubled; with the clip's measured seam
    //     correction and lens colour (SetSeamCorrection / SetLensColour).
    //   FixedSeam: the old stitcher without it: both lenses treated as one
    //     point (infinite stitch distance), with the clip's seam correction
    //     and lens colour.
    //   New: the new stitcher. Its base is the template: the lens model and
    //     calibration as they are, a fixed cross-fade, nothing measured from
    //     the clip -- the clip's seam correction and lens colour are not
    //     applied. Its layers, worked out from each frame and the frames just
    //     before it, come on top: the seam colour blend (seamColourBlend) and the seam flow (seamFlow).
    // New is the default for a clip that has no setting yet; a project
    // file that doesn't say is from before that and loads as DepthSeam
    // (Project::kOlderFileStitchMethod).
    enum class Method { DepthSeam, FixedSeam, New };
    Method method = Method::New;
    bool depthSeam() const { return method == Method::DepthSeam; }

    // The new stitcher's seam colour blend (insv::SeamColourBlend): the
    // lenses' colour matched per stretch of the seam from what both see in
    // the overlap over each frame and the quarter second before it (which SeekTo
    // measures first). Only with Method::New; the old stitcher has
    // its own lens colour.
    bool seamColourBlend = true;
    bool seamColourBlendOn() const { return method == Method::New && seamColourBlend; }

    // The new stitcher's seam flow (insv/SeamFlow.h): near things crossing
    // the seam joined up by optical flow between the lenses in the overlap,
    // the rest kept at the template's geometry; each frame's flow averaged
    // with the few frames before it (which SeekTo measures first). Only
    // with Method::New; on the GPU stitch, or on the CPU's where the app
    // was built with OpenCV.
    bool seamFlow = true;
    bool seamFlowOn() const { return method == Method::New && seamFlow; }

    // The camera's own lens calibration (Calibrate lenses) in place of the
    // file's; none = the file's. The guard is in it: no guard profile goes
    // on top. The clip's own, like lensGuard (ClipItem::lensCalibration).
    std::optional<LensCalibration> lensCalibration;

    bool operator==(const PreviewStitchConfig& o) const {
        return width == o.width && height == o.height &&
               lensGuard == o.lensGuard && method == o.method &&
               seamColourBlend == o.seamColourBlend && seamFlow == o.seamFlow &&
               lensCalibration == o.lensCalibration;
    }
    bool operator!=(const PreviewStitchConfig& o) const { return !(*this == o); }
};

// Which lens-guard profiles a clip's file carries (camera::ClipMetadata::
// standardGuard / premiumGuard). A guard whose profile the file lacks is
// stitched bare (DualFisheyeStitchSetup), so it is the same as None; a camera
// that records none (the ONE X2, the X6) has nothing to choose.
struct LensGuardProfiles {
    bool standard = false;
    bool premium = false;

    static LensGuardProfiles all() { return {true, true}; }
    bool any() const { return standard || premium; }
    bool has(PreviewStitchConfig::LensGuard g) const
    {
        switch (g) {
        case PreviewStitchConfig::LensGuard::Standard: return standard;
        case PreviewStitchConfig::LensGuard::Premium: return premium;
        case PreviewStitchConfig::LensGuard::None: break;
        }
        return true;
    }
    // `g` as the stitch applies it to this file.
    PreviewStitchConfig::LensGuard usable(PreviewStitchConfig::LensGuard g) const
    {
        return has(g) ? g : PreviewStitchConfig::LensGuard::None;
    }
    bool operator==(const LensGuardProfiles& o) const
    {
        return standard == o.standard && premium == o.premium;
    }
};

// Equirect widths (height = width / 2), from an X5 clip's lens size (each lens
// is lensWidth square; the full sphere is 2 x lensWidth wide).
inline int FullSphereWidth(int lensWidth) { return lensWidth > 0 ? 2 * lensWidth : 3840; }

// Auto preview: the full sphere, capped at what still plays in real time at
// this frame rate (tools/playback_bench, RTX 5070: decode + stitch + copy-back is
// 20.7 ms at 5760 for 8K30, 14 ms at 5120 for 5.7K60, 5.4 ms at 3840 for
// 4K120). 4K120's sphere is 3840, so every mode gets as close to full source
// detail as it can afford.
inline int AutoPreviewWidth(int lensWidth, double fps) {
    const int cap = fps > 90.0 ? 3840 : fps > 45.0 ? 5120 : 5760;
    const int full = FullSphereWidth(lensWidth);
    return (full < cap ? full : cap) & ~1;
}

// Export: all the detail the clip has, and at least 2x the output width so the
// rectilinear reproject never magnifies the equirect.
inline int ExportStitchWidth(int lensWidth, int outWidth) {
    int w = FullSphereWidth(lensWidth);
    if (w < 2 * outWidth)
        w = 2 * outWidth;
    if (w < 3840)
        w = 3840;
    return w & ~1;
}

// The parts of a clip's stitch that fell back from the GPU to the CPU
// (IStitchSource::GetGpuFallback).
struct GpuFallback {
    bool decode = false; // the lenses decode on the CPU
    bool stitch = false; // the equirect is stitched on the CPU
    // With `decode`: the codec ("H.264") when the GPU decodes video but not
    // this codec -- a lasting limit of the card, not memory running out.
    std::string codec;
    bool any() const { return decode || stitch; }
};

// Describes the source clip itself (native resolution/fps/duration) — not
// necessarily the resolution frames are actually served at. See Frame.
struct ClipInfo {
    int width = 0;
    int height = 0;
    double fps = 0.0;
    int64_t duration_ms = 0;
};

// One stitched equirect frame, decoded to interleaved 8-bit RGBA. width/
// height are this frame's actual dimensions, which for a live-playback
// source is the cached preview resolution, not ClipInfo's source resolution.
struct Frame {
    std::vector<uint8_t> rgba;
    int width = 0;
    int height = 0;
    int64_t timestamp_ms = 0; // rounded to the ms: seeks, trims, keyframes, the timeline
    int64_t timestamp_us = 0; // exact: the stabilizer's correction (insv::FramePts)
};

// Serves stitched equirect frames from an Insta360 .insv file for interactive
// playback/scrubbing.
//
// The implementation (stitch::NativeStitchSource, src/insv/) does true
// frame-at-time-T stitching in-process: Open() only parses the calibration
// trailer and opens the demux, then SeekTo()/ReadFrame()/GetFrame() decode the
// lens pair at the requested time and stitch on demand (Vulkan compute, with a
// CPU fallback). No up-front whole-file pass, no on-disk cache. Full-resolution
// export drives the same interface at a larger equirect size (see
// ReframeExportController).
class IStitchSource {
public:
    virtual ~IStitchSource() = default;

    // Opens the clip for stitching with `config` (preview size, lens guard,
    // depth seam). Returns false on failure, with GetLastError() set and
    // naming the file.
    virtual bool Open(const std::string& clip_path, const PreviewStitchConfig& config) = 0;

    // Valid only after a successful Open().
    virtual const ClipInfo& GetInfo() const = 0;

    // Random-access single frame: the frame at timestamp_ms. Equivalent to
    // SeekTo(timestamp_ms) + ReadFrame(), and it moves the sequential playhead
    // the same way. Good for scrubbing; for continuous playback use SeekTo +
    // ReadFrame directly so the decoder runs forward without a per-frame seek.
    // Valid only after a successful Open().
    virtual Frame GetFrame(int64_t timestamp_ms) = 0;

    // Positions the sequential playhead. The next ReadFrame() returns the first
    // frame at or after timestamp_ms. Blocks until that frame is decoded and
    // stitched. Returns false with GetLastError() set on failure. Valid only
    // after a successful Open().
    virtual bool SeekTo(int64_t timestamp_ms) = 0;

    // A quick seek: the next SeekTo (that one only) and the frame read after
    // it skip what only makes that frame look exactly as playback into it
    // would -- the seam measurements (the new stitcher's seam colour blend
    // over the quarter second before it, the depth-aware seam where the clip isn't
    // analysed); the frame keeps the last frame's. For the frames a scrub
    // passes through; the scrub's final seek is exact. Default: nothing to
    // skip.
    virtual void SetQuickSeek(bool /*on*/) {}

    // The source time (ms) of the keyframe nearest `timestamp_ms`: SeekTo() of
    // it decodes a single frame, so it's the cheap target while scrubbing. The
    // default (no index) is `timestamp_ms` itself.
    virtual int64_t NearestKeyframeMs(int64_t timestamp_ms) const { return timestamp_ms; }
    // The keyframes at or before / at or after `timestamp_ms` (source ms, as
    // NearestKeyframeMs); -1 where there's none. The default (no index)
    // knows none.
    virtual void KeyframesAround(int64_t timestamp_ms, int64_t& before, int64_t& after) const {
        (void)timestamp_ms;
        before = after = -1;
    }

    // Returns the next frame in play order and advances the playhead,
    // decoding strictly forward -- no seek, no decoder flush. Returns an empty
    // Frame (rgba.empty()) at end-of-clip; also on error, with GetLastError()
    // set. Not safe to call concurrently with itself, GetFrame, or SeekTo.
    virtual Frame ReadFrame() = 0;

    virtual const std::string& GetLastError() const = 0;

    // After a successful Open(): what of this clip runs on the CPU although
    // the GPU should do it -- the GPU part failed to start, most often
    // because the graphics memory is full. Can grow on a read (the GPU
    // stitch gives up at a frame it can't allocate for); call from the
    // reading thread. A GPU that can't decode video at
    // all is said once at startup, so it isn't a fallback here; nor is a GPU
    // path turned off on purpose (INSV_NO_GPU_*). Default: none.
    virtual GpuFallback GetGpuFallback() const { return {}; }

    // Per-lens / per-sensor-row capture-time correction for subsequent frames
    // (see CaptureTiming, NativeStitchSource): `timing` for frames before
    // source time `untilMs`, `after` for frames from it on -- so the reader
    // can hand over to the next clip of the same file at a cut without
    // knowing which frame will cross it. An inactive timing turns it off.
    // Safe to call from another thread than the reader. Default:
    // unsupported, ignored.
    virtual void SetCaptureTiming(CaptureTiming /*timing*/, int64_t /*untilMs*/,
                                  CaptureTiming /*after*/) {}
    // One timing for every frame.
    void SetCaptureTiming(CaptureTiming timing)
    {
        SetCaptureTiming(std::move(timing), INT64_MAX, CaptureTiming{});
    }

    // Seam alignment fine-tune (insv::StitchParams::seam, measured by
    // stitch::MeasureClipSeam) for subsequently stitched frames. Call from
    // the reading thread. Default: unsupported, ignored. The new stitcher
    // (PreviewStitchConfig::Method::New) ignores it.
    virtual void SetSeamCorrection(const insv::SeamCorrection& /*c*/) {}

    // The clip's lens colour (insv::StitchParams::lensColour, measured by
    // stitch::MeasureClipLensColour) for subsequently stitched frames. Call
    // from the reading thread. Default: unsupported, ignored. The new
    // stitcher ignores it.
    virtual void SetLensColour(const insv::LensColour& /*c*/) {}

    // Privacy blur for subsequent frames: every frame stitched is mosaicked
    // inside the quads `fn` returns for its time (empty fn = off). Safe to
    // call from another thread than the reader. False when the source can't
    // blur -- a caller that must not show the footage unblurred stops there.
    virtual bool SetBlurQuads(BlurQuadsFn /*fn*/) { return false; }

    // The next frame as the decoded fisheye pair on the GPU, shareable with
    // another Vulkan device (render::LensFrame), instead of a stitched equirect
    // -- for a viewport that renders the view straight from the lenses. Same
    // play order / seeking as ReadFrame(). False at end-of-clip (GetLastError()
    // empty) or on error; after an error the next read tries the same frame
    // again (the graphics memory may have been full for a moment). Default:
    // unsupported; LensFramesAvailable() tells.
    virtual bool LensFramesAvailable() const { return false; }
    virtual bool ReadLensFrame(render::LensFrame& /*out*/) { return false; }
    // Let go of GPU memory held for lens frames that nobody is using (the
    // source went idle). Default: nothing to do.
    virtual void TrimLensFrames() {}

    // Give back everything the source holds on the graphics card -- its
    // decoders and their frame pools, the GPU stitch -- and keep the parsed
    // clip (its description, calibration, settings, seam state), so taking
    // it up again costs a decoder start, not an Open(). Lens frames already
    // handed out stay valid. True when it released something; false when it
    // holds nothing there, or can't let go (frames kept by KeepNextPair /
    // HoldNextPair). A source that fell back to the CPU (GetGpuFallback)
    // can be released too, so that ResumeGpu tries the GPU again. Call from
    // the reading thread, like the reads.
    virtual bool ReleaseGpu() { return false; }
    // Released and not yet taken up again.
    virtual bool GpuReleased() const { return false; }
    // Take a released source up again: what Open() did on the GPU, the GPU
    // tried afresh (a clip that fell back to the CPU while the memory was
    // full gets the GPU when it's there again; GetGpuFallback says). The
    // next read carries on where the source was, unless a SeekTo comes
    // first. Every read and SeekTo does this itself; call it first where
    // the answers of LensFramesAvailable() / keyframe lookups matter,
    // since a released source has neither. False with GetLastError() set
    // when the clip can't be opened again (the file is gone).
    virtual bool ResumeGpu() { return true; }
};

} // namespace stitch
