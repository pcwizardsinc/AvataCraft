#pragma once

#include <cstddef>
#include <cstdint>
#include <vector>

#include "ColorLut.h"       // color::Grade
#include "ViewProjection.h" // view::Pose

// CPU equirectangular -> "flat" view reprojection for the export pipeline.
// A direct port of the interactive viewport's fragment shader
// (src/render/shaders/equirect.frag): for each output pixel, reconstruct the
// view-space ray (ViewProjection.h: the vertical FOV and the distortion),
// rotate it by yaw/pitch to a world-space look direction, convert that to
// equirect UV, and bilinearly sample the source frame.
//
// Deliberately Qt-free and Vulkan-free: it is the reproject half of the export,
// linked into reframe_flatten alongside system FFmpeg only. Export is offline,
// so a multithreaded CPU pass is the right tool.

namespace exportpipe {

struct ReframeView {
    view::Pose pose;
    float aspect = 1.0f;  // output width / height
    // Gyro de-rotation (row-major 3x3) in the sphere frame, applied to the
    // world ray after the pose -- same as equirect.frag's pc.stab.
    float stab[9] = {1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f};
    // Colour panel: the LUT and the four adjustments; default = neutral.
    // Same formula as the shaders' color_grade.glsl -- see
    // ClipItem::ColorGrade.
    color::Grade colorGrade;
};

// Reproject an interleaved 8-bit RGBA equirect frame (eqW x eqH) into an
// interleaved 8-bit RGBA rectilinear frame (outW x outH). `outRgba` must have
// room for outW*outH*4 bytes. The equirect seam wraps horizontally (U repeat);
// the poles clamp vertically (V clamp-to-edge) -- matching the sampler in
// src/render/EquirectViewportWindow.cpp.
void RenderRectilinear(const uint8_t* eqRgba, int eqW, int eqH,
                       uint8_t* outRgba, int outW, int outH,
                       const ReframeView& view);

// Split screen: one pane of the picture, its rectangle in the output frame
// and its pose.
struct PaneView {
    int x = 0, y = 0, w = 0, h = 0;
    view::Pose pose;
};

// RenderRectilinear for a split picture: each of `panes` into its rectangle
// of the outW x outH frame, with its own pose and its rectangle's aspect
// (view's pose and aspect are ignored; its stab and grade go for all), the
// rest of the frame `fillRgba` (R in the low byte).
void RenderRectilinearPanes(const uint8_t* eqRgba, int eqW, int eqH, uint8_t* outRgba, int outW,
                            int outH, const std::vector<PaneView>& panes, uint32_t fillRgba,
                            const ReframeView& view);

// Apply a colour grade (as ReframeView::colorGrade) to `pixels` interleaved
// 8-bit RGBA pixels in place -- the same formula RenderRectilinear grades
// with. A neutral grade is a no-op.
void GradeRgba(uint8_t* rgba, size_t pixels, const color::Grade& grade);

} // namespace exportpipe
