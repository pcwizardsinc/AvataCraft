# orbis-reframe user manual

A guide to orbis-reframe for people who edit with it, not for developers.
For how the code works, see the other documents in [`docs/`](..).

| Chapter | Contents |
|---|---|
| [Getting started](getting-started.md) | What your computer needs, which packages to install, starting the program and opening your first clip |
| [The main window](main-window.md) | A tour of the window: viewport, player bar, timeline, edit toolbar, sidebars and menus |
| [The timeline](timeline.md) | Moving around, arranging, trimming, splitting and speeding up clips, audio and overlay tracks, linked audio |
| [Reframing](reframing.md) | Choosing where the camera looks: the view, keyframes, and Track subject |
| [Stabilization](stabilization.md) | Steadying the picture with the camera's gyro: the modes, their settings, gyro sync, and what can't be fixed |
| [Stitching](stitching.md) | Joining the two lenses: lens guards, lens calibration, the stitcher, depth-aware seam, seam alignment, filming tips |
| [Audio and noise reduction](audio.md) | The camera's sound, two microphones, music and other audio files, levels and fades, noise and wind reduction, lining up a separate recorder |
| [Colour](colour.md) | Exposure, contrast, saturation and temperature for each clip, and LUTs (e.g. for I-Log footage) |
| [Picture in picture](picture-in-picture.md) | Flat videos in a small frame over the picture: adding, placing, keyframing, frame and border |
| [Titles](titles.md) | Text over the video: ready-made titles, adding one, its text, font, colour and size, sliding it in and out or typing it on, the recording time as a running clock, speed, altitude and heading from the GPS, lean and G-force, gauges and the route, placing and keyframing it |
| [Transitions](transitions.md) | Going over from one clip to the next at a cut: a crossfade or a dip to black, its length, the footage it uses |
| [Privacy blur](privacy.md) | Finding and blurring number plates, checking and correcting the scan, blurring a plate by hand |
| [Projects and export](projects-and-export.md) | The project library, project folders, saving and opening projects, where the clips are, aspect ratio, resolution, frame rate and bit depth, exporting the video, screenshots |
| [Media information](media-information.md) | What the Media information section shows about a clip's file, video, audio and camera |
| [Keyboard shortcuts](keyboard-shortcuts.md) | Every keyboard shortcut and mouse action on one page |
