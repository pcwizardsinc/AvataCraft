# Insta360 X6 file format

**Desk research (2026-10-15), then two contributors' clips, read with our
code on their machines: a test set (2026-10-18: 24 clips, 8K / 6K / 4K,
Standard, I-Log and Dolby Vision, firmware v1.2.36) and another camera
(2026-11-11: same firmware, 8K 30 Standard with deliberate turns, Dolby
Vision, I-Log, 8K 50).** The ✅ below are from those clips; the maintainer
hasn't examined an X6 file yet. Public specs, Insta360's manuals and
Gyroflow's telemetry-parser for the rest. Written as differences
from the X5 ([`insta360-x5.md`](insta360-x5.md), "X5 §n" below). Markers as
in [`README.md`](README.md).

## Files and streams

- 📖 One `.insv` per take holding both lenses, the X5's naming (X5 §1).
- 📖 Two 1/1.1" square sensors (a third more area than the X5's). H.265
  only, up to 180 Mb/s.
- 📖 360 modes:

  | mode | frame | fps | per lens (⚠️) |
  |---|---|---|---|
  | 8K | 7680×3840 | 50 / 48 / 30 / 25 / 24 | 3840² |
  | **6K** (new) | 6016×3008 | 60 / 50 / 48 / 30 / 25 / 24 | **3008²** |
  | 4K | 3840×1920 | 100 / 60 / 50 / 48 / 30 / 25 / 24 | 1920² |

- ✅ Clips at all three lens sizes open and stitch. The app names a clip's
  mode by its lens size: 3008² is **6K** (the X6 row of `insv::InsvModel`).
- ✅ Vulkan decode + stitch on an AMD Radeon 8060S (Strix Halo iGPU, RADV),
  8K 30: ~84 fps decode, ~35 fps for the full 7680-wide stitch, ~60 fps for
  the direct view.
- ❓ **8K 50** in real time (~1.5 Gpx/s across both lenses, ~1.7× the
  X5's 8K 30, X5 §3.3). A contributor's `playback_bench` (60 frames) on an
  NVIDIA RTX 5070 Ti gave decode ~30.9 fps, fused view ~16.9 fps, direct
  view ~18.4 fps. That is far below the AMD figure above at the same frame
  size, and below an X5 8K 30 clip on an RTX 5070 (decode ~125 fps, fused
  view ~94 fps, 2026-11-11), so something else likely limits that run; not
  found yet. A stand-in on the RTX 5070 (2026-11-11; an X5 8K 30 clip's
  lenses re-encoded to HEVC Main 10, 3840², 50 fps, P frames only, ~76 and
  ~140 Mb/s per lens, Release `playback_bench --frames 60`): decode 188 /
  160 fps, fused view 118 / 106, direct view 117 / 104 -- 5x real time.
  Frame size, 10-bit and 50 fps don't explain the contributor's figure, nor
  a Debug build (the same) or CPU decode (the bench reports nothing off the
  all-GPU path, and that run did). Still ❓ until an X6 8K 50 file runs
  here: its encoder settings (B frames, tiles, bitrate peaks) may differ
  from the stand-in's.

## Modes and sample clips

All the X6's modes 📖 (Insta360's shooting specs, Sources). We have no X6
file; **the contributor's set** is the 24 clips of 2026-10-18, **the
contributor's camera** the 2026-11-11 clips (both fw v1.2.36). The status
words are the X5's (X5 §3.4), and *enough* needs a clip we can run
ourselves.

| Mode | Spec | Files | Clips | Status |
|---|---|---|---|---|
| 360 Video 8K | 50 / 48 / 30 / 25 / 24 | one `.insv` + `.lrv` | contributor's set; contributor's camera: 8K 30 (turns), 8K 50 | **8K 50 wanted** (real-time decode, see above), and any 8K clip of our own |
| 360 Video 6K | 60 / 50 / 48 / 30 / 25 / 24 | as above | contributor's set | one clip of our own wanted |
| 360 Video 4K | 100 / 60 / 50 / 48 / 30 / 25 / 24 | as above | contributor's set | one clip of our own wanted |
| I-Log 10-bit | | as above | contributor's set; contributor's camera: 8K 30 moving | confirmed on contributors' clips (opens, stitches, limited-range BT.709, log profile); **one of our own wanted**, moving |
| Dolby Vision (HLG) | | as above | contributor's set; contributor's camera: 8K 30 | tagging and export with the shipped HLG LUT confirmed on contributors' clips; **one of our own wanted**: the HLG LUT's roll-off |
| Lens guards (Standard, Premium) | | as above | none known (the contributors' clips are bare: no field 145) | **one clip with each guard, and the same scene bare, wanted** |
| IMU axes | | | contributor's camera: 8K 30, deliberate turns | `"z,-x,-y"` confirmed on a contributor's clip (see Trailer); **one of our own wanted** to check it with our own fit |
| PureVideo | 8K / 4K, 30 / 25 / 24; 6K at **5760×2880** | ❓ | none | **wanted**: 2880² lenses, which the X6's modes don't list |
| InstaFrame 2.0 | 360 8K 30 / 25 / 24 + flat 4K | `.insv` + `.mp4` ("360 Video Backup" on), `.mp4` only (off) | none | **wanted** |
| Timelapse | 16K 15360×7680, 8K, 30 / 25 | ❓ | none | **wanted**: 16K is 7680² per lens |
| TimeShift | | ❓ | none | **wanted** |
| Bullet Time | 8K 7680×1920 100, 6K 6016×1504 120, 4K 3840×960 240 | ❓ | none | **wanted**: not a 2:1 frame |
| Loop Recording, Road Mode | | ❓ | none | wanted, low |
| Single-lens Video, PureVideo | 5K / 4K / 2.7K, 4:3 to 9:16, up to 120 | `.mp4` | none | wanted |
| Single-lens FreeFrame | 6016² 30 / 25, 3040×3840 60…25 | `PRO_VID_….mp4` | none | wanted |
| 360 Photo (HDR, AEB, Interval, Starlapse) | 120 MP 15520×7760, 30 MP | `.insp`, `.dng`, `.jpg` | none | wanted, low |
| Audio: Auto, Engine Sound Enhancement, Auto Wind Noise Reduction, Voice Enhancement, Stereo, 360 Audio | 48 kHz AAC | | none | one clip of each wanted |

## Colour: 10-bit, log and HDR

- 📖 Colour modes Standard, **Dolby Vision** and **I-Log 10-bit**.
- ✅ Every clip is H.265 Main 10 (`yuv420p10le`), in all three
  colour modes. Standard and I-Log clips are tagged `bt709`; **Dolby Vision
  clips are tagged `bt2020nc` + `arib-std-b67` (HLG), limited range**, with
  no Dolby Vision RPU side data.
- ✅ **Standard and I-Log streams are limited range** on the contributor's
  camera's clips (FFmpeg `tv` / `yuv420p10le` without full-range), unlike the X5's full
  range (X5 §3.3). The app decodes each clip with the matrix and range its
  stream is tagged with; a stream without a range tag is taken as limited,
  the HEVC default.
- ✅ The mode is only in the trailer, record 0x101 field 22 `gamma_mode`:
  `standard`, `I_Log` or `Dolby_Vision` (X5 §3.3 for the X5's values). The
  app reads it as the clip's colour profile; only `I_Log` is recognised as
  a log profile so far. Media information shows Dolby Vision as
  *Dolby Vision (HLG)* when the stream is HLG.
- The app's GPU stitch samples the decoder's pictures through a ycbcr
  conversion. Since 2026-10-18 it takes 10-bit HEVC (Main
  10) too: FFmpeg's Vulkan decoder gives P010 images
  (`VK_FORMAT_G10X6_B10X6R10X6_2PLANE_420_UNORM_3PACK16`), the stitcher's
  conversion is made for that format (by the stream's bit depth), and the
  viewport's shared lens planes are 16-bit (R16 / R16G16). Checked on a
  stand-in -- the X5 I-Log clip re-encoded to Main 10 with its trailer
  kept: export (both GPU paths, and the CPU fallback) and playback match
  the 8-bit original at 46-48 dB PSNR, in real time -- and ✅ on the
  contributor's X6 clips. Since 2026-10-19 the conversion takes the
  stream's matrix and range (BT.709 / BT.601 / BT.2020, full or limited)
  on the GPU, in the viewport and on the CPU path alike. Checked on
  stand-ins -- an X5 clip re-encoded to BT.2020 limited range, 8- and 10-bit:
  45-47 dB PSNR against the original, where the old fixed conversion gave
  29 dB -- and ✅ export of a real Dolby Vision clip through the shipped
  HLG → Rec.709 LUT (a contributor's, 2026-11-11, `reframe_export`).
- An I-Log clip stitches correctly but looks flat until Insta360's LUT is
  applied (below). Dolby Vision clips are HLG / BT.2020 as tagged and need
  an HLG -> Rec.709 LUT; Insta360 publishes none, so the app ships one
  (`tools/make_hlg_lut`, from the BT.2100 / BT.2408 formulas) and offers it
  for any clip whose stream is tagged HLG (`arib-std-b67`).
- The X5 has I-Log too, 8-bit (X5 §3.3).
- 📖 Insta360's 10-bit I-Log LUTs (`X6_I-Log_LUTs.zip`, version 2.0, made
  2026-05-20): 3D `.cube` files, each at 33³ and 65³, from I-Log to Rec.709
  / BT.1886 (`X6_I-Log_to_Rec709_BT1886_s65_v2.cube`), to Rec.2020 PQ and to
  Rec.2020 HLG (1000 nits, 203 nits diffuse white). The app reads all of
  them (Colour ▸ LUT); the Rec.709 one is the one for its SDR output. The
  10-bit pictures are graded in float before the output, so they shouldn't
  band; a 10-bit export (Project settings ▸ Bit depth) keeps 10 bits
  through to the file.

## Trailer

- ✅ The X5's framing (magic, footer, record directory). Record 0x101 has
  serial, model (`Insta360 X6`) and firmware; the IMU (0x300, ~1 kHz) and
  exposure (0x400) records parse with the X5's layouts.
- ✅ The extended MEI calibration string is there, the X5's 56-token
  layout: e.g. xi 2.455, fx / fy 7232, cx / cy ~3850 / 3880 (the
  contributor's set) and fx / fy ~7220, cx / cy ~3865 / 3889 (the
  contributor's camera) -- per unit, from the factory -- roll ~90,
  combined frame **15488×7744**, type 193. The sanity ranges in
  `Calibration.cpp` hold. It is not in the short maker-notes tags, so
  `insv_trailer_dump`'s `Parameters:` line is empty; the string is on its
  `Extended:` line.
- ✅ Field 27 `window_crop_info`: src 7744², **dst 7680²** (X5: 5376² ->
  5312², X5 §5.1). The dst width is the window fx / fy are given in, so the
  stitch reads it from the file (`InsvMakerNotes::crop_dst_w` ->
  `LensCalibExt::focalRefW`); with the X5's 5312 the lens circles come out
  too small and the sphere has gaps between them. A file without the field
  takes its model's value from `insv::InsvModel`, with a log line.
- ✅ **No field 145 lens-profile table** in any contributor's clip (all
  bare lenses): no lens-guard or dive-case profiles, so the stitch
  takes every lens as bare at the default 200° field of view. Stitches at
  all three sizes cover the sphere without gaps, so 200° looks right for
  bare lenses.
- 📖 The X6 has **lens guards** as accessories, in a Standard and a Premium
  version, like the X5 (Insta360 store; retailers, Sources). A retailer
  says the camera detects fitted guards and adjusts its stitching.
- ❓ What a guarded X6 clip records: whether the trailer then has a field
  145 table in the X5's numbering and layout (X5 §5.4: `ProtectorS`,
  `ProtectorA`, ... with a θ→height polynomial and field of view each), the
  profiles under another field or name, or only a flag saying which guard
  was fitted. Until a clip with each guard shows it, the app stitches every
  X6 clip as bare lenses and greys out **Lens guards**; a guarded clip then
  stitches with a slightly wrong lens model.
- ✅ **IMU axis map `"z,-x,-y"`** (the X5's, X5 §6.3; the X6 row of
  `insv::InsvModel::imuAxes`), measured 2026-11-11 by a contributor on an
  8K 30 Standard clip (~27 s) with a still start, then deliberate turns
  about each axis, fw v1.2.36; to check on a clip of our own. Method: `tools/residual_stab --diagnose` (trim 4–26 s) and the
  same tool's residual pan on 4–12 s against `z,x,y` and `-x,y,-z`.
  - Horizon lock vs gravity: mean tilt ~0.4° with `"z,-x,-y"`.
  - Stick-band correction / raw rotation ratio **1.02** at scale 1.
  - Residual forward pan lowest with `"z,-x,-y"` on the compared stretch.
  - Video↔IMU offset from the file's timing ~+380 ms (exposure lock-in
    ~+394 ms); gyro ~1 kHz, rad/s. telemetry-parser has no X6-specific
    code (unknown models get `Xyz`).

## Sources

- Insta360 X6 manual, shooting specs:
  <https://onlinemanual.insta360.com/x6/en-us/specs/shooting-specs>
- Insta360 X6 manual, file formats:
  <https://onlinemanual.insta360.com/x6/en-us/operating-tutorials/storage/fileformat>
- Insta360 manual, I-Log mode (X5 and X6):
  <https://onlinemanual.insta360.com/x6/en-us/operating-tutorials/capture-preview/features/ilog>
- Insta360 X6 specs page: <https://www.insta360.com/specs/x6>
- Insta360 store, X6 Standard Lens Guards:
  <https://store.insta360.com/ca/product/x6-standard-lens-guards>
- Clifton Cameras, Insta360 X6 Lens Guards (Standard and Premium):
  <https://www.cliftoncameras.co.uk/insta360-x6-lens-guards/kit-variation/premium>
- George's, Insta360 X6 Standard Lens Guards (the camera detects them):
  <https://www.georges.com.au/products/insta360-x6-standard-lens-guards>
- Insta360 I-Log LUT downloads: <https://www.insta360.com/download/i-log>
- Gyroflow telemetry-parser, `src/insta360/mod.rs`:
  <https://github.com/AdrianEddy/telemetry-parser>
