# Antigravity A1 file format

**Desk research (2026-10-15); measured on clips 2026-10-29**: three
contributed 8K H.265 flights, then a second set from the same drone: one
H.264 clip in each of nine video modes (8K, 5.2K, 4K 100) and two photos;
**a third set (2026-11-01, measured 2026-11-02)**: a take-off and a
landing, 5.2K 60 in H.265, 4K Slow Motion, a timelapse, a 14 MP photo and
AEB DNGs, and Antigravity Studio's 360 exports of one clip (*Modes and
sample clips*).
What's marked ✅ below is checked on them; the modes we have no clips of
are still desk research, from reviews and Gyroflow's telemetry-parser. The
app supports the A1 **experimentally** from 2026-10-29: 8K clips open,
stitch, stabilize (leveled by the drone's own attitude) and export; 5.2K
and 4K 100 clips open and stitch (below). The A1 is a 360 drone from Antigravity, a
brand incubated by Insta360, and writes the same `.insv` family; written as
differences from the X5 ([`insta360-x5.md`](insta360-x5.md), "X5 §n" below).
Markers as in [`README.md`](README.md).

## Streams

- 📖 Two 1/1.28" sensors. Reviews say **180°** lenses, but ✅ each lens
  images **~200°**, like the X5's: by the clip's own calibration the image
  circle's edge lies at ~100° off-axis all round (99-101° on lens 1;
  101-105° on lens 0, where the frame clips the circle), measured on a
  frame of `_011` and `_012` by where the picture goes dark. The stitch's
  200° default (X5 §5.4, used when the file has no lens profiles) fits.
  The A1's frame is cropped closer to the circle than the X5's: the circle
  nearly fills the 3840² stream.
- 📖 360 modes, H.264 or H.265, up to 170 Mb/s:

  | mode | frame | fps | per lens (✅) |
  |---|---|---|---|
  | 8K | 7680×3840 | 30 / 25 / 24 | 3840² |
  | **5.2K** (new) | 5248×2624 | 60 / 50 / 30 / 25 / 24 | **2624²** |
  | 4K | 3840×1920 | 100 / 30 / 25 / 24 | 1920² |

  ✅ on our clips: 8K at 30 (29.97, 30000/1001), 25 and 24; 5.2K at 60
  (59.94, 60000/1001), 50, 30 (29.97), 25 and 24; 4K at 100 (exactly 100,
  stored at the capture rate); 4K Slow Motion, captured at 100 and stored
  at 29.97 (*Slow motion and timelapse*). Every mode writes the same calibration
  (below), so the per-lens sizes are the one 5248² sensor window scaled.
  The camera's target bitrate is field 135, in units of 2²⁰ b/s: 170 for
  8K (both codecs), 105 for 5.2K, 140 for 4K 100; the two streams together
  measure 177 / 109 / 147 Mb/s (decimal).
- ✅ **One `.insv` holds both lenses** as two square streams, HEVC Main
  or H.264 High, 8-bit, full range (`yuvj420p`), BT.709 on all our clips
  (handler `INS.AVC` for H.264), lens 0 (looking **down**)
  first, lens 1 (looking **up**) second. No audio track; a `mov_text` track
  holds only a sensor frame counter per frame (`F:13776`, ...).
- ✅ File names: **`VID_<date>_<time>_<n>.insv`**, with no lens token
  (the X5's is `VID_…_00_…`), and the proxy beside it
  **`PRX_<date>_<time>_<n>.prx`**: the same name with `PRX` and `.prx`, both
  fisheyes side by side at 2560×1280 (the X5's `.lrv`, X5 §3.2), with a
  trailer of its own (records 1 and 2). ✅ The MP4's `creation_time` is
  the recording start in UTC to the second: on our first three clips it is
  the name's time, which is local, four hours ahead (five on the
  2026-11-01 set, the day the contributor's clocks went back).
- ✅ **The file holds its own name**: in the MP4 header, `moov` /
  `udta`, in the `free` box after the `AMBA` box, as the path on the card,
  `C:\DCIM\CAM_001\VID_<date>_<time>_<n>.insv` (the proxy:
  `PRX_….prx`; the `.insv` also holds its proxy's name). So a renamed clip
  can be given its name back, take number and all; the second set came
  renamed by mode and got its names back so, matching
  the time rebuilt from `creation_time` and field 7 on every file. The
  app takes a renamed clip's recording time from it and finds the proxy
  by it. The photos hold no name.
- ✅ **A proxy carries its clip's field 24** (the first frame's time on the
  drone's clock) and serial, on all nine pairs of the second set: what ties
  a renamed proxy to its clip; the app takes one found by the held name or
  the clip's stem only when both match.
- ✅ **Untouched files can be told apart.** Field 9 of record 1 is the
  byte size of the file before the trailer, exactly, on every `.insv` and
  `.prx` we have (12 clips, 9 proxies): a re-muxed or trimmed file no
  longer matches it.
- ✅ **The drone in the picture**: on our clips, only a light bar with a
  dark edge at the very rim of lens 0 (the downward one), 94-97° off its
  axis, in the same place on every clip -- the drone's body or an arm
  seen past the horizon. It lies at the outer end of the seam's blend
  band, where lens 0 hardly counts (the edge fade), so it doesn't show in
  the stitched picture (checked at the spot, depth-aware seam off and on).
  Nothing of the drone near the seam elsewhere, nor in lens 1. ✅ **On the
  ground** (take-off `_024`, landing `_025`, seen in the proxies): two
  white landing legs reach into lens 0's picture from its rim, with the
  pad below them; ❓ how much of them the stitched picture shows (not
  checked).

## Trailer

- ✅ The same 78-byte footer as the X5 (X5 §4.1): magic
  `8db42d694ccc418790edff439fe026bf`, trailer version 3. The footer's
  header names the Offsets table (type 0, 570 bytes: 57 entries).
- ✅ **The Offsets table (X5 §4.2) is the only index.** Each record's payload
  starts a **256 KiB slot** (the entries' offsets are 0x40000 apart, a few
  records packed between them), and **no six-byte header follows a
  record**: the bytes after it are zeros or the next record's data. So the
  walker takes each record's type and size from its table entry, as
  telemetry-parser does; reading them from the header after the record
  finds nothing. Checked on all three clips and the `.prx` proxy.
- ✅ Records in the clips: types 1 (Metadata, protobuf), 2 (thumbnail), 3
  (IMU), 4 (exposure), 7 (GPS), 9, 11, 14, 23, 32, 33, 37 (attitude), 38
  and 56; the proxy holds 1 and 2. Of the ones the X5 doesn't have, 37 is
  read and 14 / 56 partly understood (below); 23, 32, 33 and 38 hold
  timestamped floats, meaning ❓ (a flight log?).
- ✅ Record 1 is the X5's protobuf (X5 §5.1); on our clips: model (field 2)
  `Antigravity A1`, firmware `10.0.397.3_5.5`; field 27 `{5248, 5248, 5248,
  5248}`, so the focal reference is 5248; the **40-token `offset_v3`**
  MEI calibration (field 54, X5 §5.3; no 56-token string), in a 10496×5248
  side-by-side frame, `xi` 1.504, lens type 155, which the app reads; and a
  34-token `offset_v2` (X5 §5.3: radius, centre, yaw / pitch / roll,
  baseline, four polynomial coefficients; lens type 112) with the angles
  in another form, pitch near 0 (lens 0 yaw / pitch / roll 179.66 / −0.29
  / 88.88, lens 1 179.90 / −0.43 / 89.69), not used. ✅ **Both strings
  are identical on every clip of all three sets** (17 clips, one drone),
  so the clips can't tell a misread calibration from a constant the
  vendor's software adds; fields 24, 25 (readout
  ~21.25 ms), 28 (3.7 ms), 62 (raw IMU) and 65 (±32 g, ±2000 °/s) as on the
  X5, and the IMU (~1 kHz) and exposure records decode with the X5's
  layout, in µs. Field 7 is **`YYYYMMDDhhmm`**, local time, without the
  X5's seconds, so the recording time comes from the name the file holds
  (*Streams*), then the one it has, which carry them. **Field 195 is the
  capture rate and field 196 the stored (playback) rate**, each a fraction
  (30000 / 1001, 100000 / 1000, ...); they differ only in slow motion
  (*Slow motion and timelapse*). Field 20 is the stored rate, rounded (30,
  100); field 10 the recording's length in whole seconds, field 93 in ms
  (30730 on the 4K 100 clip, whose streams last 30710: the proxy's
  length) -- capture time, not video time, in slow motion; field 9 the
  file's size
  before the trailer (above); field 25 the sensor readout, ~21.2 ms at 8K,
  ~12.3 ms at 5.2K, 6.3 ms at 4K 100; **field 132 the codec**, 1 H.264, 2
  H.265; field 135 the target bitrate (*Streams*). ⚠️ **Field 153 looks
  like the recording mode**: 0 on every 8K and 4K 100 clip, 3 on every
  5.2K one (both codecs), 4 in 4K Slow Motion, 2 in the timelapse; 1 on
  the 55 MP and 14 MP photos, 5 on one 55 MP photo (`_032`, ❓ which
  photo mode). Field 26.1 is 0 on the normal clips, 17 in slow motion, 2
  in the timelapse (the X5's `VideoTimelapse`, X5 §3.5), 3 on photos.
  Fields 51 (1) and 64 (2) are set, meaning ❓. The serial is in field 1 as on the X5.
- ⚠️ The calibration's extrinsics are yaw / pitch / roll ≈ (−177.5, −89.95,
  90.4) and (−179.4, −89.9, 89.4): pitch −90° puts yaw and roll about the
  same axis, so the order they compose in matters (it doesn't on the X5).
  Pitch, then yaw, then roll (X5 §5.3) leaves the lens axes opposite to
  0.2°, and the per-clip seam fit converges to 0.02° on all three clips
  with small corrections (lens 1 pitch +0.14 to +0.24°, roll +0.40 to
  +0.42°, centre −0.06 to −0.08 %, radius −0.17 to −0.20 %). Before the
  fit the lenses are 0.24-0.53° apart at the seam (X5: ~0.17°). The app's
  per-clip measurement gives the same on all three clips, over each whole
  clip (0.47-0.52° -> 0.02°). ✅ **The same at every resolution**: on the
  second set the lenses are 0.40-0.49° apart before the fit in all nine
  modes, and the fit finds the same correction at 8K 30, 5.2K 60 and 4K
  100 (lens 1 pitch +0.23 to +0.27°, roll +0.43 to +0.54°, centre −0.07 to
  −0.09 %, radius −0.10 to −0.15 %), ending at 0.14-0.15°: these clips fly
  low, a few metres over a field and trees, so parallax is left.
- ✅ **Studio's stitch puts lens 1 where the per-clip fit does, not where
  the file alone does** (measured 2026-11-03, `stitch_bench` on `_021`
  4-8 s against Studio's unstabilized equirect, *Modes and sample clips*).
  The export lines up with our sphere at `refrot=0.361,-2.764,89.940`
  (Studio puts the lens axes on the equator; from 1298 matched features at
  6 s, median 0.036°, and the bench's own fit within 0.1°) and
  `refstart=0`. Against it, our stitch from the file's calibration alone
  is 0.16° (median) / 0.57° (p95) off in the seam band, band PSNR 24.0
  dB; with the per-clip seam correction (lens 1 rotation −0.002 / +0.221
  / +0.430°, centre −0.07 %, radius −0.15 %) 0.14 / 0.23°, 25.5 dB. The
  difference is a **tilt of lens 1 by ~0.48°** against our reading of
  `offset_v3`, seen also 10-30° from lens 1's axis, out of reach of
  Studio's AI Stitching at the seam; lens 0 sits where the file puts it
  (radial within 0.01°), so Studio doesn't apply the fit's radius scale
  to it. **The fit's lens 1 rotation alone matches Studio best**, the same
  on 4-8, 30-34 and 60-64 s (band 0.10 / 0.34 / 0.30° median, p95 0.27 /
  0.66 / 0.58°, against 0.16 / 0.37 / 0.34° and 0.57 / 0.77 / 0.77° from
  the file alone); adding its centre or radius terms makes it worse. So
  Studio's lens 1 holds one pose through the clip: the file's, turned by
  that rotation. No other order of the angles gives it (the closest,
  `Rx Rz Ry`, still leaves 0.27°). ❓ Where Studio's tilt comes from.
- ✅ **The app's new stitcher corrects the file's calibration by a fixed
  amount for the model** (`insv::InsvModel::lensCorrection`, as offsets
  from the file's values in the per-clip seam fit's terms, measured
  2026-11-03): lens 1 turned (+0.006, +0.238, +0.468)° (yaw / pitch / roll
  on top of the file's angles), its centre moved (−0.0749, +0.0016) % of
  the lens picture's width, both lenses' radius −0.1286 %. Each is the
  median over all 17 clips of the per-clip seam fit (yaw −0.002 to
  +0.011; pitch 0.10 to 0.30, 0.59 on the landing `_025`; roll 0.41 to
  0.54, 0.76 / 0.88 on `_027` / `_024`, −0.97 on `_025`; centre −0.071 to
  −0.084 % and −0.006 to +0.009 %; radius −0.08 to −0.21 %). The lenses
  are then 0.14° apart at the seam on average (17 clips, 8 frames each;
  0.42° with the file's calibration alone, 0.30° with lens 1's turn
  only), and the seam is the sharpest of every correction tried (band
  sharpness over beside, on `_010`, `_012`, `_015` and three stretches of
  `_021`; tied on `_024`). A fit of all six numbers to every clip at once
  scores 0.10° but makes the seam less sharp than the median: the offset
  it minimises leaves out any shift the way parallax goes, and a larger
  radius change on both lenses turns the far content's error into that
  direction. Against Studio's `_021` export the median correction puts
  both lenses ~0.1° further out at 50-80° from their axes than Studio,
  which keeps the file's radius (lens 1's turn alone matches Studio
  closer: band 0.09 / 0.33 / 0.29° median against 0.13 / 0.35 / 0.33°);
  from the seam alone, which lens's radius is off can't be told -- a chart
  calibration of an A1 would. ⚠️ **One unit measured**: if the offsets
  are this drone's own calibration error rather than the model's, another
  A1 needs other values; a clip from a second A1 would tell.
- ✅ The lenses are **71 mm apart** (lens 1 `tz` −0.0711; X5: 32 mm), lens 0
  in front along its own axis as on the X5: the depth-aware seam lines up
  houses, poles and wires along the horizon when the drone flies low
  (`_011` at 1 s, confidence 0.89), and with the sign flipped
  (`insv_stitch --baseline -0.0711`) they double again.
- ✅ **A low sun on the seam** (2026-10-30, `_021` at 60-70.4 s, flying
  high toward a setting sun): the up lens sees the sun at its rim with its
  own glare and rays, the down lens a weaker, different flare. Matched as
  plain grey values, the two lenses agree badly at the true (far) distance
  there (NCC 0.25-0.45, ~0.95 elsewhere on the seam), and the glare's
  smooth gradient lines up with itself at any shift, so the depth-aware
  seam took 0.3-0.4 m and bent the town round the sun; at the 71 mm
  baseline 0.3 m is a 13° shift (X5: 6°). The seam's match now takes each
  lens's brightness plane out first (`insv::SeamPatchScore`), and those
  bins stay far on all the frames checked. The table also stays within the X5's shift
  range (−0.9 to +5.9°), which at 71 mm ends at ~0.7 m, and a match has to
  be clearly better than any other shift to count (the uniqueness term,
  `insv::SeamDepthTuning::uniqueLo` / `uniqueHi`):
  a frame solved from itself after a seek (`_018` at 22.36 s) took scattered
  matches at 0.3-0.5 m and pulled the far town into a loop.
- ✅ **The lenses' colour** (measured 2026-10-31 from the picture, seam
  cells both lenses see alike, unclipped, over each clip): the exposure
  record (type 4) holds **one shutter time per frame**, not one per lens,
  and there is no type 12: the lenses expose together, and the file
  doesn't say how they differ. Measured, the difference is **fixed within a
  clip** (±1.5-3 % from frame to frame outside flare; on `_010` it doesn't
  follow the shutter, 0.84-1.30 ms, within ±2 %) but **differs between
  clips**: the down lens (lens 0) against the up one, blue −1.2 % on
  `_010`, −6 to −8 % on the second set (`_021` R −0.9 %, G −2.4 %, B
  −6.2 %). Across the overlap it changes by +0.3 to +0.5 % per degree
  towards lens 0: lens 0 falls off towards its rim more than lens 1, most
  in blue. With the sun at the up lens's rim (`_021` 23-33 s, 57-70 s)
  that lens's veiling flare adds light (lens 1 ≈ 0.56-0.87 × lens 0 + 26-90
  levels on the sun's side): such frames show as a wide spread of the
  ratio along the seam, and the app's per-clip measurement
  (`insv::FitLensColour`) leaves them out. ⚠️ **Not the same all round the
  seam** within a frame: on `_020` at 3-5 s (flying low, the sun near the
  horizon) the lenses agree within 1-5 % on half the seam circle, while on
  the ~135° facing the sun the down lens is 15-45 % darker (most in blue);
  and away from the sun the per-clip value (G −2.4 %) is ~2 % off on
  stretches where the lenses agree. The stitch therefore also matches them
  per stretch of the seam, per frame (`insv::SeamBlend::local`).
  ⚠️ **Veiling light is added light, not a gain** (measured 2026-10-31 on
  `_015` at 23.9 s, the sun just above the horizon at the up lens's side):
  on the seam stretch under the sun the up lens sees shadowed grass at G
  107 against the down lens's 58, and the sky next to it a little brighter
  -- in linear light (levels^2.2) both about +0.10, a ratio of 2.6 on the
  grass and 1.7 on the sky. No gain matches both; taking the added light
  out does (`insv::LensVeilPerBin`, `SeamBlend::veil`: up to 0.25 linear
  there). On the same frame the sky's blue is near clipping (245-250) in
  both lenses while red and green agree within 1-2 levels: with whole cells
  left out for one clipped colour, that stretch had no data and was given
  its neighbour's correction (a 14 % step). The lens colour is measured per
  colour since (`insv::kLensColourMethod` 2). ⚠️ **The difference depends
  on the content** (measured 2026-10-31 on `_020` at 2.17 s, turning): in
  the sky just above the trees the lenses agree within 1-2 levels, in the
  trees' shadows below lens 1 is 8-12 levels higher in blue -- a small
  added offset, under what counts as veiling light. Matched on all the
  overlap's rows, the sky split by 4-8 % in green on a line; the stitch
  matches each stretch on the rows where the lenses meet, and follows the
  picture within ~40 ms, as the scene slides along the seam when the drone
  turns.
- ✅ **How the lenses sit in the picture** (`InsvModel::mountDeg`, the
  stitch's output turn): not in the file -- the calibration places the
  lenses relative to each other, as on the X5, where lens 0 faces forward.
  Stitched the X5's way, the A1's lens axes lie on the horizon. Turned so
  lens 0 looks straight down and the picture's forward is the drone's
  nose: yaw −90°, pitch 90°, roll 0 (the X5's: 180, 0, 0). The nose found
  from the horizon on 2026-10-29: a drone flying fast tilts nose down, so
  the horizon in the stitched picture is highest toward the nose. A fitted
  sinusoid on six frames of clip `_010` at a steady 15.7 m/s (62-72 s,
  tilt 16-19°) puts the high point at −86° ± 6° from lens 0's side; taken
  as −90°, the body square to the lens frame. It puts the trailer's
  thumbnail (type 2) of `_011` at the picture's centre too; `_012`'s
  thumbnail looks elsewhere, so the thumbnail is a view, not the nose.
  **Measured from the scene** (2026-11-05, `_021`): the direction of
  travel in the stitched picture -- the essential matrix of feature
  matches between two frames 10 apart, on the sphere's bearings -- against
  record 37's velocity taken into the picture through field 69, the 9.7°
  tilt and the IMU axes below. On the five pairs with little rotation
  (30.5, 50, 65-67 s; 12-14 m/s) they agree to −0.16° in azimuth (−0.87
  to +0.81°) and +0.19° in elevation (−0.16 to +0.73°): the nose sits at
  the picture's yaw 0, and the elevation checks the tilt without the
  attitude-against-gyro fit it came from. Insta360 Studio's 360 export of
  the clip without FlowState isn't turned to the nose: it keeps its lens
  frame, the lens axes on the horizon, about 2.65° about lens 0's axis from
  ours (`360NoStab.mp4` of the contributor's `PanoExport`).
- ✅ **IMU axes `-x,y,-z`** (`InsvModel::imuAxes`): sphere X ← −raw x,
  Y ← raw y, Z ← −raw z, in the sphere the A1's mount gives. Measured
  2026-10-29 as on the X5 (X5 §6.3) and the ONE X2: four unstabilized
  horizon views (yaw 0 / 90 / 180 / 270°, 90° diagonal field of view) of
  `_010`, the camera rotation per frame interval from tracked features
  (rotation-only Kabsch fit), against the gyro integrated over the same
  interval. On 40-60 s (turns at 100-150 m): 1.3° from the free fit, gain
  1.01 / 0.97 / 0.99, every view picks it (1.7-2.7°), and the rotation left
  per frame drops from 1.20° to 0.074°; on 10-40 s the same map, 2.7°. The
  runner-up is 90° away. Raw +y is also where the accelerometer puts "up"
  in a hover (0.92 g of it).
- ✅ **Thumbnail, record type 2**, in a layout of its own: a 64-byte
  header -- `u32 0`, `u32 64` (the header's size), `u32` the picture's
  size in bytes, then zeros but for width (`u32` at byte 24), height (28)
  and row stride (32) -- then a **flat view, not an equirect**, NV12:
  **256×192** in the clips, **768×768** in the `.prx` proxy, the stride
  equal to the width in both (the X5's: a 40-byte header and a 1280×640
  equirect, X5 §4.3). The view looks ahead and down at the ground, a wide
  lens look; on `_011` the proxy's picture shows the same view as the
  clip's, cut square. Checked 2026-10-29 on all three clips and their
  proxies. **Full range** like the video: 2-14% of the clips' pixels are
  above 235, a sky in the video's lens 1 likewise (10%), and the pictures
  look right decoded so. The matrix is ⚠️ BT.709, the video's, not
  measured: a view fitted from the stitched first frame matched no better
  under BT.601 or BT.709. The app shows the picture on the A1's cards
  (Media tab, project library), cut to the card's shape.
- ✅ **GPS, record type 7**, in the X5's layout (X5 §8): a fix every
  **1.6 s** on all twelve clips (the X5 with the GPS remote: once a second),
  one record per fix, from the first one the drone has after recording
  starts. Field 98 (X5 §5.1), which on the X5 gives the first frame's Unix
  time, is absent, and nothing else in the file ties the GPS clock to the
  video: field 36 is the first fix's own Unix time (to the ms on all
  three), the MP4's `creation_time` is in whole seconds, and no other
  record holds a Unix time.
- ✅ **The GPS lined up with the video by its speed** (`AlignGpsBySpeed`,
  `Gps.h`): the fixes' speed against record 37's horizontal speed, timed
  in video time by field 24, over every shift; the best to the ms. On
  `_010` / `_011` / `_012` the first fix is **1.129 / 0.911 / 0.526 s**
  into the video, matched to 0.20 / 0.06 / 0.08 m/s RMS, 0.8-2.0 m/s a
  second either way. A check that doesn't use the fit's own clip: the
  three put the drone's clock (field 24) at the same offset from Unix time
  to within 31 ms; the nine clips of the second set, one per mode, 24 to
  100 fps, 15-70 s at 0.1-15 m/s, to within 11 ms. A shift is taken only when it is clear: at least 5
  fixes over the attitude track, their speeds spread by 0.5 m/s or more,
  matched to 1 m/s RMS or better, and every shift a second or more away
  fitting at least twice as badly (+0.1 m/s). A hover, or a clip too
  short for 5 fixes (8 s), stays without GPS in titles and gauges, and the
  log says why.
- ✅ **Sync**: the X5's formula (field 24 + field 28, X5 §7.1) holds; the
  app's per-clip fine-tune finds +0.9 to +1.2 ms on all three clips, and
  the image fit above agrees within ~1 ms. Field 24 is one of the exposure
  record's timestamps, as on the X5 (all 13 clips checked).
- ✅ **The centre row half the exposure before the frame's time**, as on
  the X5 (X5 §7.1; measured 2026-11-05): the per-clip sync measurement on
  three 4 s windows of 16 clips (46 windows, every mode, exposure 0.4-5 ms,
  readout 6.3-21.3 ms) falls by 0.484 ms per ms of exposure, 0.10 ms RMS
  left (0.78 ms with one constant), at the X5's −0.5 ms; the readout time
  adds nothing.
- ✅ **Attitude, record type 37** (the walker's id 0x2500): the flight
  controller's orientation, 50 Hz, 36 bytes each: `u64` µs on the IMU's
  clock (4-8 ms behind the gyro), a unit quaternion as x, y, z, w (4 ×
  f32), body to world -- body x the nose, y right, z down; world north,
  east, down -- then the velocity north, east, down in m/s (3 × f32; its
  horizontal speed is the GPS speed). In fast flight the body pitches
  −25° to −28°. Measured 2026-10-29 on all three clips by matching the
  attitude's rotation per 20 ms step against the gyro integrated over the
  same step: body ← IMU is **field 69**'s rotation, transposed -- (w, x,
  y, z) = (0.5, 0.5, −0.5, 0.5), an exact axis permutation -- then a
  **9.5-9.9° pitch up** about the body's right axis, the camera tilted in
  the airframe (26° body pitch − 9.7° = the 17° the camera's horizon
  tilts). 0.09-0.14° per step is left. The tilt isn't in the file; the
  app takes 9.7° (`InsvModel::attitudeTiltDeg`, one drone measured).
  Insta360 Studio's FlowState export of `_021` (2026-11-05, 13 frames,
  each lined up with our stitch by feature matches) holds the attitude's
  up within 0.3° in steady flight and moves up to 0.65° off it, in pitch,
  in turns of 10-20°/s: no offset fixed in the airframe, so nothing that
  would point to a different tilt.
- ✅ **The accelerometer reads the drone's acceleration with gravity.** In
  steady flight it points up however the drone is tilted (thrust and drag
  balance gravity: `_010` 62-64 s at 15.6 m/s, 0.2-1.3° from the
  attitude's up), but the drone speeds up, brakes and turns most of the
  time, which moves it 4-35° off up (2 s means, `_010`). The attitude's
  up plus record 37's velocity, differentiated, predicts it to ~1° (0.3-4°
  per 2 s), which checks the attitude and the tilt above. Leveled by the
  accelerometer, Horizon lock's up was up to 15° (pitch) and 9° (roll)
  off per 10 s on `_010`, 5-8° on `_011`, under 1° on `_012`; leveled by
  the attitude, 0.2° or less on all three (`residual_stab --diagnose`,
  block [6]). The app levels by the attitude (Horizon lock, Direction
  lock, Lean follow's auto-level).
- ✅ **The attitude's heading doesn't drift, and its north is its own.**
  Its yaw matches its own velocity's course in flight (median 0.0°, 10-90%
  −1.8° to +2.5° over 5 m/s, `_010`): the nose points where the drone
  flies. Against the GPS course (which matches the course from the GPS
  positions, median 0.1°) it is a steady **22.5-23.9° off** on all three
  clips, minutes apart -- so record 37's north (and its velocity's) is the
  flight controller's own, not true north, and not magnetic north either
  (the declination there is ~13° the other way). For holding a direction
  only its steadiness matters. Against it the gyro alone, integrated,
  turns 2-5°/min (`_011` 2.2, `_012` 3.6, `_010` 4.8), and the
  stabilizer's levelled track on `_010` 17.7° over the 87 s (its bias fit
  can't see the part about up). The app holds the levelled track's
  heading to the attitude's north (`ImuTrack::orientation`): `_010` within
  ±0.5° at 11 s steps, 1.6° peak to peak with fast turns' transients (the
  attitude at 50 Hz, 4-8 ms late), so Direction lock doesn't wander.
- ⚠️ **Other orientation records** (layouts from the bytes, meaning
  inferred, not used): type 14 has one 36-byte entry per video frame with a
  unit quaternion in it; type 56 holds the same orientation in another
  layout (its first quaternion is type 14's, sign flipped). ❓ Field 91 (a
  unit quaternion, none of the attitude, the IMU mount or their products).

## Slow motion and timelapse

✅ One clip of each (2026-11-01, measured 2026-11-02). In both, **the video's
time is not the drone's clock**: the motion and exposure records run in
real time while the video plays slower or faster. The app turns video
time into the drone's clock by a **capture scale**, seconds of the clock
per second of video (`insv::CaptureScale`): field 196 over field 195 in
slow motion (0.2997), a timelapse's frame interval times the stored rate
(60), from its frames' own times (type 6) where it has them, else from
field 30. Sync, stabilization (its smoothing windows stay in video time),
the GPS and the motion overlays all go through it (2026-11-04).

- **4K Slow Motion** (`_028`): two 1920² HEVC streams **stored at 29.97
  fps** (2997/100), 2773 frames, 92.5 s of video. Captured at 100: field
  195 is 100000 / 1000, field 196 29970 / 1000; the exposure record has
  one entry every 10.0 ms (2823), the IMU spans 28.2 s, field 93 is 27740
  ms, and the readout (field 25, 6.33 ms) is 4K 100's. So the file is
  tagged at the **playback rate** and plays 3.34× slowed as it stands.
  Records as in a normal clip (types 1-4, 7, 9, 11, 14, 23, 32, 33, 37,
  38, 56); a proxy as usual, also at 29.97. With the scale, the file's
  sync holds (the image's yaw left after Horizon lock is smallest at the
  file's offset, 0.053°/frame, against 0.114 unstabilized; ±20 ms both
  worse) and the frame clock fits to +0.1 ppm; the GPS, lined up by its
  speed, spans 3.0-88.4 s of the video (before: 0.9-26.5 s). ❓ How a
  trimmed slow-motion file's time map (record 0x8000) counts: taken as
  video time, untested.
- **Timelapse** (`_029`, 8K H.265): two 3840² streams at 29.97 fps, 150
  frames (5.0 s) over ~299 s of flight: **one frame every 2 s**. As on
  the X5 (X5 §3.5), field 26.1 is 2, field 30 is 2000 and field 59 is
  true (the interval in ms); field 133 is 2000 too. Record **type 6** holds
  one `u64` timestamp per frame (150; the X5 writes one more), the first
  one field 24's, **2.002 s apart** (2001.92-2002.08 ms: 60 frames of the
  sensor's 29.97), so the scale is 60.0, not the 59.94 field 30 gives.
  Unlike the
  X5's, the A1's timelapse **keeps the IMU** (type 3, ~1 kHz over the
  whole 299 s) and the attitude (37); the exposure record runs at 29.97
  Hz over the whole time (8956 entries), GPS every 1.6 s. **No proxy.**
  With the scale, Horizon lock keeps it level (pitch left in the image
  0.19°/frame against 0.70 unstabilized). Its GPS doesn't line up: the
  drone hovered (0-0.17 m/s), so there's no speed to match.

## Photos

✅ Two 55 MP single shots (2026-10-29, the same drone), then two more and
a 14 MP shot (2026-11-01):

- **14 MP** (`_031`): 5248×2624, the two fisheyes side by side at 2624²,
  otherwise as below.
- **DNG** (AEB, `AEB_<date>_<time>_<n>.dng`, three files, one per
  bracket, consecutive numbers): uncompressed 16-bit raw, RGGB, 10496×5248
  -- both fisheyes side by side, as the `.insp` -- ~115 MB each, model
  `Antigravity A1`. The three shutter times are 1/4722, 1/2258, 1/1129 s:
  1 EV apart, ISO 100-105. ❓ Whether they hold the calibration (not
  checked).

- An **`.insp` is a JPEG**, 10496×5248, the two fisheyes side by side
  (5248² each, lens 0 left as in the video), with a small Exif block:
  maker `Yingling Innovations Pte. Ltd.`, model `Antigravity A1`,
  exposure, ISO, GPS position and altitude; **no date** and no Software
  tag (the X5 writes both).
- After the JPEG, **the same `inst` trailer** as the video's: record 1
  with the same calibration and fields (field 26.1 is 3, 0 on normal videos;
  field 91 is all zeros; no field 36, 93, 132 or 135), the IMU (record 3, 2 kB), and records
  9, 11, 32, 38 and 56; no GPS record (the position is in the Exif) and no
  attitude (record 37). Field 9 here is 2329 bytes more than the JPEG's
  size on both photos, ❓ why.
- Unlike the video's, the photo's trailer also has the X5's six-byte
  header after each record (X5 §4.2), besides the Offsets table.
- **Thumbnail, record type 2**, in the X5's 40-byte header layout --
  `u32 1`, `u32` the record's size, `u32 1`, `u32 0`, width, height -- then
  a 256×192 NV12 flat view, the same kind of picture as the video's.

The app doesn't open 360 photos yet (roadmap, *360 photos*); the trailer
holds all the stitch needs.

## Modes and sample clips

All the A1's modes 📖 (Antigravity's spec table as retailers and reviews
reprint it, and the spring 2026 update for timelapse; Sources). Our clips,
from one contributor and one drone (firmware `10.0.397.3_5.5`): three 8K
H.265 flights (2026-10-28), and a set of nine H.264 clips, one per mode,
plus two photos (2026-10-29), flown low over a field. The second set came
renamed by mode but is otherwise straight from the drone (field 9,
*Streams*); the videos have their names back (*Streams*): `_013` 8K 25,
`_014` 8K 24, `_015` 5.2K 60, `_016` 5.2K 50, `_017` 5.2K 30, `_018` 5.2K
25, `_019` 5.2K 24, `_020` 4K 100, `_021` 8K 30.
The photos keep the contributor's names. A third set
(2026-11-01), with the drone's own names, over a park: `_024` 8K 30
H.264, take-off from a pad, then a hover with turns (43 s); `_025` the
same, a low hover and landing (10 s); `_026` its proxy only (67 s, on the
pad); `_027` 5.2K 60 H.265 (32 s); `_028` 4K Slow Motion; `_029` a
timelapse; photos `_030` / `_032` 55 MP, `_031` 14 MP; `_033`-`_035`
AEB DNGs. **All our files come from the microSD card.**

**Studio references** for `_021` (8K 30, H.264): Antigravity Studio's
exports as 360 equirect, 7680×3840 H.265, ~200 Mb/s, at **exactly 30
fps** (2113 frames; the clip has 2111 at 29.97), so frames are matched by
time, not by number. Unstabilized: AI Stitching, FlowState off,
Chromatic Calibration off, no adjustments -- the reference for the
stitch's geometry, seam and colour. Stabilized: the same with FlowState
on, level. Each has a silent AAC track. The unstabilized one is still in
the drone's body frame and lines up with the clip from its first frame
(*Trailer* above has the rotation). Studio's earlier flat
3840×2160 exports of the same take (AI Stitching and Chromatic
Calibration on) show the raw body frame without FlowState (horizon on
end).
The status words are the X5's (X5 §3.4).

| Mode | Spec | Files | Our clips | Status |
|---|---|---|---|---|
| 360 Video 8K | 7680×3840, 30 / 25 / 24 | ✅ one `.insv` with both lenses (two 3840² streams), and a `PRX_….prx` proxy | 3 at 29.97 fps, H.265; 5 at 29.97 / 25 / 24, H.264 (with a take-off and a landing); standard colour | experimental: opens, stitches, stabilizes and exports; GPS lined up by its speed |
| 360 Video 5.2K | 5248×2624, 60 / 50 / 30 / 25 / 24 | ✅ as above, two 2624² streams | 5, one at each rate, H.264; 1 at 60, H.265 | experimental, as 8K: plays in real time (60 fps: 4.0 ms a frame on an RTX 5070), Horizon lock level within 0.2°, sync within 5 ms, exports (5.2K 60, `_015`) |
| 360 Video 4K | 3840×1920, 100 / 30 / 25 / 24 | ✅ as above, two 1920² streams; 100 fps stored at 100 | 1 at 100 fps, H.264 | as 5.2K: plays at 100 fps (3.3 ms a frame), level within 0.5°, exports (`_020`); wanted: 30 / 25 / 24 |
| 4K Slow Motion | 3840×1920, 30 / 25 / 24 | ✅ as 4K, stored at 29.97, captured at 100 (field 195; *Slow motion and timelapse*) | 1 at 29.97, H.265 | experimental: plays as stored (3.34× slowed, as the drone means it); sync, stabilization and GPS on the capture time (by the tools); Media information shows *Slow motion* |
| H.264 encoding | up to 170 Mb/s, as H.265 | ✅ as above, H.264 High; field 132 = 1 | 11 | as its mode in H.265 |
| Timelapse | added by the spring 2026 update; ❓ other sizes and intervals | ✅ as 8K, one frame every 2 s, IMU kept, no proxy (*Slow motion and timelapse*) | 1 at 8K, 2 s, H.265 (a hover) | experimental: stabilization on the flight time (by the tools); Media information shows *Timelapse*; wanted, low: another interval, one in flight (for the GPS) |
| 360 Photo: Standard, HDR, Burst, AEB | 55 MP 10496×5248, 14 MP 5248×2624 | ✅ `.insp`, ✅ `.dng` per AEB bracket (*Photos*) | 4 at 55 MP, 1 at 14 MP, 1 AEB set (3 DNGs) | not supported (no photos in the app yet); wanted, low: HDR |
| Internal storage (20 GB) vs microSD | | ✅ microSD; internal ❓ | all from microSD | wanted, low: a clip from the internal storage |
| Audio | not in the spec table | ✅ no audio track in our clips | 17 | done: opens and exports as picture only |
| Drone in the picture (props, arms, landing gear) | | | 3 in flight; `_024` take-off, `_025` landing | done in flight: a part at lens 0's rim only, outside the stitched picture; on the ground the landing legs are in lens 0 (*Streams*), ❓ in the stitch |
| Replaceable lenses | | | none | wanted, low: whether the calibration in the file follows a lens swap |
| IMU axes | | | `_010` (flight turns) | done (`-x,y,-z`) |

Cinematic, Normal and Sport are flight modes, not recording modes; they
change how the drone moves, which matters only for the stabilization check.

Still wanted, 10–30 s each, straight from the card with the whole folder
and **with the drone's own file names**, as in "Sample clips wanted"
([`README.md`](README.md#sample-clips-wanted)):

1. The `.insv` of the third set's `_026` (only its proxy came).
2. 4K at 30, 25 or 24 (not Slow Motion).
3. An HDR photo, low.
4. A clip recorded to the internal storage, low.

## Sources

- Shotkit, Antigravity A1 review (specs, formats):
  <https://shotkit.com/antigravity-a1-review/>
- Space.com, Antigravity A1 review (sensors, weight):
  <https://space.com/technology/antigravity-a1-drone-review>
- Antigravity's spec table (video and photo modes, codecs, storage), as
  reprinted by apollomaniacs:
  <https://www.apollomaniacs.com/ipod/howto_ar_drone_basic_antigravity_a1.htm>
- No Film School, the spring 2026 update (adds timelapse):
  <https://nofilmschool.com/antigravity-a1-drone-spring-update>
- Gyroflow telemetry-parser, `src/insta360/mod.rs` (the slotted,
  descriptor-less layout): <https://github.com/AdrianEddy/telemetry-parser>
