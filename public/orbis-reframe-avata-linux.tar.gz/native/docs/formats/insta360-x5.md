# Insta360 X5 file format — `.insv` / `.lrv` reference

Everything this project knows about the Insta360 X5's recorded video files: the
MP4 container, the video/audio streams, the proprietary `inst` trailer, the
telemetry in it (gyro, accelerometer, exposure, GPS), and the lens calibration.
It collects the findings from `src/insv/`, the spikes/tools, the project's
development notes, a direct re-inspection of the sample footage, and a
cross-check against the external sources in §13 (2026-09-24).

The other cameras' formats are in their own files next to this one, indexed
in [`README.md`](README.md); they describe how each differs from this one.

**Confidence markers** used below:
- ✅ **verified**: parsed by our code and cross-checked (ExifTool byte-for-byte,
  ffprobe, several clips agreeing, and/or an independent implementation)
- 📖 **documented externally**: stated by an independent source (§13) and
  consistent with our files, but not yet exercised by our code
- ⚠️ **inferred**: strong evidence, but not validated end to end
- ❓ **unknown**

The main external sources are Gyroflow's **telemetry-parser**
(`src/insta360/`), which has a full reader for this trailer including
**the protobuf schema of the metadata record**; **ExifTool**
(`QuickTimeStream.pl`, `ProcessInsta360`); BenjaminHenriksson's
**insv-stitch**; the Insta360 X5 online manual; and the TDK ICM-40609-D
datasheet. We use only interoperability documentation and our own files. No
Insta360 SDK disassembly was used, and none should be.

Reference clips (`sample_footage/`, gitignored), all from one camera:
firmware `v1.5.6_build1` for the 2025 clips, `v1.11.10_build1` for the 2026
ones (one clip `v1.11.6_build1`). Which modes they cover is in §3.4.

| clip | length | notes |
|---|---|---|
| `Old/VID_20250904_193105_00_002.insv` (+ `LRV_…_01_002.lrv`) | 42.8 s | stick mount, GPS, main test clip |
| `Old/VID_20250828_192900_00_001.insv` | ~9.5 min | curves clip, **two AAC streams** (camera mic + Mic Air), no GPS |
| `Old/VID_20250828_201257_00_006.insv` | ~10.7 min | 15 GB, GPS for the first ~48 s only (§8), different rolling-shutter value |
| `Split card original/VID_20250927_144221_00_019.insv` / `_020` (+ `.lrv`) | 1799.8 s + 445.6 s | one 37-minute recording split into two files, straight from the card, handlebar mount |
| `Analysis/VID_20250927_144221_00_019-trim.insv` / `_020-trim` | 30 min + 7.4 min | the same recording re-written (trimmed ~2 s at each end) by Insta360 software |
| `Modes/VID_20260927_*_00_001…005.insv` (+ `.lrv`) | ~12 s each | one clip per mode, camera still (§3.3) |
| `ilog/VID_20261018_185907_00_006.insv` | 11 s | 5.7K 30 I-Log, indoor |
| `Demo/…/VID_20260815_*.insv` (+ `.lrv`), `IMG_20260815_*.insp` | 18 clips, 77 photos | a day's ride, 8K 30: 12 video clips and 6 timelapses (`_078`, `_079`, `_088`, `_089`, `_091`, `_095`, §3.5); two Interval series of 72 MP 360 photos with GPS (§3.6) |
| `Demo/…/card/` | | that day's card files other than the media: `MISC/Camera01/*.pb` sidecars of every clip and proxy (§9), `MISC/RECRST_IDX*.SUCC`, `DCIM/fileinfo_list.list`, `DCIM/.editinfo_list.list` |
| `Modes/VID_20250905_185106_00_018.insv` (+ `.lrv`) | 24 s (726 frames) | timelapse at firmware v1.5.6, 8K, 2 s interval, on the move (§3.5) |
| `Modes/VID_20260801_172932_00_024.insv` (+ `.lrv`) | 44 s | 8K 30 riding, firmware v1.11.6 |
| `Marks/VID_20261110_220445_00_010.insv` (+ `.lrv`, `.insv.pb`) | 24.5 s | 8K 30 with **two highlight marks** set while recording (§4.3) |

---

## 1. Files on the card

```
DCIM/Camera01/VID_20250904_193105_00_002.insv   full-res dual-fisheye master
DCIM/Camera01/LRV_20250904_193105_01_002.lrv    low-res proxy of the same take
MISC/Camera01/VID_20250904_193105_00_002.insv.pb   protobuf sidecar (§9), one per file
MISC/Camera01/LRV_20250904_193105_01_002.lrv.pb
```

- **Name pattern** 📖 ✅ (Insta360 X5 manual): *prefix + date/time +
  lens-direction digit + master/proxy digit + sequence number*.
  - Lens-direction digit: `0` = back lens (away from the screen) and `1` =
    screen-side lens. Master/proxy digit: `0` = master and `1` = proxy.
  - So `_00_` is the master and `_01_` the proxy. `_10_`/`_11_` exist for
    single-lens and photo modes.
  - The X5 (like the X4) writes **one** `.insv` holding both lenses. The X3
    wrote one file per lens.
  - FreeFrame recordings use a `PRO_VID` prefix. Photos are `IMG_…` (`.insp`,
    `.jpg`, `.dng`).
  - The date/time is the recording start in camera-local time. `NNN` is the
    camera's running counter.
- **Long recordings are split** 📖 ✅: every **29 min 59 s**, per Insta360
  support (X5/X4/X3). The recording continues in a new file with the same
  date/time prefix and the next counter: our 37-minute take became `…_019`
  (1799.8 s, 42.5 GB) and `…_020` (445.6 s, 10.5 GB) on the card ✅. Files aren't limited to 4 GB; 13–42
  GB single files exist. The continuation's metadata names the take's first
  file (§5.1 field 26).
- The metadata also records the file's own card path
  (`/DCIM/Camera01/VID_….insv`). So does the MP4 header, which a rename
  doesn't touch either: `moov` / `udta`, in the `free` box after `AMBA`,
  `C:\DCIM\Camera01\VID_….insv` (byte ~1250 of the box; the `.lrv` holds
  its own `LRV_…` name), the same place as the Antigravity A1's. The app
  finds a renamed clip's `.lrv` by it, or by the clip's stem
  (`ride.insv`, `ride.lrv`) when the proxy's serial and field 24 are the
  clip's.

## 2. MP4 container

Both `.insv` and `.lrv` are plain ISO-BMFF / QuickTime files that FFmpeg opens
without special handling. After the standard boxes, the camera appends one
proprietary box. Top-level layout, as camera-written ✅:

```
ftyp  (28 B)   major_brand "avc1", compatible "avc1isom" (even for HEVC)
wide  (8 B)
mdat           all A/V samples
moov           track tables; udta holds a ThumbnailTIFF (~1.38 MB)
inst           Insta360 trailer, runs to EOF (12.5 MB on a 43 s clip)
```

- `moov` comes **after** `mdat`, so the file isn't "fast-start".
- A file re-written by Insta360 software (the `_020-trim` clip) had no `wide`
  box but still carried the trailer after `moov`. `ExtractRawTrailer()`
  therefore defines the trailer as "everything after `moov`".
- Container timescale is 30000. Track handlers are named `INS.HVC`, `INS.AVC`
  and `INS.AAC`.

## 3. Streams

### 3.1 `.insv` (master) ✅

| index | what | details |
|---|---|---|
| 0 | lens 0 fisheye video | HEVC Main, `hvc1`, **3840×3840**, 29.97 fps (30000/1001), ~94 Mb/s, no B-frames, GOP 60 (keyframe every 2 s) |
| 1 | lens 1 fisheye video | identical parameters to stream 0 |
| 2 | audio | AAC-LC, 48 kHz stereo, ~189 kb/s, `default` |
| 3 | *(only with an external mic)* | a second AAC-LC 48 kHz stereo stream, not `default` |

- **Pixel format** ✅: `yuvj420p` — 8-bit 4:2:0, **full range**
  (`color_range=pc`), BT.709 primaries/transfer/matrix. Treat it as full range:
  feeding it to swscale as limited range lifts the blacks and crushes the
  whites (a 3.5 dB PSNR fix, 2026-09-01). The GPU path
  samples it as NV12 through a `VkSamplerYcbcrConversion` (BT.709, ITU_FULL).
- Each lens stream is a single fisheye circle filling the square frame, with
  radius ~1920 stream px. The two streams are frame-locked.
- insv-stitch calls stream 0 the "front" lens and stream 1 the "back" lens.
  The Insta360 naming (§1) calls lens `0` the back lens. Which lens counts as
  "front" is only a convention.
- The "8K" figure (7680×3840) is 2 × 3840². No stream has that size.
- **Two audio streams** (`VID_20250828_192900`): the camera mic and an
  Insta360 Mic Air external mic. They're separate sources, not duplicates
  (−1.3 dB vs −8.9 dB peak). `InsvAudioDemux::open` takes the stream's
  ordinal among the audio streams; orbis-reframe puts each stream on its
  own track, *Camera mic* or *External mic*, by the order below
  (`Track::roleOfStream`). Nothing in the container (`handler_name` =
  `INS.AAC` on both) says which stream is which mic, but on this clip the
  **first (`default`)
  audio stream is the Mic Air** and the second is the camera's own mic --
  identified by the user by ear (the Mic Air was mounted by the exhaust),
  and it fits the data: stream 0 carries by far the clearest engine
  harmonics (`tools/audio_filter_bench`, 2026-09-29). The `.lrv` proxy carries
  the same two streams in the same order.
  0x101 field 61 (`audio_mode`) is 9 on these clips; its value table only
  goes up to 6. It's 9 on the single-mic clips too, so it doesn't flag the
  external mic. 0x101 fields 120 (track count) and 121 (one entry per
  track) do show a second track, but don't say which track is which mic
  (§5.1).

### 3.2 `.lrv` (proxy) ✅

| index | what | details |
|---|---|---|
| 0 | video | H.264 High, `avc1`, **1664×832**, 29.97 fps, ~4 Mb/s, B-frames, GOP 30 |
| 1 | audio | AAC-LC 48 kHz stereo |

- The LRV is **not stitched**. It holds both fisheyes side by side, each in an
  832×832 half. Our lens 0 (`.insv` stream 0) is the **right** half.
- Same full-range BT.709 `yuvj420p` as the master.
- It can be a frame or two shorter than the master: 1280 vs 1282 frames. Its
  own metadata gives its own frame count.
- **It carries the full trailer**: the same IMU, exposure, GPS and
  calibration, byte-identical in content. Stabilization or calibration work can
  run from the LRV alone.
- Per Insta360, the LRV is for "playback, preview, AI recognition, and scene
  analysis".
- Not used by the editor yet (proxy playback is planned).

### 3.3 Capture modes ✅

The camera app (firmware v1.11.10) offers these 360 video modes:

| Resolution | Frame rates | HDR |
|---|---|---|
| 8K | 30 / 25 / 24 | on or off (off adds an "AdaptiveTone" on/off) |
| 5.7K+ | 30 / 25 / 24 | on or off |
| 5.7K | 60 / 50 / 48 / 30 / 25 / 24 | available at every rate |
| 4K | 120 / 100, and 60 / 50 / 48 / 30 / 25 / 24 | not at 120 / 100; available at 60 and below |

Measured from `sample_footage/Modes/` (2026-09-27, one clip per mode):

| Clip | Mode | Per lens | fps | Mb/s per lens | GOP |
|---|---|---|---|---|---|
| `102745_00_001` | 8K HDR | 3840×3840 | 29.97 | ~94 | 60 (2 s) |
| `102815_00_002` | 8K, HDR off | 3840×3840 | 29.97 | ~94 | 60 (2 s) |
| `102900_00_003` | 5.7K 60 HDR | 2880×2880 | 59.94 | ~104 | 120 (2 s) |
| `102925_00_004` | 4K 120 | 1920×1920 | 119.88 | ~94 | 120 (1 s) |
| `104454_00_005` | 5.7K+ 30 HDR | 2880×2880 | 29.97 | ~63 | 60 (2 s) |
| `185907_00_006` (`sample_footage/ilog/`, 2026-10-18) | 5.7K 30 I-Log | 2880×2880 | 29.97 | ~56 | 60 (2 s) |

- **Every mode is 8-bit** HEVC Main, full-range BT.709 `yuvj420p`, no
  B-frames. HDR is tone-mapped in the camera; nothing in the stream says
  HDR, and the HDR / non-HDR 8K clips probe identically. 5.7K+ has the same stream shape as 5.7K; only the
  bitrate differs. No 10-bit path is
  needed for these modes.
- **I-Log** (5.7K 60 and below, Insta360's manual) ✅ on `185907_00_006`:
  **8-bit** HEVC Main too, and tagged exactly like a standard clip
  (full-range BT.709 `yuvj420p`, BT.709 transfer) -- the stream doesn't say
  log; the trailer does: metadata field 22 `gamma_mode` is `I_Log` instead
  of `standard` (§4; read by `ReadInsvTelemetry` as `gamma_mode`, shown
  in Media information, and the Colour section asks for the LUT). The
  rest of the trailer (calibration, IMU, exposure) has the same shape. The
  picture is flat as log should be: on a 1280×720 forward view, luma
  53–125 (average 97), mean saturation ~8.5 -- after the X5 LUT 28–99
  (66), saturation ~19; the back view 73–214 -> 39–213. No visible
  banding through the LUT at 8 bits (indoor, smooth ceiling).
  📖 Insta360's I-Log download page offers the X5 a LUT of its own, as the
  one for **8-bit** I-Log (the other, for newer cameras' 10-bit I-Log, is
  the X6 set, X6 document). The LUT is
  `X5_I-Log_To_Rec.709_V1.0.cube`: a 65³ 3D `.cube`, `TITLE "X5 ILog to
  Rec709 3DLUT v1.0"`, no `DOMAIN` lines (so input 0–1), I-Log to Rec.709.
  The app applies it per clip (Colour ▸ LUT); the curve itself isn't
  modelled.
- The trailer is identical in shape across modes: the same calibration
  strings (stated at the 10752×5376 reference size and scaled to the
  stream), the same lens profiles, ~1006 Hz IMU, and one exposure record per
  frame (so 2× / 4× as many at 60 / 120 fps). The native stitch works
  unchanged at 2880² and 1920².
- The `.lrv` is always 1664×832 at **29.97 fps**, even for 60 / 120 fps
  masters (377 LRV frames vs 754 master frames on the 60 fps clip). A proxy
  can't stand in for high-fps playback frame for frame.
- Decode load is similar across modes: ~0.88 / ~1.0 / ~0.88 Gpx/s for
  8K30 / 5.7K60 / 4K120, but the per-frame budget is 33 / 16.7 / 8.3 ms.
  Worst-case seek decodes up to a whole GOP: 60 frames at 8K, 120 at 5.7K60
  and 4K120.

### 3.4 Every mode, and our clips of it

All the modes the X5 offers 📖 (Insta360's shooting specs, §13), with the
clips we have (the reference clips at the top; every one H.265 at 29.97 / 59.94 / 119.88 fps) and
whether that is enough. **Enough** means the file is examined here and what
the app reads per mode (lens size, calibration, IMU, exposure timing, field
25) is checked on it; **one clip** means examined, but a second take would
check what one still clip can't (a moving camera for stabilization, another
frame rate); **wanted** means no clip yet.

| Mode | Spec | Files | Our clips | Status |
|---|---|---|---|---|
| 360 Video 8K, HDR on / off | 30 / 25 / 24 | `VID_…_00_` `.insv` + `.lrv` | 20 at 30 fps, still and moving, one split recording; firmware v1.5.6, v1.11.6, v1.11.10 | enough at 30; **25 / 24 wanted** |
| 360 Video 5.7K+ | 30 / 25 / 24 | as above | one still clip at 30 | one clip |
| 360 Video 5.7K | 60 / 50 / 48 / 30 / 25 / 24 | as above | one still clip at 60 | one clip; **50 / 48 / 24 wanted** |
| 360 Video 4K | 120 / 100 / 60 / 50 / 48 / 30 / 25 / 24 | as above | one still clip at 120 | one clip; **100 / 60 / 30 wanted** |
| I-Log (5.7K 60 and below) | | as above | one indoor clip, 5.7K 30 | one clip; **moving, at 60 wanted** |
| Filters Vivid / Flat | | as above | none | wanted, low: probably baked into the picture |
| H.264 encoding | | as above | none | **wanted**: every clip we have is H.265 |
| PureVideo | 8K / 5.7K / 4K, 30 / 25 / 24 | ❓ | none | **wanted** |
| InstaFrame 2.0 | 360 5.7K+ + flat 4K / 1080p, 30 / 25 / 24 | `.insv` (360) + `.mp4` (flat) | none | **wanted** |
| Timelapse | not in the spec table | as video, no audio, no IMU but the orientation per frame (§3.5) | six 8K clips at a 2 s interval, on the move (v1.11.10), one more at v1.5.6 with the same fields | enough to recognise, play and stabilize; **another interval and resolution wanted** (does the entries' spacing follow field 25?) |
| TimeShift | not in the spec table | ❓ | none | **wanted** |
| Bullet Time | not in the spec table | ❓ | none | **wanted** |
| Loop Recording, Dashcam | | ❓ | none | wanted, low |
| Split recording (over 29 min 59 s, §1) | | two `.insv` + two `.lrv` | one, as on the card and re-written by Insta360 software | enough: field 26 confirmed on the card original |
| Single-lens Video | 4K / 2.7K 60…24, 1080p 120…24 | `VID_….mp4` | none | **wanted** |
| Single-lens FreeFrame | 3840² 30…24, 2720² / 1920² 60…24 | `PRO_VID_….mp4` | none | **wanted** |
| Single-lens Me Mode | 4K 30…24, 2.7K / 1080p 120…24 | `.insv` (4K, and 50 fps and up), `.mp4` (2.7K / 1080p at 30 and below) | none | **wanted** |
| Single-lens PureVideo | | `.mp4` | none | wanted |
| 360 Photo, Interval | 72 MP, 18 MP | `IMG_…` `.insp` (a JPEG, §3.6), `.dng` | 77 Interval `.insp` at 72 MP, two series | enough to start `.insp` support |
| 360 Photo single shot, HDR, Starlapse, Burst; DNG; 18 MP | | | none | **wanted** |
| Single-lens Photo | 36 MP, 9 MP | `.insp`, `.dng` | none | wanted, low |
| Audio: Auto Wind Noise Reduction, Voice Focus, Stereo, 360 Audio | 48 kHz AAC | | ❓ which ours used; one with a Mic Air too | **one clip of each wanted** (field 121, §5.1) |
| Lens guards | | | guarded and bare footage | enough (§5.4) |
| Invisible Dive Case | | | none | wanted if a case is at hand |
| GPS remote | 10 Hz records | | two clips, one losing the fix (§8) | decoded and lined up with the video (§8) |

The files and timing of the modes we have no clip of are a guess from the
spec table: TimeShift and Bullet Time may record at other frame rates or
sizes, or without IMU or an `.lrv`, as the timelapse does (§3.5).

### 3.5 Timelapse ✅

From the six Demo timelapses (8K, 2 s interval, firmware v1.11.10):

- **The video looks like an 8K 30 clip**: two 3840² HEVC streams at
  29.97 fps, full-range BT.709, ~105 Mb/s, one frame per interval (1228
  frames for 41.5 min on `_078`). **No audio stream.** The `.lrv` is the
  usual 1664×832 at 29.97 fps, with the same frame count.
- **Field 26.1 is 2** (`VideoTimelapse` in telemetry-parser's
  `SubMediaType`), **field 30 `timelapse_interval` is 2000** and **field 59
  `timelapse_interval_in_millisecond` is true**, so the interval is 2000 ms.
  Field 120 (audio tracks) is 0. Normal clips have no field 30 or 59.
- **No IMU record (type 3).** In its place:
  - **type 6, `TimelapseTimestamp`**: one `u64` device-clock µs timestamp
    per frame, plus one (1229 on `_078`), an interval apart; the first one
    equals field 24.
  - **type 24, `TimelapseQuat`** (telemetry-parser names it; format not
    published): 40-byte entries `{f64 device time in s, f64 w, x, y, z}`,
    unit quaternions, **11 per frame, 2.1244 ms apart**: 21.24 ms, the
    readout time of field 25 at 8K. So the camera stores its orientation
    across each frame's readout, already integrated, instead of the raw
    gyro. Measured on the six clips (2026-11-05, `tmp/tl/`):
    - **Timing**: the sixth entry (the frame's centre row) sits at the
      frame's type 6 time minus half its exposure (type 4): slope −0.49 to
      −0.53 per ms of exposure over 0.2-33 ms, ≤ 0.2 ms rms left. The
      entries are on the device clock in seconds, the same clock as type 6.
    - **Stray groups**: `_079` and `_091` hold one group of 11 that
      belongs to no frame, 322 s and 615 s before the first (a group per
      frame follows); the others hold exactly one group per frame. Groups
      are matched to frames by time, not by position.
    - **Frame and axes**: the quaternion turns a world vector into the
      camera's axes (world → body). World z is up: body +z holds it within
      2-4° (median) on every clip, the other convention lets it wander 27°
      on `_095`. Body → the stitched sphere (+X right, +Y up, −Z forward)
      is **`y,z,x`** (the syntax of the IMU's axis map; not the IMU's own
      axes, `z,-x,-y`): found by the bike's lean, whose sideways axis lies
      where the camera's 27° yaw on the bike puts it under this map only,
      with the direction of turning taken from the GPS course (its rate
      against the quaternions' yaw about up: corr −0.48 to −0.89 on four
      clips, so positive yaw turns left); the image's own rotation between
      frames fits it best too, weakly (the rider fills half the views).
    - **Heading drifts**: the forward direction's heading against the GPS
      course at speed moves 5-12° per minute, not linearly (405° over
      `_078`'s 40 min, 600° over `_095`'s 61); up doesn't. World x and y
      are wherever the camera started.
- **Exposure (type 4) and GPS (type 7) run in real time**, not per frame:
  10 Hz over the whole recording (24 894 exposure records on `_078`), so
  the per-frame exposure sync of §7.1 doesn't apply.
- **The type 6 times are 2.026 s apart** on `_078` (2026-11-04), not the
  2000 ms of field 30: 1228 frames over 41.5 min say the same. They aren't
  evenly spaced: each interval is 2.000 or 2.100 s (a 100 ms tick of the
  10 Hz exposure clock skipped, a quarter of the intervals on `_078`,
  `_079`, `_088`, `_089`), so a frame's time is up to 0.8 s off a
  straight line through them; `_091` and `_095` are exactly 2.000 s
  apart.
- **The app** opens, stitches and exports them as 8K 30 clips (`_078`
  through `reframe_export`, 2026-10-20, clean stitch). Since 2026-11-04 it
  knows them as timelapses: video time is turned into the camera's clock
  by the frames' own times (type 6; 60.7 s per second of video on
  `_078`), for the GPS, and Media information shows *Timelapse*. Since
  2026-11-05 it stabilizes them from type 24 (`InsvModel::
  timelapseQuatAxes` = `y,z,x`): each frame by its own entries, the GPS
  and the motion by each frame's own type 6 time (the GPS lands up to
  16 ms of video from a straight line on `_078`). Checked on all six: the
  rotation between frames by the track against the image's (the forward
  view's roll, essential matrix) peaks at the frame itself, corr 0.43-0.78
  on the four long rides, gain 0.63-0.89; Horizon lock is level by eye on
  `_078`.

Field 26.1 isn't a reliable mode field beyond timelapse: it is 0 on the
8K, 4K 120 and 5.7K+ HDR clips, 6 (`VideoHdr`) on the 5.7K 60 HDR and the
5.7K I-Log clip, and 20 (past the published list) on four of the 2025
clips, split or not.

### 3.6 360 photos (`.insp`) ✅

From the 77 Demo photos, two series shot with **Interval** (firmware
v1.11.10):

- The `.insp` is a **JPEG** (Exif: `Arashi Vision`, `Insta360 X5`, GPS),
  11904×5952 for 72 MP: both lenses side by side as fisheye circles
  (5952² each), not stitched, with the
  `inst` trailer after the JPEG data (the footer of §4.1).
- **No Offsets table**: the footer's header points at the last record and
  the sequential walk (§4.2) reaches them all: type 3 (IMU, 2000 B, 100
  samples), 11, 9, 1 (metadata), 2 (thumbnail, 4 915 240 B: 2560×1280
  NV12 after the 40-byte header) and 5 (ThumbnailExt, 76 800 B: 320×160
  NV12).
- **Field 26.1 is 5** (`PhotoIntervalshooting`) on every photo, and
  **26.3 names the series' first photo**: 2 photos under `…_001`, 75 under
  `…_003`. The interval isn't in the metadata (no field 30); the file
  names step 10 s, sometimes 11.
- Field 25 (readout) is 27.7 ms, longer than 8K video's 21.24 ms.
- The app doesn't open `.insp` files yet.

## 4. The `inst` trailer — framing

The trailer is anchored at **EOF**. Everything is little-endian.
Implemented in `src/insv/InsvTrailer.cpp` (`WalkTrailerRecords`). The
structure below is confirmed independently by ExifTool and telemetry-parser.

### 4.1 Footer (last 78 bytes) ✅

| offset | size | field |
|---|---|---|
| 0 | 6 | header of the last record (see §4.2) |
| 6 | 32 | padding (zero) |
| 38 | 4 | **trailer length** in bytes from trailer start to EOF (u32). This is the `inst` box size minus its 8-byte box header. |
| 42 | 4 | **trailer version**: `3` on the X5 📖 |
| 46 | 32 | magic, the ASCII text `8db42d694ccc418790edff439fe026bf` |

### 4.2 Records ✅ 📖

Each record is `payload` followed by a 6-byte header. The header comes
**after** the payload, so you walk the records backward from EOF. The header
is **`{format: u8, type: u8, size: u32}`**. Our code reads the first two bytes
as one LE u16 "id", which gives `type << 8 | format`: `0x0300` means type 3 in
format 0. `format` is `0` = binary, `1` = protobuf, `2` = JSON
(telemetry-parser `RecordFormat`). So **`0x101` = type 1 (Metadata) in
protobuf format**.

- **Sequential walk**: from the footer's header, the payload starts at
  `-78 - size` from EOF. The previous record's header sits in the 6 bytes
  before that payload, and so on.
- **Offsets table (type 0)**: on the X5 the footer's header points first to a
  type-0 "Offsets" record: a table of 10-byte entries
  `{type: u8, format: u8, size: u32, offset: u32}`. `offset` is where that
  record's payload starts, from the trailer start, and its header follows at
  `offset + size`. Note the byte order is `type, format` here but
  `format, type` in a record header. That explains the "swapped ids" we saw
  (header `0x0300` appears in the table as `0x0003`).
  - On the X5 the sequential chain dead-ends after type 2 in a run of empty
    records. **The telemetry records can only be reached through this table.**
  - telemetry-parser checks each record header against its table entry
    (matching type and size). Our walker takes each record's position, type
    and size from its table entry and doesn't read the header: on all 61
    X5 samples (`.insv` and `.lrv`) the header repeats the entry ✅, and the
    Antigravity A1 writes no headers at all
    ([`antigravity-a1.md`](antigravity-a1.md)).
  - Empty entries are placeholders for types the clip doesn't have.

### 4.3 Record types

Type names are from telemetry-parser's `RecordType` / `ExtraType` 📖. Sizes
are from the 42.8 s clip `193105` (1282 video frames).

| hdr id | type | name | X5 size | contents | status |
|---|---|---|---|---|---|
| `0x0000` | 0 | Offsets | 310 | locator table (§4.2) | ✅ |
| `0x0101` | 1 | **Metadata** (protobuf) | ~4 KB | serial, model, firmware, calibration, timing, IMU config… (§5) | ✅ |
| `0x0200` | 2 | Thumbnail | 1 228 840 | 40-byte header (`u32 1, u32 record size, u32 1, u32 0, u32 width, u32 height`, zeros) + **1280×640 NV12**, an already **stitched equirectangular** frame from the start of the recording (ExifTool: `PreviewTIFF`; other models store JPEG, H.264 or, the Antigravity A1, a flat view here). Read by `ReadInsvThumbnail` for the Media tab's and project library's cards | ✅ |
| `0x0300` | 3 | **Gyro** (IMU) | 877 440 | accel + gyro, ~1 kHz (§6) | ✅ |
| `0x0400` | 4 | **Exposure** | 20 928 | one per sensor frame (§7) | ✅ |
| `0x0500` | 5 | ThumbnailExt | 76 800 (`.insp`) | 320×160 NV12; photos only (§3.6) | ⚠️ |
| `0x0600` | 6 | FramePts / TimelapseTimestamp | 9 832 (`_078`) | `u64` device µs per frame, plus one; timelapse only (§3.5; ExifTool: `VideoTimeStamp`) | ✅ |
| `0x0700` | 7 | **GPS** | 22 790 | 53 B × 10 Hz, fix updated at 1 Hz (§8); only with a GPS source | ✅ |
| `0x0900` | 9 | **AAAData** (auto-exposure / white-balance / focus) | 61 536 | **48 B per recorded frame** (§4.4) | 📖 |
| `0x0a00` | 10 | Anchors / highlights | 35 (51 with two marks) | `{type u8, count u32, count × u64}` lists, 7 types (1,2,3,4,16,17,18). The marks set while recording are in **type 1**, as device µs (below); all counts 0 on clips without marks | 📖 ✅ |
| `0x0b00` | 11 | AAASimulation | 342 294 | **267 B per recorded frame** (the same on `192900` and `201257`). Each block starts with the same `u32` ms timestamp as type 9's; the rest is bit-packed and not decoded, with small 8-bit curves visible | 📖❓ |
| — | 12–18 | ExposureSecondary, Magnetic, Euler, SecGyro, Speed, TBox, Quaternions | — | not on the X5 samples (other models) | |
| `0x1800` | 24 | TimelapseQuat | 540 320 (`_078`) | `{f64 s, f64 w, x, y, z}`, world → body, 11 per frame across the readout; timelapse only (§3.5) | ✅ |
| `0x1600` | 22 | Snapshots (`shell_recognition_data` in the `.pb` sidecar, §9: probably for recognising a lens guard) | 8 306 836 | **four 1664×832 NV12 frames of the dual-fisheye picture** from across the clip (§4.5) | ✅ |
| `0x1c00` | 28 | ? | 12 793 | eight 256-entry `u8` tables, identity on every sample, then one **256-entry `u16` tone curve** (values 0-255, concave: 40 -> ~89, 120 -> ~178, 200 -> ~229) that differs slightly between clips; the rest mostly zero. One curve for the whole picture, not per lens | ⚠️ |
| `0x1d00` | 29 | ? | 1 953 | 9-byte `{u64 µs device timestamp, u8}`, ~5 Hz | ❓ |
| `0x3900` | 57 | ? | — | only in the software-rewritten `_019-trim` clip, not in its card original: written by Insta360 software | ❓ |
| `0x8000` | 128 | **TimeMap** | 862 136 (`144221_019-trim`) | written by Insta360 software on trimmed/re-timed exports (the card original of `144221` has none). Decoded ✅: header `{u32 32 (header size), u32 trimCount, u32 pairBytes, u32 frameCount, 16 B zero}`, then `trimCount × {f64 duration, source start, source end}` (ms), then `(video ms, original ms)` f64 pairs, one per frame. On the sample: 1 trim, source 2002.0 → 1 799 764.6 ms, pairs `(0, 2002.0), (33.37, 2035.37)…`. **Field 24 keeps naming the original first frame**, so sync must add the source offset (§7.1) | ✅ |

**Highlight marks (type 10)** ✅ (2026-11-10, `Marks/…_220445_00_010`): the
record is the camera's `anchors` (its name in the `.pb` sidecar, §9). Each
list is `u8 type`, `u32 count`, then `count` little-endian `u64` timestamps,
with no padding. On that clip, recorded with two marks, list 1 holds
75 928 729 and 86 128 627 and the other six lists are empty (51 bytes; every
clip without marks has the 35-byte record with all counts 0). The values are
device µs on the clock of `first_frame_timestamp` (field 24, 70 062 121 here),
so a mark's video time is `(mark − field 24) / 1e6` s: **5.867 s** and
**16.067 s**, which match when the marks were set. The `.lrv` carries the same
record; the `.pb` sidecar doesn't hold the times. What lists 2, 3, 4 and
16-18 hold (marks made in the phone app? other kinds of highlight?) is
unknown ❓. Read by `insv::ReadInsvHighlights`; `insv_trailer_dump --marks`
prints the lists.

ExifTool decodes types 1 (partly), 2, 3, 4, 6 and 7. Its source notes that
0x900/0xa00/0xb00 also occur on X3 / ONE RS / Ace Pro. Our parser reads types
1, 2, 3, 4, 7 and 10.

### 4.4 Type 9 — AAAData (48 B per frame) 📖

Layout per telemetry-parser: `u32 timestamp` (ms), `f32 ev_target`,
`f32 exp_time`, `u32 data_stat`, `u32 luma_struct`, then `7 × u32` temperature
or spare data. `luma_struct` packs:
- `luma_wg_grid` = bits 0–6
- `luma_wg_y` = bits 7–13
- `sum_wg_y` = bits 14–18
- `iso = (100 · (luma_struct >> 19)) >> 6`

On `193105`: ev/exp read 0, and `luma_struct = 0x02000000` gives **ISO 100**.
The first u32 of the trailing data counts down slowly (2297, 2296, …). Its
ms clock sits ~208 ms after the video device clock ❓, so don't use it for
sync.

On `192900`, `201257` and `193105` (2026-11-03) only three of the 12 words
are ever non-zero: the timestamp, `luma_struct` and that slow counter (2083-3361
across the three clips; a temperature?). `ev_target`, `exp_time`,
`data_stat` and the other six spare words are 0 on every frame. **No
white-balance or per-lens colour values**: nothing here says how the two
lenses' colour differs (§7).

### 4.5 Type 22 — Snapshots ✅

Four small frames of the camera's picture, stored as decoded images:

```
36-byte header   {u32 1, u32 record size, u32 1, u32 0, u32 3, 4 × u32 0}
4 × {
  28-byte header {u32 width 1664, u32 height 832, u32 stride 1664,
                  u16 0, u16 8112, 12 × u8 0}
  NV12           1664×832 Y, then interleaved U V at half size
}
```

The `3` and `8112` mean nothing we know of; they are the same on every sample.
Each frame has the `.lrv`'s layout (§3.2): both fisheyes side by side,
lens 0 on the right. Measured on `192900`, `201257` and `193105` (2026-11-03,
each frame matched against every `.lrv` frame, rms 1.3-4 levels against 7-23
for the next best match): each one is a frame of its own clip, spread
across the clip and not stored in time order (`192900`: 124, 383, 253,
512 s; `193105`: 25.9, 34.1, 9.6, 42.2 s). How the camera picks them is
unknown.

They show the picture as the camera's processing made it, before the video
encoder. **They have the same colour as our decode of the `.insv`**: per lens
and per channel within 0.7 % on all 12 frames (mean of unclipped pixels,
over the whole circle and over the rim where the seam is; same range and
matrix as the video). So the colour difference between the lenses (§7) is
in the recording, not added by the decode.

## 5. Type 1 — Metadata (protobuf `ExtraMetadata`)

The payload is a protobuf message. telemetry-parser publishes its schema
(`extra_info.rs`, fields 1–65) 📖. Fields above 65 are newer and unnamed there;
their meanings below come from our own decoding ⚠️.

Our `ParseMakerNotes()` reads the first four length-delimited fields
(1, 2, 3, 5) by hand. That works because they come first; field 4
(`file_type`) is absent on the X5.

### 5.1 Field map (values from `193105`)

| # | name (telemetry-parser) | X5 value | notes |
|---|---|---|---|
| 1 | `serial_number` | `IAHEA25xxxxxxx` (14 characters) | ✅ |
| 2 | `camera_type` | `Insta360 X5` | ✅ |
| 3 | `fw_version` | `v1.5.6_build1` | ✅ |
| 5 | `offset` | 16-token short calibration | §5.2 ✅ |
| 7 | `creation_time` | `20250904193105` | recording start by the camera's clock, local: a varint holding the decimal `YYYYMMDDhhmmss`. ✅ The same time as the file name, on every X5 clip we have. The container's `creation_time` is that moment in UTC (`2025-09-04T16:31:05Z`; on `201257` 2 h earlier, here 3 h) ⚠️ the offset is presumably the camera's time-zone setting |
| 9 | `file_size` | 1012672185 | size of the file *before* the trailer body (= `inst` box offset + 8) ✅ |
| 10 | `total_time` | 42 | seconds |
| 11 | `gps` | 3 doubles | start fix: lat, lon, alt |
| 14 | `gyro` | empty | (older models: one sample) |
| 17 | `original_offset` | = field 5 | factory copy. The non-"original" variants may be adjusted for accessories (`OffsetConvertState`: WaterProof, DivingWater/Air, Protect, …) |
| 18 | `trigger_source` | 2 = RemoteControl (4 = BtRemote on `192900`) | 📖 |
| 19 | `dimension` | {3840, 3840} | per-lens stream size ✅ |
| 20 | `frame_rate` | 30 | nominal |
| 22 | `gamma_mode` | `standard`; `I_Log` in I-Log | colour profile ✅ (both values seen) |
| **24** | **`first_frame_timestamp`** | 2468081984 | **device µs of the first recorded video frame**; the sync anchor (§7.1) ✅ 📖 |
| **25** | **`rolling_shutter_time`** | **21.244** (11.837 on `201257`) | **frame readout time, ms**. Gyroflow's `frame_readout_time` reads it directly ✅ 📖 |
| 26 | `file_group_info` | {type 20, index 0, identify "/DCIM/Camera01/…_019.insv", total 0} | field 1 is telemetry-parser's `SubMediaType`: 2 on timelapses, 5 on Interval photos, otherwise not reliable (§3.5, §3.6); 20 is past the published enum (max 17). For a split recording `index` is non-zero on continuations (2 on `_020`), `identify` is the first file's path and `total` stays 0 -- the same on the card original as on the re-written copy ✅. |
| 27 | `window_crop_info` | {src 5376×5376, dst 5312×5312} | sensor crop window. `dst` is the focal reference: **`fx_video = fx · 3840/5312`**. Gyroflow computes `fx / (dst_w / dimension_w)` ✅ 📖 |
| **28** | **`gyro_timestamp`** | **1.6** | **IMU timing offset, ms**. Gyroflow subtracts it from every gyro/accel time (§6.2) 📖 |
| 29 | `is_has_gyro_timestamp` | true | enables field 28 |
| 30 | `timelapse_interval` | 2000 (timelapses only) | the interval, in ms when field 59 is set (§3.5) 📖 ✅ |
| 31 | `gyro_calib` | 6 × f64 + u64 unix ts | per-unit IMU calibration: 6 small values (−0.0069 0.0025 0.0041 −0.0055 −0.0088 0.0043), likely gyro + accel bias; ts 0. Identical on every clip. Whether they're already applied to type 3 data is unknown ❓ |
| 36 | `first_gps_timestamp` | 1757003465191 | Unix ms. Not the first fix's time (that's 1757003464999 here), nor the first frame's; up to ~1 s off either on the samples, meaning unknown ❓. GPS lines up by field 98.3 (§8) |
| 41 | `is_selfie` | 0 | |
| 42 | `is_flowstate_online` | 0 | in-camera FlowState off |
| 44 | `resolution_size` | {3840, 3840} | |
| 46 | `cam_posture` | 0 | CameraRotate0 (0/90/180/270) 📖 |
| 47 / 48 / 49 | `fov_type` / `distance` / `fov` | 15 = Mega / 0.6 / 56.8° (`192900`: 3 = Ultrawide / 1.0 / 40°) | the in-camera or app **default reframe view** |
| 51 | `gyro_type` | **1 = `InsdevImuType40609`** | **the IMU is a TDK ICM-40609(-D)** 📖 |
| 53 | `offset_v2` | 34-token calibration | §5.3 |
| 54 | `offset_v3` | 40-token MEI calibration | §5.3. **This is what Gyroflow uses** |
| 55 / 56 | `original_offset_v2/_v3` | = 53 / 54 | |
| 57 | `focus_sensor` | 3 = All | |
| 59 | `timelapse_interval_in_millisecond` | true (timelapses only) | field 30 is in ms 📖 ✅ |
| 61 | `audio_mode` | 9 | beyond the published enum |
| **62** | **`is_raw_gyro`** | **true** | **type 3 holds raw integer IMU counts** (§6.1) 📖 |
| 64 | `pts_type` | **2 = `VideoPtsEexposureFile`** | the video PTS derive from the exposure record, which confirms §7.1 📖 |
| **65** | **`gyro_cfg_info`** | **{acc_range: 32, gyro_range: 2000}** | **±32 g, ±2000 °/s**: the scale for raw counts (§6.1) 📖 |
| 93 | — | 42776 | duration, ms |
| 98 | — | {2468081984, 2510815317, 1757003465870, 1757003508603, 1282, 0, 20} | **first/last frame device µs, first/last frame Unix ms, frame count** (= ffprobe `nb_frames`). Absent in the rewritten `-trim` clips ✅ |
| 111 / 112 | — | 56-token calibration | full MEI with 13 distortion terms (§5.3). Probably "offset_v4 / original_offset_v4" |
| 120 | — | 1 (2 on `192900`) | **probably the number of audio tracks**: 2 only on the clip with the Mic Air, matching its two AAC streams (§3.1). 1 on every other sample, `.lrv` included |
| 121 | — | {1: 0, 2: 460} | repeated, **one entry per audio track** (the count in field 120). Field 2 is a signed varint: +378 to +460 on the camera-mic-only clips, −121 on *both* entries of `192900`. Meaning unknown ❓. Field 1 is 0 on every entry, so it doesn't say which track is which mic |
| 145 | — | named lens-profile table | per-accessory profiles `bare`, `ProtectorA`, `ProtectorS`, `ProtectorAS`, `InvisibleDiveWater`, `InvisibleDiveAir`: θ(deg)→image height(mm) polynomial + FOV each (**bare 200°**, protectors 195°, dive 190°). §5.4 ✅ |
| 143, 135 (=180), 146–163 | — | | ❓ |

The "bare 200°" profile matches our empirical finding that the fisheye
`radius` maps to θ ≈ 100°.

> **Code-comment correction:** `InsvTrailer.h` says the extended `2_…` string
> is "not in the 0x101 maker-notes record". It **is** in 0x101, as fields
> 53–56 and 111–112. `ReadInsvExtendedCalibrationString()` finds field 111
> anyway, because it scans for the longest `2_` run.

### 5.2 Short calibration string (`offset`, field 5)

```
2  2663.208 2705.380 2687.820 0.326 -0.017 89.997   2648.963 8071.630 2687.090 -0.283 -0.065 88.577   10752 5376 1137
N  |------------ lens 0 (6 values) ------------|   |------------ lens 1 (6 values) ------------|
```

**Not parsed any more** (2026-09-26): the stitch uses only the extended MEI
string (§5.3), which every X5 clip carries. The removed legacy parser read it
as per lens `cx cy radius tx ty tz`, then `rawH rawW extra`, with the circles
stacked vertically, plus empirical fixes: a ~90° `tz` "sensor clock", mirroring
both lenses, and θ_ref ≈ 100°. The 90° clock and the mirror are also needed on
the MEI path, so they're real coordinate conventions, not artefacts of that
reading.

**⚠️→📖 Better-supported reading:** per lens `radius cx cy yaw pitch roll`, in
a **side-by-side 10752 (W) × 5376 (H)** frame.
- Our evidence: the MEI strings (§5.3) put lens 0 at `cx=2705.380
  cy=2687.820` and lens 1 at `cx=8071.630`, which are the short string's
  2nd/3rd values per lens.
- insv-stitch's fallback path indexes it the same way. It reads `offset[2]`
  and `offset[3]` as cx/cy, takes `offset[7]/offset[1]` as the lens-1/lens-0
  focal ratio, and computes lens-1 cx as `offset[8] − offset[14]`
  (8071.63 − 5376).
- Moot for the app since the parser was removed; kept here as format
  reference.

The trailing token (`1137`) is unknown.

### 5.3 Extended calibration strings

All start with `2_` (the lens count) and end with one trailing integer: 132096
= 0x20400, 197632 = 0x30400, 394240 = 0x60400. telemetry-parser calls this
trailing token `flag`. Each lens block ends in `w h lensType` (`10752 5376
113`).

| field | name | tokens | per lens (telemetry-parser / insv-stitch layout) |
|---|---|---|---|
| 53/55 | `offset_v2` | 34 | 16: `radius cx cy yaw pitch roll tx ty tz` + 4 poly coefficients (`1.0 -0.189 0.274 -0.090`) + `w h type` ⚠️ |
| 54/56 | `offset_v3` | 40 | 19: **`xi fx fy cx cy yaw pitch roll tx ty tz k1 k2 k3 p1 p2 w h lensType`** 📖, then a trailing `flag` |
| 111/112 | (v4?) | 56 | 27: the full MEI model below ✅ 📖 (insv-stitch). Slightly different values (fx 4294.03 vs 4297.15), so probably a newer or refined calibration |

**56-token MEI layout** (`insv::LensCalibExt`, matching insv-stitch):

| idx | field | lens 0 value | notes |
|---|---|---|---|
| 0 | `xi` | 2.000000 | MEI mirror parameter |
| 1–2 | `fx fy` | 4294.03 4293.86 | sensor px, then `· 3840/5312` (field 27) |
| 3–4 | `cx cy` | 2703.31 2684.03 | in the 10752×5376 side-by-side frame; lens 1 `cx −= 5376`, then `· 3840/5376` |
| 5–7 | `yaw pitch roll` | 0.241 0.068 89.993 | degrees (see below: also the lens↔IMU rotation) |
| 8–10 | `tx ty tz` | 0 0 0; lens 1: 0.00077 0.00017 **−0.0318** | lens 1 is **~32 mm** behind lens 0 (the stereo baseline). Sign checked on seam parallax: lens 0's centre is the one ahead along lens 0's own axis; the flipped model matches nothing |
| 11–14 | `k1..k4` | 0.2297 1.602 −1.242 −3.170 | radial |
| 15 | reserved | 0 | |
| 16–17 | `p1 p2` | −0.00145 0.00040 | tangential |
| 18–21 | `s1..s4` | … | thin-prism |
| 22–23 | reserved | | |
| 24–26 | `w h type` | 10752 5376 113 | |

- The MEI forward model is implemented in `FisheyeProjection.cpp` and
  `fisheye_stitch_common.glsl`: `x = Xs/(Zs+xi)`, then distortion (radial
  k1–k4, tangential p1/p2, thin-prism s1–s4 in the OpenCV-omnidir form), then
  `u = fx·xd + cx`, `v = fy·yd + cy`, with (Xs, Ys) in the calibration's own
  image axes (u right, v down; our lens frame has both negated). Including
  p/s in these axes measurably improves the seam match;
  the other sign choices make it worse. It's the only stitch model; the
  short "Parameters" string isn't used.
- The extrinsic `yaw pitch` are rotations about the calibration's x / y
  axes. In a frame with x and y negated (ours), they flip sign; `roll` doesn't.
  Getting this wrong misaligns the seam by up to ~0.8°.
  They compose **pitch first, then yaw, then roll** (`Rz(roll) Rx(yaw)
  Ry(pitch)`, roll less its fixed 90°) ⚠️. The X5 can't tell: its angles are
  all near zero, and every order gives the same lens (65-70 dB apart).
  Cameras with large angles can: the Antigravity A1 (pitch −90°) and the
  ONE X2 (roll ~180°). Measured 2026-10-29 with the per-clip seam fit on
  three clips of each: only this order fits both (residual 0.02° on the
  A1, 0.04-0.16° on the ONE X2, small corrections). Roll last (`Rz Ry
  Rx`, the order used until then) tilts the A1's lens 0 2.9° off lens 1's
  axis, and the fit finds no seam; `Rx Rz Ry` fits the A1 but breaks the
  ONE X2.
  Even with it right, the two lenses still disagree on far content by
  ~0.2° at the seam, in a way a lens-1 rotation alone only partly takes up
  (measured 2026-10-23 on `192900`, `193105`, `201257`, one camera, standard
  guards; per 5° block, the shift of lens 1's seam strip that matches lens
  0's): an offset *along* the seam that varies as cos / sin of the azimuth
  (+0.06 to +0.18°, which a principal-point shift of lens 1 makes and a
  rotation can't; parallax only moves things across the seam), and an
  offset *across* it of +0.25 to +0.34° all round (the lenses disagree on
  the image radius near 90°: a radial scale), plus a small tilt. Fitted
  per clip (`insv::EstimateSeamAlignment`): lens 1 centre −0.08 to −0.15 %
  of the width across and −0.03 to −0.04 % down, both lenses' radius
  −0.06 to −0.08 %, pitch +0.3 to +0.4°; the offset on other frames of the
  clip drops from 0.16–0.18° (rotation only) to 0.04–0.10°. The app
  measures it per clip from the video.
- The MEI calibration is the **bare-lens** model. With a lens guard or dive
  case fitted, scale its image radius by the accessory profile (§5.4).
- Gyroflow's X5 path multiplies `cx` by 2 ("`cx_fix`", because of the
  side-by-side frame) and passes `[k1 k2 k3 p1 p2 xi]` as an "insta360"
  distortion model.

**Per-unit variance:** these values differ per camera, and X5 lenses are
user-replaceable. Always read calibration per file; never hardcode it.

### 5.4 Lens-accessory profiles (field 145) ✅

```
145 {
  1 { 1: "bare"        2: 0  2: 0.03159       2: -8.415e-05   2: 2.201e-06  2: -1.284e-08 2: 0 }
  1 { 1: "ProtectorA"  2: 0  2: 0.0321906505  2: -9.37245e-05 2: 2.5248e-06 2: -1.5e-08   2: 0 }
  1 { "ProtectorS" / "ProtectorAS": same as ProtectorA }
  1 { 1: "InvisibleDiveWater" 2: 0.000238 2: 0.03112 2: 7.306e-06 2: 4.427e-07 2: -3.892e-09 2: 0 }
  1 { 1: "InvisibleDiveAir"   2: 0 2: 0.0299338566 2: 4.86874e-05 2: -6.784e-07 2: 1.2e-09 2: 0 }
  2 { 1: "bare" 2: 200.0 }  2 { "Protector*": 195.0 }  2 { "InvisibleDive*": 190.0 }
  3 { 1: "invisibleDive" 2: 2 }  3 { 1: "heat_bare" 2: 10 }  3 { 1: "heat_protector" 2: 12 }
}
```

- Values are doubles (wire type 1). Identical on every clip in the sample set.
- Each `1 {}` entry is a polynomial `h(θ) = Σ cᵢ θⁱ`, **θ in degrees → image
  height in mm**. Evidence: `bare`'s h(θ) is proportional to the MEI model's
  sensor-px radius at a constant ~820 px/mm (≈1.22 µm pitch) from 10° to
  105°, within ±1 %.
- `2 {}` is the usable FOV per profile. `3 {}` is unknown (a dive-mode id and
  thermal thresholds?).
- A **guard pushes each angle further out**: `Protector(θ)/bare(θ)` = 1.017
  at the centre, rising to ~1.024 at 70–95°. The image circle stays the same,
  so the guarded lens fits 195° into it.
- **The camera does not record which accessory is fitted.** Fields 5/17,
  53/55, 54/56 and 111/112 (the "may be adjusted for accessories" pairs) are
  identical on guarded footage, and `ExtraUserOptions.offset_convert_states`
  (field 13.10, telemetry-parser) is absent; it is written by Insta360
  software after an edit. So the user has to choose it, as in Studio.
- Which of `ProtectorA`/`S`/`AS` is the Premium or Standard guard is a guess
  (A = premium, S = standard). They carry identical data, so it doesn't
  matter on the X5.
- **Measured effect**: ignoring it on guarded footage
  offsets the two lenses by ~4° across the seam; scaling the MEI radius by
  `Protector(θ)/bare(θ)` brings that to ≤ 0.5° (the rest is parallax). A
  constant 1.025 fits almost as well.

## 6. Type 3 — IMU (gyro + accelerometer)

### 6.1 Encoding and scaling

The payload is a flat array of fixed-size samples, each starting with a `u64`
device timestamp. Value order is **accel x, y, z, then gyro x, y, z** ✅.
ExifTool, telemetry-parser and our data all agree on that order. Ignore
insv-stitch's `x5_pipeline.md` table, which lists gyro first, 56-byte samples,
~200 Hz and m/s²; it contradicts its own code and the files.

| layout | size | after the timestamp | when |
|---|---|---|---|
| **raw counts** (X5) | **20 B** | 6 × `u16`, value = `raw − 32768` (signed count) | `is_raw_gyro` (field 62) true |
| doubles | 56 B | 6 × `f64` LE, already in g and rad/s | older models / `is_raw_gyro` false |

- **Pick the layout from field 62**, as telemetry-parser does; our parser
  does too. Only when the field is absent does it fall back to ExifTool's
  guess from `len % 20` / `len % 56` and a byte peek.
- **Scaling raw counts** 📖 (telemetry-parser, from field 65 `gyro_cfg_info`):
  - **gyro** in °/s = count / (32768 / `gyro_range`) = count / **16.384**
    (±2000 °/s), so rad/s = count · **0.0010653**
  - **accel** in g = count / (32768 / `acc_range`) = count / **1024**
    (±32 g)
  - Defaults when field 65 is absent: 2000 °/s and 16 g.
  - These are the TDK **ICM-40609-D**'s maximum full-scale ranges (datasheet:
    gyro ±15.6…±2000 °/s, accel ±4…±32 g). Field 51 names that part.
- **Our parser scales by field 65** (with the defaults above when it's
  absent). ExifTool, and our parser at first, use `count / 1000`
  for both, which is **wrong for the X5**:
  - Gyro rad/s comes out **6.1 % low** (×0.9387).
  - Accel comes out 2.4 % high.
  - Checked on three clips: the mean-gravity magnitude is 1.022 / 1.031 /
    1.026 g with `/1000`, and **0.998 / 1.007 / 1.002 g with `/1024`**.
  - A uniform 6 % gyro under-scale
    doesn't explain the ~50° axis disagreement in §6.3 on its own, but it biases
    every integrated angle.
- Size: 20 B × ~1006/s ≈ 72 MB/hour. `ReadInsvTelemetry(path, max)` can cap
  it. ExifTool stops at 20 000 samples.

### 6.2 Timing

- **Clock** ✅: the device's monotonic clock in **µs**, shared by types 3, 4,
  29 and metadata fields 24/98. It isn't zero-based and doesn't reset per file.
- **Rate** ✅: ~**1006 Hz**, mean step 994 µs, range 877–1000 µs. The steps
  are irregular, so integrate with the real `dt`.
- **Latency offset** 📖: metadata field 28 `gyro_timestamp` = **1.6 ms**
  (with field 29 true). Gyroflow computes, for raw-gyro files,
  `t_imu_video = (ts − first_frame_timestamp)/1e6 − gyro_timestamp/1000` in
  seconds. That is, IMU samples are shifted 1.6 ms **earlier** relative to
  video. Exposure samples are not shifted.
- **Pre-roll** ✅: the IMU track starts **157–778 ms before the first recorded
  frame** (§7.1).

### 6.3 Axes and IMU→camera orientation

- The raw axes are the IMU chip's own.
- **Gyroflow's X5 mapping** 📖 (telemetry-parser `process_map` +
  `insert_lens_profile`), applied to both gyro and accel:
  1. Rotate the raw vectors by the lens-0 `yaw, pitch, roll` from `offset_v3`
     (field 54: 0.326°, −0.017°, 89.997°). The matrix is `Rz(roll)·Ry(pitch)·
     Rx(yaw)`, which is essentially a **90° rotation about raw z**. So the
     "~90° sensor clock" angle in the calibration **is the lens↔IMU
     rotation**. It isn't just an image-plane quirk.
  2. Apply the IMU orientation string **`"yzX"`**. Each letter picks the
     source axis for output X, Y, Z; lowercase means negated. So
     `out = (−v.y, −v.z, +v.x)` in Gyroflow's camera frame. The X4 uses the
     same string.
  3. Net effect: `out ≈ (−raw_x, −raw_z, −raw_y)`, up to the sub-degree
     yaw/pitch terms.
- **insv-stitch** takes Gyroflow's normalised output and still needs a
  hand-solved `IMU_TO_CAM` (a Wahba fit against Studio renders on one unit,
  "~120° from identity", for camera X right / Y down / Z forward). It calls
  that matrix unit-specific. So even Gyroflow's mapping isn't the whole
  answer for 360 reprojection.
- **Ours** ✅ (measured 2026-09-25): **`"z,-x,-y"`** (the X5 row of
  `insv::InsvModel::imuAxes`), i.e.
  sphere X ← raw z, Y ← −raw x, Z ← −raw y, in the stitched sphere's frame
  (+X right, +Y up, −Z forward; `reframe_reproject.comp`).
  - Method: render raw pinhole views, estimate per-frame camera rotation with
    an essential matrix (RANSAC; separates rotation from forward-motion
    parallax), rotate into the sphere frame, and least-squares fit a 3×3 map
    against the §7.1-synced, §6.1-scaled gyro. Three view directions on
    `193105` agree to a few degrees; the combined fit is within ~6° of the
    signed permutation (scale ≈ 1). The camera rotation left after correcting
    with it: 0.37 °/frame vs 0.74 raw (0.96 with the old map).
  - The old default `"y,z,x"` (an early `|corr|` pick, sign-blind and made with
    the ~0.8 s sync error) is ~120° off. An early gravity fit (a since-removed
    experiment tool) found `"z,x,y"` on the handlebar clip: the same permutation, with two
    axes' signs flipped (and run without the §7.1 sync).
  - **Verified on four clips** ✅ (2026-09-25): 8 segments (20 s, the
    highest-rotation windows, 4 horizon-band views each, lag-corrected per
    §7.1) on `193105`, `192900`, `201257` and `144221_020-trim`.
    `z,-x,-y` ranks 1st of the 24 signed permutations on every one, 2.4–4.8°
    from that segment's free fit, the runner-up far behind. The handlebar
    clip (`144221_019-trim`) stays unmeasurable: handlebars fill every view
    (inlier ratio ~0.1). The mapping is a property of the camera body, not the
    mount, and its sibling `020-trim` (same camera) confirms it.
  - Exact rotation + per-axis scale, pooled (7 segments, 5 397 frames): **1.9°** from
    the permutation (about sphere Y), gyro scale 1.00 / 0.95 / 1.00 (raw
    x/y/z). Using them instead of the plain permutation improves the residual
    by < 1 % on every segment, held-out included — not worth adopting.
- **Residual gyro bias** (2026-10-09): on the five still `Modes` clips (accel
  spread ~0.001 g) the raw gyro means (−0.0051, +0.0066, +0.0018) rad/s
  (~0.35 °/s), drifting slowly between clips (−0.0042, +0.0057, +0.0015 three
  minutes later). Not field 31's values. `GyroStabilizer::build()` fits it per
  clip for horizon leveling.
- Observed on stick/handlebar clips: mean accel ≈ (−0.80, 0.60, −0.23) g
  (`/1000`), which splits across raw axes 0 and 1. The stick resonance puts
  ~0.75 g RMS of ~9–11 Hz on the accelerometer, so low-pass it (~1.5 Hz)
  before using it as gravity.

## 7. Type 4 — Exposure ✅

- 16-byte samples: `u64` device µs timestamp, then `f64` **exposure time in
  seconds** (0.00066–0.020 s here; ExifTool shows `ShutterSpeed` 1/335).
- **One per sensor frame**, 33 368 µs apart (29.97 fps, ±80 µs).
- **More samples than video frames**: the sensor streams before recording
  starts. `193105` has 1308 exposure samples for 1282 frames: 24 before and 2
  after.
- telemetry-parser treats type 12 (`ExposureSecondary`) the same way; it
  isn't present on the X5.
- ✅ One record for **both lenses**: they expose together. Their colour
  still differs, measured from the picture (2026-10-31, seam cells both
  lenses see alike, unclipped, over each clip): **fixed within a clip**
  (±1.5-3 % outside flare) but **different between clips** (lens 0
  against lens 1, blue −4.5 % on `192900`, −2.7 % on `201257`, +1.3 % on
  `193105`), and changing across the overlap per channel, red rising and
  green / blue falling towards lens 0 by ~0.5 % per degree: the two lenses'
  rims fall off differently, in colour too. The app measures it per clip
  (`insv::FitLensColour`). The camera's own snapshots (§4.5) show the same
  difference, and no record read so far (types 1, 4, 9, 22, 28) holds a
  colour value per lens.

### 7.1 Video ↔ IMU time sync ✅ 📖

`first_frame_timestamp` (field 24; also 98.1) is the device timestamp of the
first recorded frame. On every clip it **equals one exposure timestamp
exactly**:

| clip | exposure idx of frame 0 | first frame − IMU[0] | exposure[0] − IMU[0] |
|---|---|---|---|
| `193105` (`.insv` and `.lrv`) | 24 | **+773.5 ms** | −27.4 ms |
| `201257` | 24 | **+778.4 ms** | −22.4 ms |
| `192900` | 5 | **+157.3 ms** | −9.5 ms |
| `144221_019-trim` | 23 | **+768.6 ms** | +1.1 ms |

This is **exactly how Gyroflow aligns Insta360 files** 📖. telemetry-parser
subtracts `first_frame_timestamp` from every gyro, accel and exposure time,
then subtracts `gyro_timestamp` from the IMU. Field 64 (`pts_type =
VideoPtsEexposureFile`) says the video PTS come from the exposure record.

```
video time of an IMU sample   t = (imu.ts − field24)·1e-6 − field28·1e-3        [s]
video frame n                 ↔ exposure[k + n],   exposure[k].ts == field24
```

Our code used to assume `exposure[0]` is frame 0 (a "−26.5 ms"
offset; the real offset is **+0.16 to +0.78 s**). Fixed 2026-09-25:
`insv::MakeInsvImuTrack` anchors on field 24 + field 28,
verified against image motion on two clips.

**Trimmed files** ✅ (2026-09-25): a file re-written by Insta360 software after
a trim keeps field 24 = the *original* first frame, but its video starts later.
The TimeMap record (type 128, §4.3) gives the original time of video t = 0:
2002 ms on `144221_019-trim` (its video has 53 880 frames against 53 981
exposure samples after field 24's frame). Without adding it the gyro lands 2 s
off, which made horizon lock tilt ~45° in corners. `InsvTelemetry::time_map_offset_ms`
carries it (median source − video offset; speed-ramped maps aren't modelled).

**Frame-clock drift + readout** ✅ (measured and fixed 2026-09-25). The MP4 PTS are a nominal constant 1001/30000 s
(frame 14220 of `192900` sits at exactly 474.474 s), but the camera's frame
clock isn't exactly 29.97 fps. `exposure[k+n].ts − field24 − n/fps` grows
linearly: **+40 ppm** on `192900`, `193105` and `144221_020-trim` (+10 ms at
255 s, +19 ms at 475 s), **−15 ppm** on `201257` (−7 ms at 475 s). On a 30-min
clip that's ~70 ms. Mapping video time through `n/fps` (as the code does)
lets the sync drift by that much. On top of that, the image content lags the
frame timestamp by about **half the readout** (field 25 / 2: 10.6 ms at
21.244 ms, 5.9 ms on `201257`), i.e. the timestamp marks the start of
readout. Image-measured best lag on 8 segments / 4 clips vs
`drift + readout/2`: mean +2 ms, sd 9 ms (each segment's own lag repeats to
~3 ms across its two halves; the spread is content-dependent — which sensor
rows the tracked features sit in). Rotational shake removed (residual vs
none, 8-segment mean): 35 % now → 40 % with drift → 43 % with drift +
readout/2 (per-segment best lag: 48 %).
`insv::MakeInsvImuTrack` now fits the clock rate from the
exposure record (least-squares slope vs `n/fps`) and maps video time as
`t·(1 + rate) + offset`, the derived offset including `field25/2`:

```
gyro time of video time t = t·(1 + rate) + (field24 − imu[0].ts)·1e-6
                            + field28·1e-3 + timeMap·1e-3·(1 + rate) + field25·0.5e-3
```

Stabilized Lean-follow renders (16 views): rotation removed vs raw 20 % →
27 %.

**Rolling shutter, both lenses** ✅ (measured 2026-09-26;
**supersedes the per-lens model below**). Per-cell lags (8×6
flow cells per view, ~570 cells mapped to lens + sensor row) show both lenses
read out top to bottom over field 25, in step: row gradient ≈ field 25 on
all clips (18–22 ms at 21.2 ms, 10.6–11.8 ms at 11.8 ms). Row v of either
lens is captured at `centre + (v/H − 0.5)·field25`.

**The centre row's time: half the exposure before the frame's** ✅
(measured 2026-11-05; replaces `field24 + field28 − 2.3 ms`, which was
`192900`'s alone). Each row is taken at the middle of its exposure, so the
centre row of frame n sits at

```
exposure[k + n].ts + field28 − 0.5 ms − exposure[k + n].exposure_time / 2
```

The app's per-clip sync measurement (`stitch::MeasureClipSync`, image motion
against the gyro) on three 4 s windows of each sample clip, fitted against
the window's median exposure time and field 25: on 19 X5 clips (51 windows,
exposure 0.3–10 ms, readout 11.8 and 21.2 ms) the best lag falls by
0.501 ms per ms of exposure, 0.31 ms RMS left (1.99 ms with one constant);
the readout time adds nothing. The Antigravity A1 gives the same
(antigravity-a1.md). Exposures over 10 ms weren't measured with motion, but
the camera's own timelapse orientation (§3.5) puts each frame's centre row
half its exposure before the frame's time over 0.2–33 ms. Auto exposure
changes the exposure from frame to frame, so `insv::MakeInsvImuTrack` times
each frame by its own (`ImuTrack::frameTimes`); the per-clip fine-tune is
left with ±0.3 ms.

~~Per-lens capture time** ✅ (measured 2026-09-26;
supersedes the `+ field25/2` term above). The `readout/2`
term, and the "content-dependent" ±9 ms spread, came from two things. The
two lenses aren't exposed at the same instant. And the renders used for the
fit had their stab matrices a frame out of step: `SeekTo` lands on the first
frame at or after trim-in, but the tools baked `trimIn + i/fps`. Measured
with correctly paired renders: 40° views around the horizon, each view's
best gyro lag from the essential-matrix inter-frame rotation, mapped to lens
and sensor pixel. Lags are relative to `field24 + field28`:

| clip | readout (field 25) | lens 0 | lens 1 | within a lens |
|---|---|---|---|---|
| `192900` | 21.24 ms | −7.2 ms (7 views) | −0.2 ms (6) | ≤ 3 ms over the sensor |
| `201257` | 11.84 ms | −7.4 ms (7) | −4.2 ms (9) | ≤ 5 ms |
| `193105` | 21.24 ms | (1 usable) | −3.2 ms (6) | ~14 ms (noisy) |

Model now used: lens 0 at `field24 + field28 − 7.3 ms` (the stabilizer's
reference time), lens 1 **a third of the readout later**. The stitch
de-rotates lens 1 to lens 0's time (`stitch::CaptureTiming`). There is little
per-row rolling shutter within a lens, so the per-row correction stays
opt-in.

```
gyro time of video t (lens 0) = t·(1 + rate) + (field24 − imu[0].ts)·1e-6
                                + field28·1e-3 + timeMap·1e-3·(1 + rate) − 7.3e-3
lens 1 captured at            + field25 / 3
```

## 8. Type 7 — GPS ✅ 📖

53-byte records at **10 Hz**, written only when a GPS source is connected (a
GPS remote, per Insta360). Layout, identical in ExifTool, telemetry-parser and
our decode:

| offset | type | field |
|---|---|---|
| 0 | u64 | Unix time, seconds (UTC). ExifTool reads it as two u32 |
| 8 | u16 | milliseconds |
| 10 | char | `A` acquired / `V` void (void fixes carry no N/S/E/W) |
| 11 | f64 | latitude, degrees |
| 19 | char | `N` / `S` |
| 20 | f64 | longitude, degrees |
| 28 | char | `E` / `W` (ExifTool has also seen `O`, which it treats as west) |
| 29 | f64 | speed, **m/s** |
| 37 | f64 | track / heading, degrees |
| 45 | f64 | altitude, m (telemetry-parser comment: "geoid undulation") |

**Records are 10 Hz, fixes 1 Hz.** The X5 writes one record per 100 ms of
video (430 records on the 42.8 s `193105` clip), but the fix behind them
updates once a second: each fix -- timestamp and position alike -- repeats
over ~10 consecutive records (9 or 11 at times). When the signal is lost the
last fix keeps repeating: on `201257` the fix updates for 29 s, then one
timestamp repeats over 211 records (21 s of video), one last record follows,
and the record ends ~48 s into a 10:41 recording. So neither the record count
nor the first-to-last time span measures the track; count distinct
timestamps.

**Heading -1** means the camera doesn't know the course: it writes it while
standing still (speeds up to 0.37 m/s on `_080`, `_081`, `_083`; 47 of
`_080`'s 1222 fixes). Every other heading is 0-360.

**Lining up with the video: the timestamps, by field 98.3.** GPS is timed
in Unix time (UTC); field 98.3 is the first frame's Unix ms on the camera's
clock, so a fix's video time is `fix ms - field 98.3`. The record order
doesn't carry the time: `201257`'s lone record after the lost-fix repeat
sits at ~48 s of video but is stamped 206 s, and its position is ~3 km on
from the last fix -- what 180 s at the speed before covers, not 22 s. Field
36 (`first_gps_timestamp`) is neither the first fix's time nor the first
frame's (up to ~1 s off either way on the samples), so it isn't used. The
first fix lands between -0.9 s and +1.4 s of video on the samples, and the
record stops up to ~1.6 s before the video ends (`193105`). Insta360's
trimmed exports have no field 98, and their GPS isn't lined up.

**Field 98.3 alone leaves the GPS 0.5-2.4 s late** (measured 2026-10-29): the
change of the fixes' speed lines up with the IMU's acceleration along the
travel only with the fixes moved that much earlier -- `193105` 2.0 s,
`201257` 1.6 s, `_083` 2.4-1.9 s, `_085` 0.6 s, `_086` 0.5 s, and `_080`
2.0 s at the start of its 21 min, 1.5 s at the end (r 0.81-0.99 per 2 min
of track). The picture agrees: `_080` sets off at 44.2 s of video (frame
differences on the LRV), the speed by field 98.3 at ~46.2 s, lined up at
~44.1 s. Whether it's the camera's clock (set from the phone) against GPS
time, the GPS source's latency or both isn't known; it differs per clip and
drifts within one ❓. `camera::ReadClipTelemetry` therefore lines a field-98
track up against the IMU (`insv::AlignGpsByAcceleration`, `src/insv/Gps.h`, on
`insv::BuildMotion`'s forward acceleration): the shift over each ~2 min,
straight between them. A clip that stands still or keeps a steady speed
(`_081`, `_082`, `_084`) stays on field 98.3.

`ReadInsvGps` (`src/insv/InsvTrailer`) decodes the record: acquired fixes,
each once (the first record carrying it; the lost-fix repeat and anything
out of order dropped), the hemisphere letters as signs, with field 98.3.
Checked against `exiftool -ee -n` on `193105` (43 fixes) and `_080` (1222):
every value equal (ExifTool gives the speed in km/h). `Insta360Reader`
turns it into the common `insv::GpsTrack` in video time (heading -1 as
unknown), read through `camera::ReadClipTelemetry`. `ReadInsvTelemetry`
still
only counts the record for the Media information panel -- records, `A`
records, the fix rate (median step between distinct timestamps) and the
track length (distinct timestamps × that step); positions stay out of it.

## 9. `MISC/Camera01/<file>.pb` sidecar ✅

The camera writes one sidecar per media file into `MISC/Camera01/`, named
after it with `.pb` appended: `VID_…_00_NNN.insv.pb` **and**
`LRV_…_01_NNN.lrv.pb` (insv-stitch's `_find_pb_path` names the first 📖).
Read from the 36 sidecars of the Demo day (`Demo/…/card/`, firmware
v1.11.10, 5.9-6.0 KB each), a protobuf with:

- **Field 1, an index of the file's trailer**: one entry (field 1) per
  record that has data, `{1 format, 2 name, 3 offset, 4 size, 5 type}`,
  exactly the offsets table of §4.2 (offsets from the trailer start); then
  2 = the 16-token calibration string (trailer field 5), 3 = the trailer's
  start in the file (file size minus the trailer length of §4.1), 5 = 3
  (probably the trailer version, §4.1), 4 = ❓ (9.6 MB on `_078`, a little less on its
  `.lrv`).
  - **The names are the camera's own** for the record types: `metadata` (1),
    `thumbnail` (2), `gyro` (3), `exposure` (4), `timelapse_timestamp`
    (6), `gps` (7), `aaa` (9), `anchors` (10), `aaa_simulation` (11),
    `shell_recognition_data` (22), and `unknown_type` for 24, 28 and 29.
- **Field 2, the file's stream parameters** (some numbered fields
  unknown ❓): audio bitrate 192000 (1), codec `aac` (5), 48000 Hz (7);
  video bitrate (8: 100 Mb/s on a timelapse, 180 Mb/s on an 8K 30 clip, 8
  Mb/s on an `.lrv`), codec `hevc` / `h264` (25), width 3840 / 1664 (15,
  31), 29.97 fps (27, 29; 28 = `{1001, 30000}`), a duration in s (6, 26; 0
  on timelapses), and **19 = the trailer's metadata record (type 1),
  base64-encoded, byte for byte** -- the "base64 blob" insv-stitch reads.

We don't need it: everything in it is in the file's own trailer, which a
copy without `MISC/` still has. It doesn't contain the IMU→camera rotation.

## 10. Geometry cheat-sheet (X5)

- Sensor window 5376² per lens, focal reference 5312 (field 27). The video
  stream is 3840² (scale 5/7), with fisheye radius ≈ 1920 stream px.
- **Field of view** ≈ 200° (bare lens), which puts `radius` at θ ≈ 100°.
  Protectors reduce it to 195°, dive cases to 190° (field 145).
- Two lenses back to back: 180° apart in yaw, ~32 mm apart. Studio's "front"
  needs a 180° output-yaw relative to our lens 0.
- The "mirror" the removed short-string path needed is simply the MEI
  calibration's image axes (§5.3).
- **Rolling-shutter readout = field 25**, per clip: 21.24 ms in the 8K 30 fps
  sample mode and 11.84 ms on `201257`. Use the file's value rather than a
  constant.

## 11. Tools

| tool | use |
|---|---|
| `build/insv_trailer_dump <file>` | serial, model, firmware, Parameters, IMU/exposure summary; `--imu` / `--exposure` / `--gps` dumps |
| `exiftool -ee -G3 <file>` | independent decode of types 1 (partly), 2, 3 (first 20 000, `/1000` scaling), 4, 7 |
| Gyroflow `telemetry-parser` (`gyro2bb`, or the Python `telemetry_parser`) | full metadata JSON (`Extra metadata`), correctly scaled and synced IMU, Insta360 lens profile |
| `ffprobe -show_streams` | container and streams (§3) |
| `tools/residual_stab --diagnose` | IMU spectra, image-vs-gyro sweep, sync (block [5]) |

## 12. Open questions (after the 2026-09-24 research)

Resolved by the research: the record-type names, the type-9 layout, the
meaning of most metadata fields, the IMU scale/range, the IMU part, the sync
anchor, the rolling-shutter source, the sidecar path, and the file-split rule.

Still open:
1. **IMU→camera rotation for 360 reprojection.** Gyroflow's `yzX` + lens
   rotation is a starting point, but insv-stitch still needed a per-unit
   solved matrix. Re-measure the ~50° axis discrepancy (§6.3) now that the
   sync anchor is fixed, and after fixing the gyro scale (§6.1).
2. **Is `gyro_calib` (field 31) already applied** to the type-3 data, and
   what are its 6 values (gyro bias + accel bias?).
3. **Short-string field order** (§5.2): the `radius cx cy` reading is
   likely but unconfirmed. Unused by the app since 2026-09-26.
4. Unknown record types 11 (layout), 22, 28, 29, 57, and metadata fields
   98+ other than those listed.
5. What sets field 25 per mode (resolution / frame rate / sensor mode).
   8K (HDR on/off), 5.7K+, 5.7K 60 and 4K 120 are now covered (§3.3); the
   other modes and rates are in §3.4.
6. X5 I-Log's transfer curve (§3.3; bit depth and tagging are known now).
   Not needed while the maker's LUT does the conversion.

## 13. External sources

- Gyroflow **telemetry-parser**, `src/insta360/{mod,record,extra_info}.rs`
  (record framing, record types, `ExtraMetadata` protobuf schema, raw-gyro
  scaling, timestamp alignment, X5 IMU orientation `yzX`, lens-profile
  construction): <https://github.com/AdrianEddy/telemetry-parser>
- **ExifTool** `lib/Image/ExifTool/QuickTimeStream.pl`, `ProcessInsta360` +
  `%insvDataLen`: <https://github.com/exiftool/exiftool>; the "Parameters"
  field: <https://exiftool.org/forum/index.php?msg=78942>
- **insv-stitch** (`x5_pipeline.py`: 56-token MEI layout, sensor→video
  scaling, `.insv.pb` sidecar, `IMU_TO_CAM`):
  <https://github.com/BenjaminHenriksson/insv-stitch>
- Insta360 shooting specs (X-series table, X5 column: modes, resolutions,
  frame rates, file formats, audio modes):
  <https://onlinemanual.insta360.com/x5/en-us/specs/shooting-specs>
- Insta360 X5 manual, "File Formats" (naming digits):
  <https://onlinemanual.insta360.com/x5/en-us/operating-tutorials/storage/fileformat>
- Insta360 support: segmented recording every 29 min 59 s on X5/X4/X3
  (search result, Insta360 support pages)
- TDK ICM-40609-D datasheet (full-scale ranges):
  <https://invensense.tdk.com/products/motion-tracking/6-axis/icm-40609-d/>
- Insta360 manual, I-Log mode (X5 and X6):
  <https://onlinemanual.insta360.com/x6/en-us/operating-tutorials/capture-preview/features/ilog>
- Insta360 I-Log LUT downloads (X5 8-bit, 10-bit):
  <https://www.insta360.com/download/i-log>
- Gyroflow docs, Insta360 support (360 models unsupported in Gyroflow itself):
  <https://docs.gyroflow.xyz/app/getting-started/supported-cameras/insta360>
