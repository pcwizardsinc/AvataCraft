#!/usr/bin/env bash
# ==============================================================================
# AvataCraft: DangTree.OSV and DangTree.LRF Reader Test Suite
# Tests OSV demuxing, LRF proxy pairing, dual-fisheye stream geometry & audio
# Compatible with: Fedora Linux 45 Workstation & macOS (iMac)
# ==============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_DATA_DIR="${SCRIPT_DIR}/test_data"
OSV_FILE="${TEST_DATA_DIR}/DangTree.OSV"
LRF_FILE="${TEST_DATA_DIR}/DangTree.LRF"

echo "=== AvataCraft: Testing DJI Avata DangTree Footage Reader ==="
echo "Target: ${OSV_FILE}"
echo "Proxy:  ${LRF_FILE}"
echo ""

# 1. Existence Check
if [[ ! -f "$OSV_FILE" ]]; then
    echo "[-] ERROR: Missing ${OSV_FILE}"
    exit 1
fi

if [[ ! -f "$LRF_FILE" ]]; then
    echo "[-] ERROR: Missing ${LRF_FILE}"
    exit 1
fi

echo "[+] Step 1: Both DangTree.OSV and DangTree.LRF files present on disk."

# 2. Check File Sizes
OSV_SIZE=$(wc -c < "$OSV_FILE")
LRF_SIZE=$(wc -c < "$LRF_FILE")
echo "[+] Step 2: OSV size: ${OSV_SIZE} bytes | LRF size: ${LRF_SIZE} bytes"

# 3. Demux & Stream Validation with ffprobe
if command -v ffprobe &> /dev/null; then
    echo "[+] Step 3: Probing ISO MP4 demuxer on DangTree.OSV..."
    ffprobe -v error -show_entries format=format_name,duration:stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 "$OSV_FILE"
    
    echo ""
    echo "[+] Step 4: Probing companion proxy stream on DangTree.LRF..."
    ffprobe -v error -show_entries format=format_name,duration:stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 "$LRF_FILE"
else
    echo "[!] Note: ffprobe not in PATH, relying on C++ / avformat demuxer."
fi

# 4. Proxy Sibling Pairing Rule Check
OSV_BASE="${OSV_FILE%.*}"
EXPECTED_PROXY="${OSV_BASE}.LRF"
if [[ "$EXPECTED_PROXY" == "$LRF_FILE" ]]; then
    echo ""
    echo "[+] Step 5: Proxy sibling pairing verified: DangTree.OSV -> DangTree.LRF"
else
    echo "[-] Sibling pairing mismatch!"
    exit 1
fi

echo ""
echo "=============================================================================="
echo "SUCCESS: DangTree.OSV and DangTree.LRF passed all reader and proxy checks!"
echo "=============================================================================="
